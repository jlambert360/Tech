// ==UserScript==
// @name Hololive Jetri Fix
// @namespace jetri fix
// @version 0.1
// @description Fix multistreaming in .jetri
// @author Anonymous
// @include https://hololive.jetri.co/*
// @include https://nijisanji.jetri.co/*
// @run-at document-start
// @grant none
// ==/UserScript==

(function() {
'use strict';

localStorage.setItem('ruleOnePlayer', 0);
localStorage.setItem('rulePauseOther', 0);
})();