// ==UserScript==
// @name         Replace KomodoHype with YungMatt
// @version      1.0
// @description  Replace KomodoHype with YungMatt
// @author       Bird
// @match        *://twitch.tv/*
// @match        *://*.twitch.tv/*
// @grant        none
// ==/UserScript==

(function() {
    function getImagesByAlt(alt) {
        var allImages = document.getElementsByTagName("img");
        var images = [];
        for (var i = 0, len = allImages.length; i < len; ++i) {
            if (allImages[i].alt === alt) {
                images.push(allImages[i]);
            }
        }
        return images;
    }

    setInterval(function(){
        var PogChamps = getImagesByAlt('KomodoHype');
        PogChamps.forEach(function(champ){
            if(champ.classList.contains('emote-picker__image') || champ.classList.contains('emote-picker__emote-image')){
                champ.src = "https://cdn.discordapp.com/attachments/604830051430825994/846129934342815774/128937812237.png";
                champ.srcset = "https://cdn.discordapp.com/attachments/604830051430825994/846129934342815774/128937812237.png 1.0x";

            }if(champ.classList.contains('chat-line__message--emote')){
                champ.src = "https://cdn.discordapp.com/attachments/604830051430825994/846129934342815774/128937812237.png";
                champ.srcset = "https://cdn.discordapp.com/attachments/604830051430825994/846129934342815774/128937812237.png 1x";
            }
        })
    },100)
})();