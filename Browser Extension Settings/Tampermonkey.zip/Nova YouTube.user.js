// ==UserScript==
// @name            Nova YouTube
// @namespace       https://github.com/raingart/Nova-YouTube-extension/
// @version         0.33.2
// @description     Ultimate decision for YouTube™

// @author          raingart <raingart+scriptaddons@protonmail.com>
// @license         Apache-2.0
// @icon            https://raw.github.com/raingart/Nova-YouTube-extension/master/icons/48.png

// @homepageURL     https://github.com/raingart/Nova-YouTube-extension
// @supportURL      https://github.com/raingart/Nova-YouTube-extension/issues
// @contributionURL https://www.patreon.com/raingart
// @contributionURL https://www.buymeacoffee.com/raingart
// @contributionURL https://www.paypal.com/donate/?hosted_button_id=B44WLWHZ8AGU2

// @include         http*://*.youtube.com/*
// @include         http*://*.youtube-nocookie.com/*
// @include         http*://raingart.github.io/options.html*

// @exclude         http*://*.youtube.com/*.xml*
// @exclude         http*://*.youtube.com/error*
// @exclude         http*://music.youtube.com/*
// @exclude         http*://accounts.youtube.com/*
// @exclude         http*://studio.youtube.com/*

// @grant           GM_addStyle
// @grant           GM_getResourceText
// @grant           GM_getResourceURL
// @grant           GM_addValueChangeListener
// @grant           GM_removeValueChangeListener
// @grant           GM_listValues
// @grant           GM_getValue
// @grant           GM_setValue
// @grant           GM_deleteValue
// @grant           GM_registerMenuCommand
// @grant           GM_unregisterMenuCommand
// @grant           GM_notification
// @grant           GM_openInTab

// @run-at          document-start

// @compatible      chrome >=80 Violentmonkey,Tampermonkey
// @compatible      firefox >=74 Tampermonkey
// ==/UserScript==
/*jshint esversion: 6 */
try {
   // throw 'test';
   document?.body;
} catch (error) {
   return alert(GM_info.script.name + ' Error!\nYour browser does not support chaining operator.');
}

if (GM_info?.scriptHandler == 'Greasemonkey') {
   return alert(GM_info.script.name + ' Error!\nGreasemonkey is not supported.');
}

// isMOSupported
if (!('MutationObserver' in window)) {
   return alert(GM_info.script.name + ' Error!\nMutationObserver not supported.');
}
window.nova_plugins = [];
window.nova_plugins.push({
   id: 'comments-popup',
   title: 'Comments section in popup',
   'title:zh': '弹出窗口中的评论部分',
   'title:ja': 'ポップアップのコメントセクション',
   'title:ko': '팝업의 댓글 섹션',
   'title:id': 'Bagian komentar di popup',
   'title:es': 'Sección de comentarios en ventana emergente',
   'title:pt': 'Seção de comentários no pop-up',
   'title:fr': 'Section des commentaires dans la fenêtre contextuelle',
   'title:it': 'Sezione commenti nel popup',
   'title:tr': 'Açılır pencerede yorumlar bölümü',
   'title:de': 'Kommentarbereich im Popup',
   'title:pl': 'Sekcja komentarzy w osobnym oknie',
   'title:ua': 'Розділ коментарів у спливаючому вікні',
   run_on_pages: 'watch, -mobile',
   section: 'comments',
   // desc: '',
   _runtime: user_settings => {

      // contents is empty
      // #comments:not([hidden]) > #sections > #contents:not(:empty)

      const COMMENTS_SELECTOR = 'html:not(:fullscreen) #comments:not([hidden])';

      NOVA.waitElement('#masthead-container')
         .then(masthead => {

            NOVA.css.push(
               `${COMMENTS_SELECTOR},
               ${COMMENTS_SELECTOR}:before {
                  position: fixed;
                  top: ${masthead.offsetHeight || 56}px;
                  right: 0;
                  z-index: ${Math.max(
                  getComputedStyle(masthead)['z-index'],
                  // getComputedStyle(movie_player)['z-index'], // movie_player is not defined
                  601) + 1};
               }

               /* button */
               ${COMMENTS_SELECTOR}:not(:hover):before {
                  content: "comments ▼";
                  cursor: pointer;
                  visibility: visible;
                  /*transform: rotate(-90deg) translateX(-100%);*/
                  right: 4em;
                  padding: 0 8px 3px;
                  line-height: normal;
                  font-family: Roboto, Arial, sans-serif;
                  font-size: 11px;
                  color: #eee;
                  background: rgba(0,0,0,0.3);
               }

               /* comments section */
               ${COMMENTS_SELECTOR} {
                  margin: 0 1%;
                  padding: 0 15px;
                  background-color: #222;
                  border: 1px solid #333;
                  max-width: 550px;
               }

               ${COMMENTS_SELECTOR}:not(:hover) {
                  visibility: collapse;
               }

               /* comments section hover */
               ${COMMENTS_SELECTOR}:hover {
                  visibility: visible !important;
               }

               /* add scroll option in comments */
               ${COMMENTS_SELECTOR} > #sections > #contents {
                  overflow-y: auto;
                  max-height: 88vh;
                  border-top: 1px solid #333;
                  padding-top: 1em;
               }

               /* hide add comment textarea */
               ${COMMENTS_SELECTOR} #header #simple-box {
                  display: none;
               }

               /* fixs */
               ytd-comments-header-renderer {
                  height: 0;
                  margin-top: 10px;
               }
               #expander.ytd-comment-renderer {
                  overflow-x: hidden;
               }
               /* size section */
               ${COMMENTS_SELECTOR} #sections {
                  max-width: fit-content;
                  min-width: 500px;
               }

               /* custom scroll */
               ${COMMENTS_SELECTOR} #contents::-webkit-scrollbar {
                  height: 8px;
                  width: 10px;
               }

               ${COMMENTS_SELECTOR} #contents::-webkit-scrollbar-button {
                  height: 0;
                  width: 0;
               }

               ${COMMENTS_SELECTOR} #contents::-webkit-scrollbar-corner {
                  background: transparent;
               }

               ${COMMENTS_SELECTOR} #contents::-webkit-scrollbar-thumb {
                  background: #e1e1e1;
                  border: 0;
                  border-radius: 0;
               }

               ${COMMENTS_SELECTOR} #contents::-webkit-scrollbar-track {
                  background: #666;
                  border: 0;
                  border-radius: 0;
               }

               ${COMMENTS_SELECTOR} #contents::-webkit-scrollbar-track:hover {
                  background: #666;
               }`);
         });

   },
});
window.nova_plugins.push({
   id: 'comments-visibility',
   title: 'Collapse comments section',
   'title:zh': '收起评论区',
   'title:ja': 'コメント欄を折りたたむ',
   'title:ko': '댓글 섹션 축소',
   'title:id': 'Ciutkan bagian komentar',
   'title:es': 'Ocultar sección de comentarios',
   'title:pt': 'Recolher seção de comentários',
   'title:fr': 'Réduire la section des commentaires',
   'title:it': 'Comprimi la sezione commenti',
   'title:tr': 'Yorumlar bölümünü daralt',
   'title:de': 'Kommentarbereich minimieren',
   'title:pl': 'Zwiń sekcję komentarzy',
   'title:ua': 'Згорнути розділ коментарів',
   run_on_pages: 'watch, -mobile',
   restart_on_transition: true,
   section: 'comments',
   // desc: '',
   _runtime: user_settings => {

      NOVA.collapseElement({
         selector: '#comments',
         title: 'comments',
         remove: user_settings.comments_visibility_mode == 'disable' ? true : false,
      });

   },
   options: {
      comments_visibility_mode: {
         _tagName: 'select',
         label: 'Mode',
         'label:zh': '模式',
         'label:ja': 'モード',
         'label:ko': '방법',
         // 'label:id': 'Mode',
         'label:es': 'Modo',
         'label:pt': 'Modo',
         // 'label:fr': 'Mode',
         'label:it': 'Modalità',
         'label:tr': 'Mod',
         'label:de': 'Modus',
         'label:pl': 'Tryb',
         'label:ua': 'Режим',
         options: [
            { label: 'collapse', value: 'hide', selected: true, 'label:pl': 'zwiń', 'label:ua': 'сховати' },
            { label: 'remove', value: 'disable', 'label:pl': 'usuń', 'label:ua': 'усунути'},
         ],
      },
   }
});
window.nova_plugins.push({
   id: 'square-avatars',
   title: 'Square avatars',
   'title:zh': '方形头像',
   'title:ja': '正方形のアバター',
   'title:ko': '정사각형 아바타',
   'title:id': 'Avatar persegi',
   'title:es': 'Avatares cuadrados',
   'title:pt': 'Avatares quadrados',
   'title:fr': 'Avatars carrés',
   'title:it': 'Avatar quadrati',
   'title:tr': 'Kare avatarlar',
   'title:de': 'Quadratische Avatare',
   'title:pl': 'Kwadratowe awatary',
   'title:ua': 'Квадратні аватарки',
   run_on_pages: 'all',
   section: 'comments',
   desc: 'Make user images squared',
   'desc:zh': '方形用户形象',
   'desc:ja': 'ユーザー画像を二乗する',
   'desc:ko': '사용자 이미지를 정사각형으로 만들기',
   'desc:id': 'Buat gambar pengguna menjadi persegi',
   // 'desc:es': 'Haz que las imágenes de los usuarios sean cuadradas',
   'desc:pt': 'Torne as imagens do usuário quadradas',
   'desc:fr': 'Rendre les images utilisateur au carré',
   'desc:it': 'Rendi le immagini degli utenti quadrate',
   'desc:tr': 'Kullanıcı resimlerini kare haline getirin',
   'desc:de': 'Machen Sie Benutzerbilder quadriert',
   'desc:pl': 'Awatary użytkowniów będą kwadratowe',
   'desc:ua': 'Зробіть зображення користувачів квадратними',
   _runtime: user_settings => {

      NOVA.css.push(
         [
            'yt-img-shadow',
            '.ytp-title-channel-logo',
            '#player .ytp-title-channel',
            'ytm-profile-icon',

            // after 10.27.22
            'a.ytd-thumbnail',
            // '#description',
            // '.ytd-searchbox', // searchbox
            // '.yt-spec-button-shape-next--size-m', // comment replay, subscribe like , , etc btn

         ]
            .join(',\n') + ` {
               border-radius: 0 !important;
            }`);

   },
});
window.nova_plugins.push({
   id: 'comments-expand',
   title: 'Expand comments',
   'title:zh': '展开评论',
   'title:ja': 'コメントを展開',
   'title:ko': '댓글 펼치기',
   'title:id': 'Perluas komentar',
   'title:es': 'Expandir comentarios',
   'title:pt': 'Expandir comentários',
   'title:fr': 'Développer les commentaires',
   'title:it': 'Espandi i commenti',
   'title:tr': 'Yorumları genişlet',
   'title:de': 'Kommentare erweitern',
   'title:pl': 'Rozwiń komentarze',
   'title:ua': 'Розгорнути коментарі',
   run_on_pages: 'watch, -mobile',
   section: 'comments',
   // desc: '',
   _runtime: user_settings => {

      // Doesn't work. I don't know how to implement it better. By updating "removeEventListener/addEventListener" or reloading the entire comment block
      // dirty fix bug with not updating comments addEventListener: reset comments block
      // document.addEventListener('yt-page-data-updated', () => location.reload());

      NOVA.css.push(
         `/* fixs */
         #expander.ytd-comment-renderer {
            overflow-x: hidden;
         }`);

      // comment
      NOVA.watchElements({
         selectors: ['#contents #expander[collapsed] #more:not([hidden])'],
         attr_mark: 'comment-expanded',
         callback: btn => {
            const moreExpand = () => btn.click();
            const comment = btn.closest('#expander[collapsed]');
            // console.debug('contents expander:', comment);
            // comment.style.border = '2px solid red'; // mark for test

            // on hover auto expand
            switch (user_settings.comments_expand_mode) {
               case 'onhover':
                  comment.addEventListener('mouseenter', moreExpand, { capture: true, once: true });
                  break;

               // case 'always':
               default:
                  moreExpand();
                  break;
            }
         },
      });

      // comment replies
      NOVA.watchElements({
         selectors: ['#more-replies button'],
         attr_mark: 'replies-expanded',
         callback: btn => {
            const moreExpand = () => btn.click();

            // on hover auto expand
            switch (user_settings.comments_view_reply) {
               case 'onhover':
                  btn.addEventListener('mouseenter', moreExpand, { capture: true, once: true });
                  break;

               // case 'always':
               default:
                  moreExpand();
                  break;
            }
         },
      });

      // old method. No hover
      // NOVA.watchElements({
      //    selector: ['#contents #expander[collapsed] #more'],
      //    attr_mark: 'comment-expanded',
      //    callback: btn => btn.click(),
      // });

      // if (user_settings.comments_view_reply) {
      //    NOVA.watchElements({
      //       selector: ['#comment #expander #more-replies'],
      //       attr_mark: 'replies-expanded',
      //       callback: btn => btn.click(),

      //    });
      // }

   },
   options: {
      comments_expand_mode: {
         _tagName: 'select',
         label: 'Expand comment',
         'label:zh': '展开评论',
         'label:ja': 'コメントを展開',
         'label:ko': '댓글 펼치기',
         'label:id': 'Perluas komentar',
         'label:es': 'Expandir comentarios',
         'label:pt': 'Expandir comentário',
         'label:fr': 'Développer les commentaires',
         'label:it': 'Espandi commento',
         'label:tr': 'Yorumu genişlet',
         'label:de': 'Kommentar erweitern',
         'label:pl': 'Rozwiń komentarz',
         'label:ua': 'Розгорнути коментар',
         // title: '',
         options: [
            { label: 'always', value: 'always', selected: true, 'label:ua': 'Завжди', 'label:zh': '每次', 'label:ja': 'いつも', 'label:ko': '언제나', /*'label:id': '',*/ 'label:es': 'siempre', 'label:pt': 'sempre', 'label:fr': 'toujours', /*'label:it': '',*/ 'label:tr': 'her zaman', 'label:de': 'stets', 'label:pl': 'zawsze' },
            { label: 'on hover', value: 'onhover', 'label:ua': 'При наведенні', 'label:zh': '悬停时', 'label:ja': 'ホバー時に', 'label:ko': '호버에',/*'label:id': '',*/ 'label:es': 'en vuelo estacionario', 'label:pt': 'pairando', 'label:fr': 'en vol stationnaire', /*'label:it': '',*/ 'label:tr': 'üzerinde gezinme', 'label:de': 'auf schweben', 'label:pl': 'po najechaniu', },
         ],
      },
      comments_view_reply: {
         _tagName: 'select',
         label: 'Expand reply',
         'label:zh': '展开回复',
         'label:ja': '返信を展開',
         'label:ko': '답장 펼치기',
         'label:id': 'Perluas balasan',
         'label:es': 'Expandir respuesta',
         'label:pt': 'Expandir a resposta',
         'label:fr': 'Développer la réponse',
         'label:it': 'Espandi risposta',
         'label:tr': 'Cevabı genişlet',
         'label:de': 'Antwort erweitern',
         'label:pl': 'Rozwiń odpowiedź',
         'label:ua': 'Розгорнути відповідь',
         // title: '',
         options: [
            { label: 'always', value: 'always', 'label:zh': '每次', 'label:ja': 'いつも', 'label:ko': '언제나', 'label:id': 'selalu', 'label:es': 'siempre', 'label:pt': 'sempre', 'label:fr': 'toujours', 'label:it': 'sempre', 'label:tr': 'her zaman', 'label:de': 'stets', 'label:pl': 'zawsze', 'label:ua': 'Завжди' },
            { label: 'on hover', value: 'onhover', selected: true, 'label:zh': '悬停时', 'label:ja': 'ホバー時に', 'label:ko': '호버에', /*'label:id': '',*/ 'label:es': 'en vuelo estacionario', 'label:pt': 'pairando', 'label:fr': 'en vol stationnaire', /*'label:it': '',*/ 'label:tr': 'üzerinde gezinme', 'label:de': 'auf schweben', 'label:pl': 'przy najechaniu', 'label:ua': 'При наведенні' },
         ],
      },
   }
});
const NOVA = {
   // DEBUG: true,

   // find once.
   // more optimized compared to MutationObserver
   // waitElement(selector = required()) {
   //    this.log('waitElement:', selector);
   //    if (typeof selector !== 'string') return console.error('wait > selector:', typeof selector);

   //    return new Promise((resolve, reject) => {
   //       // try {
   //       let nodeInterval
   //       const checkIfExists = () => {
   //          if (el = document.body.querySelector(selector)) {
   //             if (typeof nodeInterval === 'number') clearInterval(nodeInterval);
   //             resolve(el);

   //          } else return;
   //       }
   //       checkIfExists();
   //       nodeInterval = setInterval(checkIfExists, 50); // ms
   //       // } catch (err) { // does not output the reason/line to the stack
   //       //    reject(new Error('Error waitElement', err));
   //       // }
   //    });
   // },

   // untilDOM
   waitElement(selector = required(), container) {
      if (typeof selector !== 'string') return console.error('wait > selector:', typeof selector);
      if (container && !(container instanceof HTMLElement)) return console.error('wait > container not HTMLElement:', container);
      // console.debug('waitElement:', selector);

      // https://stackoverflow.com/a/68262400
      // best https://codepad.co/snippet/wait-for-an-element-to-exist-via-mutation-observer
      // alt:
      // https://git.io/waitForKeyElements.js
      // https://github.com/fuzetsu/userscripts/tree/master/wait-for-elements
      // https://github.com/CoeJoder/waitForKeyElements.js/blob/master/waitForKeyElements.js
      // https://gist.githubusercontent.com/sidneys/ee7a6b80315148ad1fb6847e72a22313/raw/

      // There is a more correct method - transitionend.
      // https://developer.mozilla.org/en-US/docs/Web/API/HTMLElement/transitionend_event
      // But this requires a change in the logic of the current implementation. It will also complicate the restoration of the expansion if in the future, if YouTube replaces logic.

      return new Promise(resolve => {
         if (element = (container || document.body || document).querySelector(selector)) {
            // console.debug('[1]', selector);
            return resolve(element);
         }

         new MutationObserver((mutations, observer) => {
            for (let mutation of mutations) {
               for (const node of mutation.addedNodes) {
                  if (![1, 3, 8].includes(node.nodeType)) continue; // speedup hack

                  if (node.matches && node.matches(selector)) { // this node
                     // console.debug('[2]', mutation.type, node.nodeType, selector);
                     observer.disconnect();
                     return resolve(node);

                  } else if ( // inside node
                     (parentEl = node.parentElement || node)
                     && (parentEl instanceof HTMLElement)
                     && (element = parentEl.querySelector(selector))
                  ) {
                     // console.debug('[3]', mutation.type, node.nodeType, selector);
                     observer.disconnect();
                     return resolve(element);
                  }
               }
            }
            // after loop
            if (document?.readyState != 'loading' // fix slowdown page
               && (element = (container || document?.body || document).querySelector(selector))
            ) { // in global
               // console.debug('[4]', selector);
               observer.disconnect();
               return resolve(element);
            }
         })
            .observe(container || document.body || document.documentElement || document, {
               childList: true, // observe direct children
               subtree: true, // and lower descendants too
            });
      });
   },

   /** wait for every DOM change until a condition becomes true */
   // await NOVA.waitUntil(?, 500) // 500ms
   async waitUntil(condition = required(), timeout = 100) {
      if (typeof condition !== 'function') return console.error('waitUntil > condition is not fn:', typeof condition);

      return new Promise((resolve) => {
         if (result = condition()) {
            // console.debug('waitUntil[1]', result, condition, timeout);
            resolve(result);

         } else {
            const interval = setInterval(() => {
               if (result = condition()) {
                  // console.debug('waitUntil[2]', result, condition, timeout);
                  clearInterval(interval);
                  resolve(result);
               }
               // console.debug('waitUntil[3]', result, condition, timeout);
            }, timeout);
         }
      });
   },

   async sleep(timeout = 100) {
      return new Promise(resolve => setTimeout(resolve, timeout));
   },

   watchElements_list: {}, // can to stop watch setInterval
   // complete doesn't work
   // clear_watchElements(name = required()) {
   //    return this.watchElements_list.hasOwnProperty(name)
   //       && clearInterval(this.watchElements_list[name])
   //       && delete this.watchElements_list[name];
   // },

   watchElements({ selectors = required(), attr_mark, callback = required() }) {
      // console.debug('watch', selector);
      if (!Array.isArray(selectors) && typeof selectors !== 'string') return console.error('watch > selector:', typeof selectors);
      if (typeof callback !== 'function') return console.error('watch > callback:', typeof callback);

      // async wait el. Removes the delay for init
      this.waitElement(typeof selectors === 'string' ? selectors : selectors.join(','))
         .then(video => {
            // selectors - str to array
            !Array.isArray(selectors) && (selectors = selectors.split(',').map(s => s.trim()));

            process(); // launch without waiting
            // if (attr_mark) {
            this.watchElements_list[attr_mark] = setInterval(() =>
               document.visibilityState == 'visible' && process(), 1000 * 1.5); // 1.5 sec
            // }

            function process() {
               // console.debug('watch.process', { selector, callback });
               selectors
                  .forEach(selectorItem => {
                     if (attr_mark) selectorItem += `:not([${attr_mark}])`;
                     // if ((slEnd = ':not([hidden])') && !selectorItem.endsWith(slEnd)) {
                     //    selectorItem += slEnd;
                     // }
                     // console.debug('selectorItem', selectorItem);

                     document.body.querySelectorAll(selectorItem)
                        .forEach(el => {
                           // if (el.offsetWidth > 0 || el.offsetHeight > 0) { // el.is(":visible")
                           // console.debug('watch.process.viewed', selectorItem);
                           if (attr_mark) el.setAttribute(attr_mark, true);
                           callback(el);
                           // }
                        });
                  });
            }
         });

   },

   css: {
      push(css = required(), selector, important) {
         // console.debug('css\n', ...arguments);
         if (typeof css === 'object') {
            if (!selector) return console.error('injectStyle > empty json-selector:', ...arguments);

            // if (important) {
            injectCss(selector + json2css(css));
            // } else {
            //    Object.assign(document.body.querySelector(selector).style, css);
            // }

            function json2css(obj) {
               let css = '';
               Object.entries(obj)
                  .forEach(([key, value]) => {
                     css += key + ':' + value + (important ? ' !important' : '') + ';';
                  });
               return `{ ${css} }`;
            }

         } else if (css && typeof css === 'string') {
            if (document.head) {
               injectCss(css);

            } else {
               window.addEventListener('load', () => injectCss(css), { capture: true, once: true });
            }

         } else {
            console.error('addStyle > css:', typeof css);
         }

         function injectCss(source = required()) {
            let sheet;

            if (source.endsWith('.css')) {
               sheet = document.createElement('link');
               sheet.rel = 'sheet';
               sheet.href = source;

            } else {
               const sheetId = 'NOVA-style';
               sheet = document.getElementById(sheetId) || (function () {
                  const style = document.createElement('style');
                  style.type = 'text/css';
                  style.id = sheetId;
                  return document.head.appendChild(style);
               })();
            }

            sheet.textContent += '/**/\n' + source
               .replace(/\n+\s{2,}/g, ' ') // singleline format
               // multiline format
               // .replace(/\n+\s{2,}/g, '\n\t')
               // .replace(/\t\}/mg, '}')
               + '\n';
            // sheet.insertRule(css, sheet.cssRules.length);
            // (document.head || document.documentElement).append(sheet);
            // document.adoptedStyleSheets.push(newSheet); // v99+

            // sheet.onload = () => NOVA.log('style loaded:', sheet.src || sheet || sheet.textContent.substr(0, 100));
         }
      },

      // https://developer.mozilla.org/ru/docs/Web/API/CSSStyleDeclaration
      // HTMLElement.prototype.getIntValue = () {}
      // const { position, right, bottom, zIndex, boxShadow } = window.getComputedStyle(container); // multiple
      getValue(selector = required(), prop_name = required()) {
         return (el = document.body?.querySelector(selector))
            ? getComputedStyle(el).getPropertyValue(prop_name) : null; // for some callback functions (Match.max) return "undefined" is not valid
      },
   },

   // cookie: {
   //    get(name = required()) {
   //       return Object.fromEntries(
   //          document.cookie
   //             .split(/; */)
   //             .map(c => {
   //                const [key, ...v] = c.split('=');
   //                return [key, decodeURIComponent(v.join('='))];
   //             })
   //       )[name];
   //    },

   //    set(name = required(), value, days = 90) { // 90 days
   //       if (this.get(name) == value) return;

   //       let date = new Date();
   //       date.setTime(date.getTime() + 3600000 * 24 * days); // m*h*d

   //       document.cookie = Object.entries({
   //          [encodeURIComponent(name)]: value,
   //          // domain: '.' + location.hostname.split('.').slice(-2).join('.'),  // "www.youtube.com" => ".youtube.com"
   //          domain: location.hostname,
   //          expires: date.toUTCString(),
   //          path: '/', // what matters at the end
   //       })
   //          .map(([key, value]) => `${key}=${value}`).join('; '); // if no "value" = undefined

   //       console.assert(this.get(name) == value, 'cookie set err:', ...arguments, document.cookie);
   //    },

   //    getParamLikeObj(name = required()) {
   //       return Object.fromEntries(
   //          this.get(name)
   //             ?.split(/&/)
   //             .map(c => {
   //                const [key, ...v] = c.split('=');
   //                return [key, decodeURIComponent(v.join('='))];
   //             }) || []
   //       );
   //    },

   //    updateParam({ key = required(), param = required(), value = required() }) {
   //       let paramsObj = this.getParamLikeObj(key) || {};

   //       if (paramsObj[param] != value) {
   //          paramsObj[param] = value;
   //          this.set(key, NOVA.queryURL.set(paramsObj).split('?').pop());
   //          location.reload();
   //       }
   //    },
   // },

   /* NOVA.collapseElement({
         selector: '#secondary #related',
         title: 'related',// auto uppercase
         remove: true,
         remove: user_settings.NAME_visibility_mode == 'remove' ? true : false,
   }); */
   collapseElement({ selector = required(), title = required(), remove }) {
      // console.debug('collapseElement', ...arguments);
      const selector_id = `${title.match(/[a-z]+/gi).join('')}-prevent-load-btn`;

      this.waitElement(selector.toString())
         .then(el => {
            if (remove) el.remove();
            else {
               if (document.getElementById(selector_id)) return;
               // el.style.visibility = 'hidden'; // left scroll space
               el.style.display = 'none';
               // create button
               const btn = document.createElement('a');
               btn.textContent = `Load ${title}`;
               btn.id = selector_id;
               btn.className = 'more-button style-scope ytd-video-secondary-info-renderer';
               // btn.className = 'ytd-vertical-list-renderer';
               Object.assign(btn.style, {
                  cursor: 'pointer',
                  'text-align': 'center',
                  'text-transform': 'uppercase',
                  display: 'block',
                  color: 'var(--yt-spec-text-secondary)',
               });
               btn.addEventListener('click', () => {
                  btn.remove();
                  // el.style.visibility = 'visible'; // left scroll space
                  el.style.display = 'unset';
                  window.dispatchEvent(new Event('scroll')); // need to "comments-visibility" (https://stackoverflow.com/a/68202306)
               });
               el.before(btn);
            }
         });
   },

   calculateAspectRatioFit({
      srcWidth = 0, srcHeight = 0,
      maxWidth = window.innerWidth,
      maxHeight = window.innerHeight
   }) {
      // console.debug('aspectRatioFit:', ...arguments);
      const aspectRatio = Math.min(+maxWidth / +srcWidth, +maxHeight / +srcHeight);
      return {
         width: +srcWidth * aspectRatio,
         height: +srcHeight * aspectRatio,
      };
   },

   bezelTrigger(text) {
      // console.debug('bezelTrigger', ...arguments);
      if (!text) return;
      if (typeof this.fateBezel === 'number') clearTimeout(this.fateBezel); // reset hide
      const bezelEl = document.body.querySelector('.ytp-bezel-text');
      if (!bezelEl) return console.warn(`bezelTrigger ${text}=>${bezelEl}`);

      const
         bezelConteiner = bezelEl.parentElement.parentElement,
         CLASS_VALUE_TOGGLE = 'ytp-text-root';

      if (!this.bezel_css_inited) {
         this.bezel_css_inited = true;
         this.css.push(
            `.${CLASS_VALUE_TOGGLE} { display: block !important; }
            .${CLASS_VALUE_TOGGLE} .ytp-bezel-text-wrapper {
               pointer-events: none;
               z-index: 40 !important;
            }
            .${CLASS_VALUE_TOGGLE} .ytp-bezel-text { display: inline-block !important; }
            .${CLASS_VALUE_TOGGLE} .ytp-bezel { display: none !important; }`);
      }

      bezelEl.textContent = text;
      bezelConteiner.classList.add(CLASS_VALUE_TOGGLE);

      this.fateBezel = setTimeout(() => {
         bezelConteiner.classList.remove(CLASS_VALUE_TOGGLE);
         bezelEl.textContent = ''; // fix not showing bug when frequent calls
      }, 600); // 600ms
   },

   getChapterList(video_duration = required()) {
      let timestampsCollect = [];
      let prevSec = -1;

      // description and first(pinned) comment
      document.body.querySelectorAll(
         // `#primary-inner #description (old, has a bug with several hidden instances),
         // `#description.ytd-watch-metadata (invalid due to formatting [since 9 nov 2022]),
         `ytd-watch, ytd-watch-flexy,
         #comments ytd-comment-thread-renderer:first-child #content`)
         .forEach(el => {
             // exclude embed page
            (el.playerData?.videoDetails.shortDescription || el.textContent)
               ?.split('\n')
               .forEach(line => {
                  line = line?.toString().trim(); // clear space
                  if (line.length > 5 && line.length < 200 && (timestamp = /((\d?\d:){1,2}\d{2})/g.exec(line))) {
                     // console.debug('line', line);
                     timestamp = timestamp[0]; // ex:"0:00"
                     const
                        sec = this.timeFormatTo.hmsToSec(timestamp),
                        timestampPos = line.indexOf(timestamp);

                     if (sec > prevSec && sec < +video_duration
                        // not in the middle of the line
                        && (timestampPos < 5 || (timestampPos + timestamp.length) === line.length)
                     ) {
                        // const prev = arr[i-1] || -1; // needs to be called "hmsToSecondsOnly" again. What's not optimized
                        prevSec = sec;
                        timestampsCollect.push({
                           'sec': sec,
                           'time': timestamp,
                           'title': line
                              .replace(timestamp, '')
                              .trim().replace(/^[:\-–—|]|(\[\])?|[:\-–—.;|]$/g, '') // clear of quotes and list characters
                              //.trim().replace(/^([:\-–—|]|(\d+[\.)]))|(\[\])?|[:\-–—.;|]$/g, '') // clear numeric list prefix
                              // ^[\"(]|[\")]$ && .trim().replace(/^[\"(].*[\")]$/g, '') // quote stripping example - "text"
                              .trim()
                        });
                     }
                  }
               });
         });

      if (timestampsCollect.length) {
         // console.debug('timestampsCollect', timestampsCollect);
         return timestampsCollect;
      }
   },

   // there are problems with the video https://www.youtube.com/watch?v=SgQ_Jk49FRQ. Too lazy to continue testing because it is unclear which method is more optimal.
   // getChapterList(video_duration = required()) {
   //    const selectorLinkTimestamp = 'a[href*="&t="]';
   //    let timestampList = [];
   //    let prevSec = -1;

   //    document.body.querySelectorAll(`#description.ytd-watch-metadata ${selectorLinkTimestamp}, #contents ytd-comment-thread-renderer:first-child #content ${selectorLinkTimestamp}`)
   //       .forEach((link, i, arr) => {
   //          // const prev = arr[i-1] || -1; // needs to be called "hmsToSecondsOnly" again. What's not optimized
   //          const sec = parseInt(this.queryURL.get('t', link.href));
   //          if (sec > prevSec && sec < +video_duration) {
   //             prevSec = sec;
   //             // will be skip - time: '0:00'
   //             timestampList.push({
   //                // num: ++i,
   //                sec: sec,
   //                time: link.textContent,
   //                title: link.parentElement.textContent
   //                   .split('\n')
   //                   .find(line => line.includes(link.textContent))
   //                   .replaceAll(link.textContent, '')
   //                   .trim()
   //                   .replace(/(^[:\-–—]|[:\-–—.;]$)/g, '')
   //                   .trim()
   //             });
   //          }
   //       });
   //    console.debug('timestampList', timestampList);

   //    if (timestampList?.length > 1) { // clear from "lying timestamp"
   //       return timestampList.filter(i => i.title.length < 80);
   //    }
   // },

   // findTimestamps(text) {
   //    const result = []
   //    const timestampPattern = /((\d?\d:){1,2}\d{2})/g
   //    let match
   //    while ((match = timestampPattern.exec(text))) {
   //       result.push({
   //          from: match.index,
   //          to: timestampPattern.lastIndex
   //       })
   //    }
   //    return result
   // },

   // dateFormatter
   timeFormatTo: {
      hmsToSec(str) { // format out "h:mm:ss" > "sec"
         // str = ':00:00am'; // for test
         if ((arr = str?.split(':')) && arr.length) {
            return arr.reduce((acc, time) => (60 * acc) + +time);
         }
      },

      HMS: {
         // 65.77 % slower
         // digit(ts = required()) { // format out "h:mm:ss"
         //    const
         //       ts = Math.abs(+ts),
         //       days = Math.floor(ts / 86400);

         //    let t = new Date(ts).toISOString();
         //    if (ts < 3600000) t = t.substr(14, 5); // add hours
         //    else t = t.substr(11, 8); // only minutes

         //    return (days ? `${days}d ` : '') + t;
         // },
         digit(time_sec = required()) { // format out "h:mm:ss"
            const
               ts = Math.abs(+time_sec),
               d = ~~(ts / 86400),
               h = ~~((ts % 86400) / 3600),
               m = ~~((ts % 3600) / 60),
               // min = ~~(Math.log(sec) / Math.log(60)), // after sec
               s = Math.floor(ts % 60);

            return (d ? `${d}d ` : '')
               + (h ? (d ? h.toString().padStart(2, '0') : h) + ':' : '')
               + (h ? m.toString().padStart(2, '0') : m) + ':'
               + s.toString().padStart(2, '0');

            // 84% slower
            // return (days && !isNaN(days) ? `${days}d ` : '')
            //    + [hours, minutes, seconds]
            //       .filter(i => +i && !isNaN(i))
            //       .map((item, idx) => idx ? item.toString().padStart(2, '0') : item) // "1:2:3" => "1:02:03"
            //       .join(':'); // format "h:m:s"
         },

         abbr(time_sec = required()) { // format out "999h00m00s"
            const
               ts = Math.abs(+time_sec),
               d = ~~(ts / 86400),
               h = ~~((ts % 86400) / 3600),
               m = ~~((ts % 3600) / 60),
               // min = ~~(Math.log(sec) / Math.log(60)), // after sec
               s = Math.floor(ts % 60);

            return (d ? `${d}d ` : '')
               + (h ? (d ? h.toString().padStart(2, '0') : h) + 'h' : '')
               + (m ? (h ? m.toString().padStart(2, '0') : m) + 'm' : '')
               + (s ? (m ? s.toString().padStart(2, '0') : s) + 's' : '');
            // 78.48% slower
            // return (days ? `${days}d ` : '')
            //    + [seconds, minutes, hours]
            //       .filter(i => +i && !isNaN(i))
            //       .map((item, idx, arr) => (arr.length - 1 !== idx ? item.toString().padStart(2, '0') : item) + ['s', 'm', 'h'][idx])
            //       .reverse()
            //       .join(''); // format "999h00m00s"
         },
      },
   },

   queryURL: {
      // const videoId = new URLSearchParams(window.location.search).get('v');
      // get: (query, url) => new URLSearchParams((url ? new URL(url) : location.href || document.URL).search).get(query),
      // has: (query = required(), url_string) => new URLSearchParams((url_string ? new URL(url_string) : location.href)).has(query), // Doesn't work

      has: (query = required(), url_string) => new URL(url_string || location).searchParams.has(query.toString()),

      get: (query = required(), url_string) => new URL(url_string || location).searchParams.get(query.toString()),

      set(query_obj = {}, url_string) {
         // console.log('queryURL.set:', ...arguments);
         if (!Object.keys(query_obj).length) return console.error('query_obj:', query_obj)
         const url = new URL(url_string || location);
         Object.entries(query_obj).forEach(([key, value]) => url.searchParams.set(key, value));
         return url.toString();
      },

      remove(query = required(), url_string) {
         const url = new URL(url_string || location);
         url.searchParams.delete(query.toString());
         return url.toString();
      },
   },

   request: {

      API_STORE_NAME: 'YOUTUBE_API_KEYS',

      async API({ request, params, api_key }) {
         // NOVA.log('request.API:', ...arguments); // err
         // console.debug('API:', ...arguments);
         // get API key
         const YOUTUBE_API_KEYS = localStorage.hasOwnProperty(this.API_STORE_NAME) ? JSON.parse(localStorage.getItem(this.API_STORE_NAME)) : await this.keys();

         if (!api_key && (!Array.isArray(YOUTUBE_API_KEYS) || !YOUTUBE_API_KEYS?.length)) {
            localStorage.hasOwnProperty(this.API_STORE_NAME) && localStorage.removeItem(this.API_STORE_NAME);
            // alert('I cannot access the API key.'
            //    + '\nThe plugins that depend on it have been terminated.'
            //    + "\n - Check your network's access to Github"
            //    + '\n - Generate a new private key'
            //    + '\n - Deactivate plugins that need it'
            // );
            // throw new Error('YOUTUBE_API_KEYS is empty:', YOUTUBE_API_KEYS);
            return console.error('YOUTUBE_API_KEYS empty:', YOUTUBE_API_KEYS);
         }

         const referRandKey = arr => api_key || 'AIzaSy' + arr[Math.floor(Math.random() * arr.length)];
         // combine GET
         const query = (request == 'videos' ? 'videos' : 'channels') + '?'
            + Object.keys(params)
               .map(k => encodeURIComponent(k) + '=' + encodeURIComponent(params[k]))
               .join('&');

         const URL = `https://www.googleapis.com/youtube/v3/${query}&key=` + referRandKey(YOUTUBE_API_KEYS);
         // console.debug('URL', URL);
         // request
         return await fetch(URL)
            .then(response => response.json())
            .then(json => {
               if (!json?.error && Object.keys(json).length) return json;
               console.warn('used key:', NOVA.queryURL.get('key', URL));
               throw new Error(JSON.stringify(json?.error));
            })
            .catch(error => {
               localStorage.removeItem(this.API_STORE_NAME);
               console.error(`Request API failed:${URL}\n${error}`);
               // alert('Problems with the YouTube API:'
               //    + '\n' + error?.message
               //    + '\n\nIf this error is repeated:'
               //    + '\n - Disconnect the plugins that need it'
               //    + '\n - Update your YouTube API KEY');
            });
      },

      async keys() {
         NOVA.log('request.API: fetch to youtube_api_keys.json');
         // see https://gist.github.com/raingart/ff6711fafbc46e5646d4d251a79d1118/
         return await fetch('https://gist.githubusercontent.com/raingart/ff6711fafbc46e5646d4d251a79d1118/raw/youtube_api_keys.json')
            .then(res => res.text())
            .then(keys => { // save
               NOVA.log(`get and save keys in localStorage`, keys);
               localStorage.setItem(this.API_STORE_NAME, keys);
               return JSON.parse(keys);
            })
            .catch(error => { // clear
               localStorage.removeItem(this.API_STORE_NAME);
               throw error;
               // throw new Error(error);
            })
            .catch(reason => console.error('Error get keys:', reason)); // warn
      },
   },

   getPlayerState(state) {
      // movie_player.getPlayerState() === 2 // 2: PAUSED
      // NOVA.getPlayerState() == 'PLAYING'
      // movie_player.addEventListener('onStateChange', state => 'PLAYING' == NOVA.getPlayerState(state));
      return {
         '-1': 'UNSTARTED',
         0: 'ENDED',
         1: 'PLAYING',
         2: 'PAUSED',
         3: 'BUFFERING',
         5: 'CUED'
      }[state || movie_player.getPlayerState()];
   },

   // captureActiveVideoElement
   videoElement: (() => {
      const videoSelector = '#movie_player:not(.ad-showing) video';
      // init
      document.addEventListener('canplay', ({ target }) => {
         target.matches(videoSelector) && (NOVA.videoElement = target);
      }, { capture: true, once: true });
      // update
      document.addEventListener('play', ({ target }) => {
         target.matches(videoSelector) && (NOVA.videoElement = target);
      }, true);
      // document.dispatchEvent(new CustomEvent('nova-video-loaded'));
   })(),

   async getChannelId(api_key) {
      const isChannelId = id => id && /UC([a-z0-9-_]{22})$/i.test(id);
      // local search
      let result = [
         // global
         document.querySelector('meta[itemprop="channelId"][content]')?.content,
         // channel page
         (document.body.querySelector('ytd-app')?.__data?.data?.response
            || document.body.querySelector('ytd-app')?.data?.response
            || window.ytInitialData
         )
            ?.metadata?.channelMetadataRenderer?.externalId,
         document.querySelector('link[itemprop="url"][href]')?.href.split('/')[4],
         location.pathname.split('/')[2],
         // playlist page
         document.body.querySelector('#video-owner a[href]')?.href.split('/')[4],
         document.body.querySelector('a.ytp-ce-channel-title[href]')?.href.split('/')[4],
         // watch page
         document.body.querySelector('ytd-watch, ytd-watch-flexy')?.playerData?.videoDetails.channelId, // exclude embed page
         // document.body.querySelector('#owner #channel-name a[href]')?.href.split('/')[4], // outdated
         // ALL BELOW - not updated after page transition!
         // || window.ytplayer?.config?.args.ucid
         // || window.ytplayer?.config?.args.raw_player_response.videoDetails.channelId
         // || document.body.querySelector('ytd-player')?.player_.getCurrentVideoConfig()?.args.raw_player_response.videoDetails.channelId
      ]
         .find(i => isChannelId(i))
      // console.debug('channelId (local):', result);

      if (!result) { // request
         let channelName;
         switch (this.currentPage) {
            case 'channel':
               channelLink = location.pathname.split('/');
               if (['c', 'user'].includes(channelLink[1])) {
                  channelName = channelLink[2];
               }
               break;
            case 'watch':
               channelLink = await this.waitElement('#owner #channel-name a[href]');
               channelArr = channelLink?.href.split('/');
               if (channelArr.length && ['c', 'user'].includes(channelArr[3])) {
                  channelName = channelArr[4];
               }
               break;
         }
         // console.debug('channelName:', channelName);
         if (!channelName) return
         // https://www.googleapis.com/youtube/v3/channels?key={YOUR_API_KEY}&forUsername={USER_NAME}&part=id
         const res = await this.request.API({
            request: 'channels',
            params: { 'forUsername': channelName, 'part': 'id' },
            api_key: api_key,
         });
         // console.debug('res', res);
         if (res?.items?.length && isChannelId(res.items[0]?.id)) result = res.items[0].id;
         // console.debug('channelId (request):', result);
      }
      return result;
   },

   log() {
      if (this.DEBUG && arguments.length) {
         console.groupCollapsed(...arguments);
         console.trace();
         console.groupEnd();
      }
   }
}
window.nova_plugins.push({
   id: 'video-description-expand',
   title: 'Expand description',
   'title:zh': '展开说明',
   'title:ja': '説明を展開',
   'title:ko': '설명 펼치기',
   'title:id': 'Perluas deskripsi',
   'title:es': 'Ampliar descripción',
   'title:pt': 'Expandir descrição',
   'title:fr': 'Développer la description',
   'title:it': 'Espandi la descrizione',
   'title:tr': 'Açıklamayı genişlet',
   'title:de': 'Beschreibung erweitern',
   'title:pl': 'Rozwiń opis',
   'title:ua': 'Розширити опис',
   run_on_pages: 'watch, -mobile',
   // restart_on_transition: true,
   section: 'details',
   // desc: '',
   _runtime: user_settings => {

      if (user_settings['description-popup']) return; // conflict with plugin

      // Doesn't work after page transition
      // NOVA.waitElement('#meta [collapsed] #more, [description-collapsed] #description #expand')
      //    .then(btn => {
      //       if (user_settings.description_expand_mode == 'onhover') {
      //          btn.addEventListener('mouseenter', ({ target }) => target.click(), { capture: true, once: true });
      //       }
      //       // else if (user_settings.description_expand_mode == 'always') {
      //       else {
      //          btn.click();
      //       }
      //    });

      // const ATTR_MARK = 'nove-description-expand';

      NOVA.watchElements({
         selectors: [
            '#meta [collapsed] #more',
            '[description-collapsed] #description #expand',
         ],
         // attr_mark: ATTR_MARK,
         callback: btn => {
            if (user_settings.description_expand_mode == 'onhover') {
               btn.addEventListener('mouseenter', ({ target }) => target.click(), { capture: true, once: true });
            }
            // else if (user_settings.description_expand_mode == 'always') {
            else {
               btn.click();
            }
            // NOVA.clear_watchElements(ATTR_MARK);
         }

      });

   },
   options: {
      description_expand_mode: {
         _tagName: 'select',
         label: 'Mode',
         'label:zh': '模式',
         'label:ja': 'モード',
         'label:ko': '방법',
         // 'label:id': 'Mode',
         'label:es': 'Modo',
         'label:pt': 'Modo',
         // 'label:fr': 'Mode',
         'label:it': 'Modalità',
         'label:tr': 'Mod',
         'label:de': 'Modus',
         'label:pl': 'Tryb',
         // title: '',
         'label:ua': 'Режим',
         options: [
            { label: 'always', value: 'always', selected: true, 'label:zh': '每次', 'label:ja': 'いつも', 'label:ko': '언제나', 'label:id': 'selalu', 'label:es': 'siempre', 'label:pt': 'sempre', 'label:fr': 'toujours', 'label:it': 'sempre', 'label:tr': 'her zaman', 'label:de': 'stets', 'label:pl': 'zawsze', 'label:ua': 'Завжди' },
            { label: 'on hover', value: 'onhover', 'label:zh': '悬停时', 'label:ja': 'ホバー時に', 'label:ko': '호버에', /*'label:id': '',*/ 'label:es': 'en vuelo estacionario', 'label:pt': 'pairando', 'label:fr': 'En vol stationnaire', /*'label:it': '',*/ 'label:tr': 'üzerinde gezinme', 'label:de': 'auf schweben', 'label:pl': 'po najechaniu', 'label:ua': 'При наведенні' },
         ],
      },
   }
});
window.nova_plugins.push({
   id: 'channel-videos-count',
   title: 'Show channel videos count',
   'title:zh': '显示频道上的视频数量',
   'title:ja': 'チャンネルの動画数を表示する',
   'title:ko': '채널 동영상 수 표시',
   'title:id': 'Tampilkan jumlah video saluran',
   'title:es': 'Mostrar recuento de videos del canal',
   'title:pt': 'Mostrar contagem de vídeos do canal',
   'title:fr': 'Afficher le nombre de vidéos de la chaîne',
   'title:it': 'Mostra il conteggio dei video del canale',
   'title:tr': 'Kanal video sayısını göster',
   'title:de': 'Anzahl der Kanalvideos anzeigen',
   'title:pl': 'Pokaż liczbę filmów na kanale',
   'title:ua': 'Показати кількість відео на каналі',
   run_on_pages: 'watch, channel',
   restart_on_transition: true,
   section: 'details',
   opt_api_key_warn: true,
   desc: 'Display uploaded videos on channel',
   'desc:zh': '在频道上显示上传的视频',
   'desc:ja': 'アップロードした動画をチャンネルに表示',
   'desc:ko': '채널에 업로드된 동영상 표시',
   'desc:id': 'Tampilkan video yang diunggah di saluran',
   'desc:es': 'Mostrar videos subidos en el canal',
   'desc:pt': 'Exibir vídeos enviados no canal',
   'desc:fr': 'Afficher les vidéos mises en ligne sur la chaîne',
   'desc:it': 'Visualizza i video caricati sul canale',
   'desc:tr': 'Yüklenen videoları kanalda göster',
   'desc:de': 'Hochgeladene Videos auf dem Kanal anzeigen',
   'desc:pl': 'Wyświetla przesłane filmy na kanale',
   'desc:ua': 'Показує завантажені відео на каналі',
   _runtime: user_settings => {

      const
         CACHE_PREFIX = 'nova-channel-videos-count:',
         SELECTOR_ID = 'nova-video-count';

      switch (NOVA.currentPage) {
         case 'watch':
            // NOVA.waitElement('#upload-info #channel-name a[href], ytm-slim-owner-renderer a[href]')
            //    .then(link => {
            //       // console.debug('watch page');
            //       NOVA.waitElement('#upload-info #owner-sub-count, ytm-slim-owner-renderer .subhead') // possible positional problems
            //          // NOVA.waitElement('#owner-sub-count:not([hidden]):not(:empty)') // does not display when the number of subscribers is hidden
            //          .then(el => {
            //             if (el.hasAttribute('hidden')) el.removeAttribute('hidden'); // remove hidden attribute

            //             setVideoCount({
            //                'container': el,
            //                'channel_id': new URL(link.href).pathname.split('/')[2],
            //             });
            //          });
            //    });
            // break;

            NOVA.waitElement('#upload-info #owner-sub-count, ytm-slim-owner-renderer .subhead')
               .then(el => setVideoCount(el));
            break;

         case 'channel':
            NOVA.waitElement('#channel-header #subscriber-count, .c4-tabbed-header-subscriber-count') // possible positional problems
               // NOVA.waitElement('#channel-header #subscriber-count:not(:empty)') // does not display when the number of subscribers is hidden
               .then(el => setVideoCount(el));
            break;
      }

      async function setVideoCount(container = required()) {
         // console.debug('setVideoCount:', ...arguments);
         const channelId = await NOVA.getChannelId(user_settings['user-api-key']);
         if (!channelId) return console.error('setVideoCount channelId: empty', channelId);

         // has in cache
         if (storage = sessionStorage.getItem(CACHE_PREFIX + channelId)) {
            insertToHTML({ 'text': storage, 'container': container });

         } else {
            NOVA.request.API({
               request: 'channels',
               params: { 'id': channelId, 'part': 'statistics' },
               api_key: user_settings['user-api-key'],
            })
               .then(res => {
                  res?.items?.forEach(item => {
                     if (videoCount = +item.statistics.videoCount) {
                        insertToHTML({ 'text': videoCount, 'container': container });
                        // save cache in tabs
                        sessionStorage.setItem(CACHE_PREFIX + channelId, videoCount);

                     } else console.warn('API is change', item);
                  });
               });
         }

         function insertToHTML({ text = '', container = required() }) {
            // console.debug('insertToHTML', ...arguments);
            if (!(container instanceof HTMLElement)) return console.error('container not HTMLElement:', container);

            (document.getElementById(SELECTOR_ID) || (function () {
               container.insertAdjacentHTML('beforeend',
                  `<span class="date style-scope ytd-video-secondary-info-renderer" style="margin-right:5px;"> • <span id="${SELECTOR_ID}">${text}</span> videos</span>`);
               return document.getElementById(SELECTOR_ID);
            })())
               .textContent = text;

            container.title = `${text} videos`;
         }

      }

   },
});
// for test:
// https://www.youtube.com/watch?v=IvZOmE36PLc - many extra characters. Manual chapter numbering
// https://www.youtube.com/watch?v=IR0TBQV147I = lots 3-digit timestamp

window.nova_plugins.push({
   id: 'description-timestamps-scroll',
   title: 'No scroll to player on timestamps',
   'title:zh': '没有在时间戳上滚动到播放器',
   'title:ja': 'タイムスタンプでプレーヤーにスクロールしない',
   'title:ko': '타임스탬프에서 플레이어로 스크롤하지 않음',
   'title:id': 'Tidak ada gulir ke pemain pada stempel waktu',
   'title:es': 'Sin desplazamiento al jugador en marcas de tiempo',
   'title:pt': 'Sem rolar para o jogador em timestamps',
   'title:fr': 'Pas de défilement vers le joueur sur les horodatages',
   'title:it': 'Nessun passaggio al giocatore sui timestamp',
   'title:tr': 'Zaman damgalarında oynatıcıya kaydırma yok',
   'title:de': 'Kein Scrollen zum Player bei Zeitstempeln',
   'title:pl': 'Brak przejścia do odtwarzacza na znacznikach czasu',
   'title:ua': 'Немає прокрутки до відтворювача на часових мітках',
   run_on_pages: 'watch, -mobile',
   section: 'details',
   desc: 'Disable scrolling to player when clicking on timestamps',
   'desc:pl': 'Wyłącza przewijanie do odtwarzacza podczas klikania znaczników czasu',
   'desc:ua': 'Вимикає прокрутку до відтворювача при натисканні на часову мітку',
   _runtime: user_settings => {

      // alt - https://greasyfork.org/en/scripts/438943-youtube-no-scroll-to-top-on-timestamps
      document.addEventListener('click', evt => {
         // <a href="/playlist?list=XX"> - erroneous filtering "t=XX" without the character "&"
         if (!evt.target.matches('a[href*="&t="]')) return;

         if (sec = NOVA.timeFormatTo.hmsToSec(evt.target.textContent)) {
            evt.preventDefault();
            evt.stopPropagation();
            evt.stopImmediatePropagation();

            // NOVA.videoElement?.currentTime = sec;
            movie_player.seekTo(sec);
         }
      }, { capture: true });

   },
});
// for test:
// https://www.youtube.com/watch?v=FSjr2H0RDsY - empty desc
// https://www.youtube.com/watch?v=CV_BR1tfdCo - empty desc
// https://www.youtube.com/watch?v=EZAr3jrPqR8 - boken "restoreDateLine"

window.nova_plugins.push({
   id: 'description-popup',
   title: 'Description section in popup',
   'title:zh': '弹出窗口中的描述部分',
   'title:ja': 'ポップアップの説明セクション',
   'title:ko': '팝업의 설명 섹션',
   'title:id': 'Bagian deskripsi dalam popup',
   'title:es': 'Sección de descripción en ventana emergente',
   'title:pt': 'Seção de descrição no pop-up',
   'title:fr': 'Section de description dans la fenêtre contextuelle',
   'title:it': 'Sezione Descrizione nel popup',
   'title:tr': 'Açılır pencerede açıklama bölümü',
   'title:de': 'Beschreibungsabschnitt im Popup',
   'title:pl': 'Opis w osobnym oknie',
   'title:ua': 'Розділ опису у спливаючому вікні',
   run_on_pages: 'watch, -mobile',
   section: 'details',
   // desc: '',
   _runtime: user_settings => {

      // if (user_settings['video-description-expand']) return; // conflict with plugin. This plugin has a higher priority. that's why it's disabled/commented

      // bug if DESCRIPTION_SELECTOR is empty. Using CSS is impossible to fix. And through JS extra

      const
         DESCRIPTION_SELECTOR = 'html:not(:fullscreen) #description.ytd-watch-metadata:not([hidden]):not(:empty)',
         DATE_SELECTOR_ID = 'nova-description-date';

      NOVA.waitElement('#masthead-container')
         .then(masthead => {

            NOVA.css.push(
               `${DESCRIPTION_SELECTOR},
               ${DESCRIPTION_SELECTOR}:before {
                  position: fixed;
                  top: ${masthead.offsetHeight || 56}px;
                  right: 0;
                  z-index: ${Math.max(
                  getComputedStyle(masthead)['z-index'],
                  // getComputedStyle(movie_player)['z-index'], // movie_player is not defined
                  601) + 1};
               }

               /* button */
               ${DESCRIPTION_SELECTOR}:not(:hover):before {
                  content: "info ▼";
                  cursor: pointer;
                  visibility: visible;
                  /*transform: rotate(-90deg) translateX(-100%);*/
                  right: 12em;
                  padding: 0 8px 3px;
                  line-height: normal;
                  font-family: Roboto, Arial, sans-serif;
                  font-size: 11px;
                  color: #eee;
                  background: rgba(0,0,0,0.3);
               }

               /* description section */
               ${DESCRIPTION_SELECTOR} {
                  margin: 0 1%;
                  overflow-y: auto;
                  max-height: 88vh;
                  max-width: 55%;
                  background-color: #222;
                  border: 1px solid #333;
                  border-radius: 0 !important;
               }

               ${DESCRIPTION_SELECTOR}:not(:hover) {
                  visibility: collapse;
                  overflow: hidden;
               }

               /* description section hover */
               ${DESCRIPTION_SELECTOR}:hover {
                  visibility: visible !important;
               }

               /* custom scroll */
               ${DESCRIPTION_SELECTOR}::-webkit-scrollbar {
                  height: 8px;
                  width: 10px;
               }

               ${DESCRIPTION_SELECTOR}::-webkit-scrollbar-button {
                  height: 0;
                  width: 0;
               }

               ${DESCRIPTION_SELECTOR}::-webkit-scrollbar-corner {
                  background: transparent;
               }

               ${DESCRIPTION_SELECTOR}::-webkit-scrollbar-thumb {
                  background: #e1e1e1;
                  border: 0;
                  border-radius: 0;
               }

               ${DESCRIPTION_SELECTOR}::-webkit-scrollbar-track {
                  background: #666;
                  border: 0;
                  border-radius: 0;
               }

               ${DESCRIPTION_SELECTOR}::-webkit-scrollbar-track:hover {
                  background: #666;
               }`);
         });

      // expand
      NOVA.waitElement(DESCRIPTION_SELECTOR)
         .then(descriptionEl => {
            // Strategy 2
            let oldDateText;

            descriptionEl.addEventListener('mouseenter', evt => {
               document.body.querySelector('#meta [collapsed] #more, [description-collapsed] #description #expand')?.click()
            });
            // }, { capture: true, once: true });

            document.addEventListener('yt-navigate-finish', restoreDateLine);
            // init
            restoreDateLine();

            function restoreDateLine() {
               // Strategy 1
               // const dataEl = document.getElementById(DATE_SELECTOR_ID);

               NOVA.waitElement('#title h1')
                  .then(async container => {
                     const
                        textDate = await NOVA.waitUntil(() => {
                           // Strategy 1 regex. Does work in Premiered - "613 views Premiered 2 hours ago"
                           // if (
                           //    (text = descriptionEl.textContent.trim())
                           //    && (dateIdx = text.search(/\d{4}/)) && dateIdx > -1
                           //    && (dt = text.substring(0, dateIdx + 4))
                           //    && dt && dt != dataEl?.textContent
                           // ) {
                           //    return dt;
                           // }
                           // Strategy 2 HTML
                           if ((text = [...descriptionEl.querySelectorAll('.bold.yt-formatted-string')]
                           // first 3 div. ex:
                           // [6,053 views] [Premiered] [Oct 8, 2022]
                           // [14,051 views] [] [Mar 2, 2017]
                              .slice(0, 3)
                              .map(e => e.textContent).join('').trim())
                              && text != oldDateText
                           ) {
                              // console.debug('1', oldDateText);
                              // console.debug('2', text);
                              oldDateText = text;
                              return text;
                           }
                        }, 1000); // 1sec

                     // console.debug('textDate', textDate);
                     insertToHTML({ 'text': textDate, 'container': container });

                     function insertToHTML({ text = '', container = required() }) {
                        // console.debug('insertToHTML', ...arguments);
                        if (!(container instanceof HTMLElement)) return console.error('container not HTMLElement:', container);

                        (document.getElementById(DATE_SELECTOR_ID) || (function () {
                           container.insertAdjacentHTML('afterend',
                              `<span id="${DATE_SELECTOR_ID}" class="style-scope yt-formatted-string bold" style="font-size: 1.35rem; line-height: 2rem; font-weight:400;">${textDate}</span>`);
                           return document.getElementById(DATE_SELECTOR_ID);
                        })())
                           .textContent = text;
                     }

                  });
            }
         });

   },
});
window.nova_plugins.push({
   id: 'redirect-disable',
   title: 'Clear links from redirect',
   'title:zh': '清除重定向中的链接',
   'title:ja': 'リダイレクトからリンクをクリアする',
   'title:ko': '리디렉션에서 링크 지우기',
   'title:id': 'Hapus tautan dari pengalihan',
   'title:es': 'Borrar enlaces de redireccionamientos',
   'title:pt': 'Limpar links de redirecionamentos',
   'title:fr': 'Effacer les liens des redirections',
   'title:it': 'Cancella i collegamenti dal reindirizzamento',
   'title:tr': 'Yönlendirmeden bağlantıları temizle',
   'title:de': 'Links aus Weiterleitungen löschen',
   'title:pl': 'Wyczyść linki z przekierowań',
   'title:ua': 'Очистити посилання від перенаправлення',
   run_on_pages: 'watch, channel',
   section: 'details',
   desc: 'Direct external links',
   'desc:zh': '直接链接到外部站点',
   'desc:ja': '外部サイトへの直接リンク',
   'desc:ko': '직접 외부 링크',
   'desc:id': 'Tautan eksternal langsung',
   'desc:es': 'Enlaces externos directos',
   'desc:pt': 'Links externos diretos',
   'desc:fr': 'Liens externes directs',
   'desc:it': 'Collegamenti esterni diretti',
   'desc:tr': 'Doğrudan harici bağlantılar',
   'desc:de': 'Direkte externe Links',
   'desc:pl': 'Bezpośrednie łącza zewnętrzne',
   'desc:ua': 'Прямі зовнішні посилання',
   _runtime: user_settings => {

      // mouse left click
      document.addEventListener('click', ({ target }) => patchLink(target), { capture: true });
      // mouse middle click
      document.addEventListener('auxclick', evt => evt.button === 1 && patchLink(evt.target), { capture: true });

      function patchLink(target = required()) {
         const linkSelector = 'a[href*="/redirect?"]';

         if (!target.matches(linkSelector)) {
            if (!(target = target.closest(linkSelector))) return;
         }

         if (q = NOVA.queryURL.get('q', target.href)) {
            target.href = decodeURIComponent(q);
            // alert(target.href);
         }
      }

   },
});
window.nova_plugins.push({
   id: 'header-short',
   title: 'Header compact',
   'title:zh': '标题紧凑',
   'title:ja': 'ヘッダーコンパクト',
   'title:ko': '헤더 컴팩트',
   'title:id': 'Kompak tajuk',
   'title:es': 'Encabezado compacto',
   'title:pt': 'Cabeçalho compacto',
   'title:fr': 'En-tête compact',
   'title:it': 'Testata compatta',
   'title:tr': 'Başlık kompakt',
   'title:de': 'Header kompakt',
   'title:pl': 'Kompaktowy nagłówek',
   'title:ua': 'Компактна шапка сайту',
   run_on_pages: 'all, -embed, -mobile',
   section: 'header',
   // desc: '',
   _runtime: user_settings => {

      const height = '36px';

      NOVA.css.push(
         `#masthead #container.ytd-masthead {
            height: ${height} !important;
         }

         #search-form, #search-icon-legacy {
            height: ${height} !important;
         }

         body {
            --ytd-masthead-height: ${height};
         }

         #chips-wrapper.ytd-feed-filter-chip-bar-renderer {
            --ytd-rich-grid-chips-bar-top: ${height};
         }`);

   },
});
window.nova_plugins.push({
   id: 'header-unfixed',
   title: 'Header unfixed',
   'title:zh': '标题未固定',
   'title:ja': 'ヘッダーは固定されていません',
   'title:ko': '헤더가 고정되지 않음',
   'title:id': 'Tajuk tidak diperbaiki',
   'title:es': 'Encabezado sin arreglar',
   'title:pt': 'Cabeçalho não corrigido',
   'title:fr': 'En-tête non corrigé',
   'title:it': 'Intestazione non fissata',
   'title:tr': 'Başlık sabitlenmemiş',
   'title:de': 'Kopfleiste nicht fixiert',
   'title:pl': 'Przewijany nagłówek',
   'title:ua': 'Відкріпити шапку сайту',
   // run_on_pages: 'watch, channel',
   run_on_pages: 'all, -embed, -mobile',
   // restart_on_transition: true,
   section: 'header',
   desc: 'Prevent header from sticking',
   'desc:zh': '防止头部粘连',
   'desc:ja': 'ヘッダーがくっつくのを防ぎます',
   'desc:ko': '헤더가 달라붙는 것을 방지',
   'desc:id': 'Mencegah header menempel',
   'desc:es': 'Evita que el cabezal se pegue',
   'desc:pt': 'Impede que o cabeçalho grude',
   'desc:fr': "Empêcher l'en-tête de coller",
   'desc:it': "Impedisci che l'intestazione si attacchi",
   'desc:tr': 'Başlığın yapışmasını önleyin',
   'desc:de': 'Verhindert das Ankleben des Headers',
   'desc:pl': 'Nagłówek będzie przewijany wraz ze stroną',
   'desc:ua': 'Відкріпляє шапку при прокрутці сайту',
   _runtime: user_settings => {

      NOVA.css.push(
         `#masthead-container, ytd-mini-guide-renderer, #guide {
            position: absolute !important;
         }
         #chips-wrapper {
            position: sticky !important;
         }`);

      if (user_settings.header_unfixed_scroll) {
         createArrowButton();
         // scroll
         document.addEventListener('yt-action', evt => {
            // console.log(evt.detail?.actionName);
            if (evt.detail?.actionName == 'yt-reload-continuation-items-command') {
               scrollAfter();
            }
         });

         function scrollAfter() {
            if (topOffset = document.getElementById('masthead')?.offsetHeight) {
               window.scrollTo({ top: topOffset });
            }
         }

         // create arrow button
         function createArrowButton() {
            const scrollDownButton = document.createElement('button');
            scrollDownButton.textContent = '▼';
            scrollDownButton.title = 'Scroll down';
            Object.assign(scrollDownButton.style, {
               cursor: 'pointer',
               background: 'transparent',
               color: 'deepskyblue',
               border: 'none',
            });
            scrollDownButton.onclick = scrollAfter;

            if (endnode = document.getElementById('end')) {
               endnode.parentElement.insertBefore(scrollDownButton, endnode);
            }
         }
      }

   },
   options: {
      header_unfixed_scroll: {
         _tagName: 'input',
         label: 'Scroll after header',
         'label:zh': '在标题后滚动',
         'label:ja': 'ヘッダーの後にスクロール',
         'label:ko': '헤더 뒤 스크롤',
         'label:id': 'Gulir setelah tajuk',
         'label:es': 'Desplazarse después del encabezado',
         'label:pt': 'Role após o cabeçalho',
         'label:fr': "Faire défiler après l'en-tête",
         'label:it': "Scorri dopo l'intestazione",
         'label:tr': 'Başlıktan sonra kaydır',
         'label:de': 'Nach der Kopfzeile scrollen',
         'label:pl': 'Przewiń nagłówek',
         'label:ua': 'Прокручувати після шапки сайту',
         title: 'Makes sense on a small screen',
         'title:zh': '在小屏幕上有意义',
         'title:ja': '小さな画面で意味があります',
         'title:ko': '작은 화면에서 이해하기',
         'title:id': 'Masuk akal di layar kecil',
         'title:es': 'Tiene sentido en una pantalla pequeña',
         'title:pt': 'Faz sentido em uma tela pequena',
         'title:fr': 'A du sens sur un petit écran',
         'title:it': 'Ha senso su un piccolo schermo',
         'title:tr': 'Küçük ekranda mantıklı',
         'title:de': 'Macht auf einem kleinen Bildschirm Sinn',
         'title:pl': 'Przydatne na małym ekranie',
         'title:ua': 'Ефективно на малому екрані',
         type: 'checkbox',
      },
   }
});
window.nova_plugins.push({
   id: 'page-logo',
   title: 'YouTube logo',
   'title:zh': 'YouTube 徽标',
   'title:ja': 'YouTubeロゴ',
   'title:ko': '유튜브 로고',
   // 'title:id': '',
   // 'title:es': '',
   // 'title:pt': '',
   // 'title:fr': '',
   // 'title:it': '',
   // 'title:tr': '',
   // 'title:de': '',
   // 'title:pl': '',
   'title:ua': 'YouTube лого',
   run_on_pages: 'all, -embed, -mobile',
   section: 'header',
   // desc: '',
   _runtime: user_settings => {

      NOVA.waitElement('#masthead a#logo')
         .then(a => a.href = new URL(user_settings.page_logo_url_mode)?.href);

   },
   options: {
      page_logo_url_mode: {
         _tagName: 'input',
         label: 'URL',
         type: 'url',
         pattern: "https://.*",
         // title: '',
         placeholder: 'https://youtube.com/...',
         value: 'https://youtube.com/feed/subscriptions',
      },
   }
});
window.nova_plugins.push({
   id: 'search-query',
   title: 'Search filters',
   'title:zh': '搜索过滤器',
   'title:ja': '検索フィルター',
   'title:ko': '검색 필터',
   'title:id': 'Filter pencarian',
   'title:es': 'Filtros de búsqueda',
   'title:pt': 'Filtros de pesquisa',
   'title:fr': 'Filtres de recherche',
   'title:it': 'Filtri di ricerca',
   'title:tr': 'Arama filtreleri',
   'title:de': 'Suchfilter',
   'title:pl': 'Filtry wyszukiwania',
   'title:ua': 'Фільтр пошуку',
   run_on_pages: 'results',
   restart_on_transition: true,
   section: 'header',
   // desc: '',
   _runtime: user_settings => {

      // Strategy 1. Patch url
      if (!NOVA.queryURL.has('sp')
         && (sp = user_settings.search_query_date || user_settings.search_query_sort)
      ) {
         location.href = NOVA.queryURL.set({ 'sp': sp });
      }

      // Strategy 2. Patch input
      // if (!NOVA.queryURL.has('sp')
      //    && (sp = user_settings.search_query_date || user_settings.search_query_sort)
      // ) {
      //    NOVA.waitElement('input#search')
      //       .then(input => {
      //          const patchLocation = () => location.href = `/results?search_query=${input.value}&sp=` + sp;
      //          // press "Enter"
      //          input.addEventListener('keydown', ({ keyCode }) => (keyCode === 13) && patchLocation());
      //          input.addEventListener('keydown', ({ key }) => (key === 'Enter') && patchLocation());
      //          // click on button
      //          NOVA.waitElement('button#search-icon-legacy')
      //             .then(button => button.addEventListener('click', patchLocation));
      //       });
      // }

   },
   options: {
      search_query_sort: {
         _tagName: 'select',
         label: 'Sort by',
         'label:zh': '排序方式',
         'label:ja': '並び替え',
         'label:ko': '정렬 기준',
         'label:id': 'Sortir dengan',
         'label:es': 'Ordenar por',
         'label:pt': 'Ordenar por',
         'label:fr': 'Trier par',
         'label:it': 'Ordina per',
         'label:tr': 'Göre sırala',
         'label:de': 'Sortieren nach',
         'label:pl': 'Sortuj według',
         'label:ua': 'Сортувати за',
         options: [
            { label: 'Relevance', value: false, selected: true, 'label:ua': 'Актуальність' },
            { label: 'Upload date', value: 'CAI%253D', 'label:ua': 'Дата завантаження' },
            { label: 'View count', value: 'CAM%253D', 'label:ua': 'Кількість переглядів' },
            { label: 'Rating', value: 'CAE%253D', 'label:ua': 'Вподобайки' },
         ],
         'data-dependent': { 'search_query_date': [false] },
      },
      search_query_date: {
         _tagName: 'select',
         label: 'Upload date',
         'label:zh': '上传日期',
         'label:ja': 'アップロード日',
         'label:ko': '업로드 날짜',
         'label:id': 'Tanggal unggah',
         'label:es': 'Fecha de carga',
         'label:pt': 'data de upload',
         'label:fr': 'Date de dépôt',
         'label:it': 'data di caricamento',
         'label:tr': 'yükleme tarihi',
         'label:de': 'Datum des Hochladens',
         'label:pl': 'Data przesłania',
         'label:ua': 'Дата завантаження',
         options: [
            { label: 'All time', value: false, selected: true, 'label:ua': 'За увесь час' },
            { label: 'Last hour', value: 'EgIIAQ%253D%253D', 'label:ua': 'За останню годину' },
            { label: 'Today', value: 'EgIIAg%253D%253D', 'label:ua': 'Сьогодні' },
            { label: 'This week', value: 'EgIIAw%253D%253D', 'label:ua': 'Цього тижня' },
            { label: 'This month', value: 'EgIIBA%253D%253D', 'label:ua': 'Цього місяця' },
            { label: 'This year', value: 'EgIIBQ%253D%253D', 'label:ua': 'Цього року' },
         ],
         'data-dependent': { 'search_query_sort': [false] },
      },
   }
});
window.nova_plugins.push({
   id: 'channel-default-tab',
   title: 'Default tab on channel page',
   'title:zh': '频道页默认选项卡',
   'title:ja': 'チャンネルページのデフォルトタブ',
   'title:ko': '채널 페이지의 기본 탭',
   'title:id': 'Tab default di halaman saluran',
   'title:es': 'La pestaña predeterminada en la página del canal',
   'title:pt': 'A guia padrão na página do canal',
   'title:fr': 'Onglet par défaut sur la page de la chaîne',
   'title:it': 'Scheda predefinita nella pagina del canale',
   'title:tr': 'Kanal sayfasındaki varsayılan sekme',
   'title:de': 'Die Standardregisterkarte auf der Kanalseite',
   'title:pl': 'Domyślna karta na stronie kanału',
   'title:ua': 'Вкладка за умовчанням на сторінці каналу',
   run_on_pages: 'channel, -mobile',
   restart_on_transition: true,
   section: 'channel',
   // desc: '',
   _runtime: user_settings => {

      // alt - https://greasyfork.org/en/scripts/445640-yt-video-tab-by-default

      // if not - home page channel/user
      if (location.pathname.split('/').filter(i => i).length !== 2) return;

      if (user_settings.channel_default_tab_mode == 'redirect') {
         location.href += '/' + user_settings.channel_default_tab;

      } else {
         // tab select
         NOVA.waitElement('#tabsContent>[role="tab"]:nth-child(2)[aria-selected=true]')
            .then(() => {
               let tab_nth;
               switch (user_settings.channel_default_tab) {
                  case 'playlists': tab_nth = 6; break;
                  case 'about': tab_nth = 12; break;
                  // case 'videos':
                  default: tab_nth = 4;
               }
               // select tab
               document.body.querySelector(`#tabsContent>[role="tab"]:nth-child(${tab_nth})[aria-selected="false"]`)
                  ?.click();
            });
      }

   },
   options: {
      channel_default_tab: {
         _tagName: 'select',
         label: 'Default tab',
         'label:zh': '默认标签页',
         'label:ja': 'デフォルトのタブ',
         'label:ko': '기본 탭',
         'label:id': '',
         'label:es': 'Ficha predeterminada',
         'label:pt': 'Aba padrão',
         'label:fr': 'Onglet par défaut',
         'label:it': '',
         'label:tr': 'Varsayılan sekme',
         'label:de': 'Standard-Tab',
         'label:pl': 'Domyślna karta',
         'label:ua': 'Вкладка за умовчанням',
         options: [
            { label: 'videos', value: 'videos', selected: true, 'label:pl': 'wideo', 'label:ua': 'Відео' },
            { label: 'playlists', value: 'playlists', 'label:pl': 'playlista', 'label:ua': 'Плейлисти' },
            { label: 'about', value: 'about', 'label:pl': 'o kanale', 'label:ua': 'Про канал' },
         ],
      },
      channel_default_tab_mode: {
         _tagName: 'select',
         label: 'Mode',
         'label:zh': '模式',
         'label:ja': 'モード',
         'label:ko': '방법',
         // 'label:id': 'Mode',
         'label:es': 'Modo',
         'label:pt': 'Modo',
         // 'label:fr': 'Mode',
         'label:it': 'Modalità',
         'label:tr': 'Mod',
         'label:de': 'Modus',
         'label:pl': 'Tryb',
         'label:ua': 'Режим',
         title: 'Redirect is safer but slower',
         'title:zh': '重定向是安全的，但速度很慢',
         'title:ja': 'リダイレクトは安全ですが遅くなります',
         'title:ko': '리디렉션이 더 안전하지만 느립니다',
         'title:id': 'Redirect lebih aman tetapi lebih lambat',
         'title:es': 'La redirección es más segura pero más lenta',
         'title:pt': 'O redirecionamento é mais seguro, mas mais lento',
         'title:fr': 'La redirection est plus sûre mais plus lente',
         'title:it': 'Il reindirizzamento è più sicuro ma più lento',
         'title:tr': 'Yönlendirme daha güvenlidir ancak daha yavaştır',
         'title:de': 'Redirect ist sicherer, aber langsamer',
         'title:pl': 'Przekierowanie jest bezpieczniejsze, ale wolniejsze',
         'title:ua': 'Перенаправлення безпечніше, але повільніше',
         options: [
            { label: 'redirect', value: 'redirect', 'label:pl': 'przekierowanie', 'label:ua': 'Перенаправити' },
            { label: 'click', /*value: '',*/ selected: true, 'label:pl': 'klik', 'label:ua': 'Клік' },
         ],
      },
   }
});
// for test
// https://www.youtube.com/watch?v=oWoWkxzeiok&list=OLAK5uy_kDx6ubTnuS4mYHCPyyX1NpXyCtoQN08M4&index=3

window.nova_plugins.push({
   id: 'thumbnails-watched',
   title: 'Mark watched thumbnails',
   'title:zh': '标记您观看的缩略图',
   'title:ja': '視聴したサムネイルにマークを付ける',
   'title:ko': '본 썸네일 표시',
   'title:id': 'Tandai gambar mini yang ditonton',
   'title:es': 'Mark vio miniaturas',
   'title:pt': 'Mark assistiu às miniaturas',
   'title:fr': 'Marquer les vignettes visionnées',
   'title:it': 'Contrassegna le miniature visualizzate',
   'title:tr': 'İzlenen küçük resimleri işaretle',
   'title:de': 'Angesehene Miniaturansichten markieren',
   'title:pl': 'Oznacz obejrzane miniaturki',
   'title:ua': 'Позначити переглянуті мініатюри',
   run_on_pages: 'home, results, feed, channel, watch, -mobile',
   // run_on_pages: 'all, -embed',
   section: 'other',
   // desc: 'Need to Turn on [YouTube History]',
   _runtime: user_settings => {

      // Only the outline/border works. Other selection methods do not work in chrome!

      NOVA.css.push(
         `a#thumbnail,
         a[class*="thumbnail"] {
            outline: 1px solid var(--yt-spec-general-background-a);
         }

         /*a.ytp-videowall-still.ytp-suggestion-set:visited, <-- Doesn't work*/
         a#thumbnail:visited,
         a[class*="thumbnail"]:visited {
            outline: 1px solid ${user_settings.thumbnails_watched_frame_color || 'red'} !important;
         }

         /*for playlist*/
         ytd-playlist-panel-video-renderer a:visited #meta * {
            color: ${user_settings.thumbnails_watched_title_color || '#ff4500'} !important;
         }`);

      if (user_settings.thumbnails_watched_title) {
         NOVA.css.push(
            `a#video-title:visited:not(:hover),
            #description a:visited {
               color: ${user_settings.thumbnails_watched_title_color} !important;
            }`);
      }

      // add blur
      // NOVA.css.push(
      //    `a.ytp-videowall-still.ytp-suggestion-set:visited, #thumbnail:visited {
      //       transition: all 200ms ease-in-out;
      //       opacity: .4 !important;
      //       mix-blend-mode: luminosity;
      //       filter: blur(2.2px);
      //    }

      //    .watched #thumbnail:hover, #thumbnail:visited:hover {
      //       transition: ease-out;
      //       opacity: 1 !important;
      //       mix-blend-mode: normal;
      //       filter: blur(0px);
      //    }`);

   },
   options: {
      thumbnails_watched_frame_color: {
         _tagName: 'input',
         label: 'Frame color',
         'label:zh': '框架颜色',
         'label:ja': 'フレームカラー',
         'label:ko': '프레임 색상',
         'label:id': 'Warna bingkai',
         'label:es': 'Color del marco',
         'label:pt': 'Cor da moldura',
         'label:fr': 'Couleur du cadre',
         'label:it': 'Colore del telaio',
         'label:tr': 'Çerçeve rengi',
         'label:de': 'Rahmenfarbe',
         'label:pl': 'Kolor ramki',
         'label:ua': 'Колір рамки',
         type: 'color',
         value: '#FF0000',
      },
      thumbnails_watched_title: {
         _tagName: 'input',
         label: 'Set title color',
         'label:zh': '您要更改标题颜色吗？',
         'label:ja': 'タイトルの色を変更しますか？',
         'label:ko': '제목 색상 설정',
         'label:id': 'Setel warna judul',
         'label:es': 'Establecer el color del título',
         'label:pt': 'Definir a cor do título',
         'label:fr': 'Définir la couleur du titre',
         'label:it': 'Imposta il colore del titolo',
         'label:tr': 'Başlık rengini ayarla',
         'label:de': 'Titelfarbe festlegen',
         'label:pl': 'Ustaw kolor tytułu',
         'label:ua': 'Встановити колір заголовку',
         type: 'checkbox',
         // title: 'Link',
      },
      thumbnails_watched_title_color: {
         _tagName: 'input',
         label: 'Choose title color',
         'label:zh': '选择标题颜色',
         'label:ja': 'タイトルの色を選択',
         'label:ko': '제목 색상 선택',
         'label:id': 'Pilih warna judul',
         'label:es': 'Elija el color del título',
         'label:pt': 'Escolha a cor do título',
         'label:fr': 'Choisissez la couleur du titre',
         'label:it': 'Scegli il colore del titolo',
         'label:tr': 'Başlık rengini seçin',
         'label:de': 'Titelfarbe auswählen',
         'label:pl': 'Wybierz kolor tytułu',
         'label:ua': 'Обрати колір заголовку',
         type: 'color',
         value: '#ff4500',
         'data-dependent': { 'thumbnails_watched_title': true },
      },
   }
});
window.nova_plugins.push({
   id: 'disable-video-cards',
   title: 'Hide garbage: annotations, endcards etc',
   // 'title:zh': '',
   // 'title:ja': '',
   // 'title:ko': '',
   // 'title:id': '',
   // 'title:es': '',
   // 'title:pt': '',
   // 'title:fr': '',
   // 'title:it': '',
   // 'title:tr': '',
   // 'title:de': '',
   // 'title:pl': '',
   'title:ua': 'Приховайте сміття: анотації, кінцеві заставки тощо',
   run_on_pages: 'results, watch, embed, -mobile',
   section: 'other',
   // desc: "turn off 'card' in https://www.youtube.com/account_playback",
   desc: 'remove the annoying stuff',
   // desc: 'remove the annoying stuff at the end of the videos',
   'desc:ua': 'Приховайте набридливий контент',
   _runtime: user_settings => {

      let selectorsList = [
         // '.annotation',
         '.ytp-paid-content-overlay', // message in the bottom-left corner "Includes paid promotion"
         // channel icon in the bottom-right corner
         '.iv-branding',
         // '.iv-promo',
      ];

      switch (NOVA.currentPage) {
         case 'embed':
            // https://stackoverflow.com/questions/52887444/hide-more-videos-within-youtube-iframe-when-stop-video
            selectorsList.push([
               '.ytp-pause-overlay', // wide-bottom block with more video list on pause
            ]);
            break;

         default:
            selectorsList.push([
               /* for 'results' page: */
               '.sparkles-light-cta', // ad buy (https://www.youtube.com/results?search_query=Canon+Pixma+MG2520)
               'ytd-search-pyv-renderer', // fix blank space (https://www.youtube.com/results?search_query=Shubidua+-+Fed+Rock)
               '[class^="ytd-promoted-"]', // suggest site (https://www.youtube.com/results?search_query=mmersive+Simmulator)
               // '.ytd-promoted-sparkles-text-search-renderer', // suggest something (I do not remember)
               // 'ytd-search-pyv-renderer ytd-promoted-video-renderer', // suggest ad-video
               'ytd-video-renderer + ytd-shelf-renderer', // "People also watched" block (alt - https://greasyfork.org/en/scripts/454513-youtube-search-results-cleaner)
               // 'ytd-video-renderer + ytd-horizontal-card-list-renderer', // "People also search for" block

               /* for 'watch' page: */
               '.ytp-autohide > [class^="ytp-ce-"]', // suggest video/channel for the end cards
               '.ytp-cards-teaser-text', // "next video suggestion" (title) in the top-right corner

               'ytd-feed-nudge-renderer', // message "Recommendations not quite right? When you turn on watch history, you’ll get more personalized recommendations"

               '.ytd-watch-flexy.attached-message', // message "BBC World Service is a British public broadcast service. Wikipedia"

               // 'ytd-popup-container tp-yt-paper-dialog yt-mealbar-promo-renderer', // 'Ambient mode' You're watching in our more immersive ambient mode.
               'ytd-popup-container tp-yt-paper-dialog ytd-single-option-survey-renderer', // "How is YouTube today?" - Absolutely outstanding, Extremely good, Very good, Good, Not good

               // sidebar ad block
               // '.sparkles-light-cta',
            ]);
      }

      if (selectorsList.length) {
         NOVA.css.push(
            selectorsList.join(',\n') + ` {
               display: none !important;
            }`);
         // NOVA.css.push({
         //    'display': 'none !important',
         // }, selectorsList.join(',\n'));
      }

   },
});
window.nova_plugins.push({
   id: 'rss-link',
   title: 'Add RSS Feed link',
   'title:zh': '添加 RSS 提要链接',
   'title:ja': 'RSSフィードリンクを追加',
   'title:ko': 'RSS 피드 링크 추가',
   'title:id': 'Tambahkan tautan Umpan RSS',
   'title:es': 'Agregar enlace de fuente RSS',
   'title:pt': 'Adicionar link de feed RSS',
   'title:fr': 'Ajouter un lien de flux RSS',
   'title:it': 'Aggiungi collegamento al feed RSS',
   'title:tr': 'RSS Beslemesi bağlantısı ekle',
   'title:de': 'RSS-Feed-Link hinzufügen',
   'title:pl': 'Dodaj kanał RSS',
   'title:ua': 'Додати RSS-посилання',
   run_on_pages: 'channel, playlist, -mobile',
   restart_on_transition: true,
   section: 'channel',
   // desc: '',
   _runtime: user_settings => {

      const
         SELECTOR_ID = 'nova-rss-link',
         rssLinkPrefix = '/feeds/videos.xml',
         playlistURL = rssLinkPrefix + '?playlist_id=' + NOVA.queryURL.get('list'),
         genChannelURL = channelId => rssLinkPrefix + '?channel_id=' + channelId;


      switch (NOVA.currentPage) {
         case 'channel':
            // NOVA.waitElement('#channel-header #channel-name')
            NOVA.waitElement('#links-holder #primary-links')
               .then(async container => {
                  if (channelId = await NOVA.getChannelId()) {
                     insertToHTML({ 'url': genChannelURL(channelId), 'container': container });
                  }
                  // console.debug('channelId:', channelId);
               });
            break;

         case 'playlist':
            NOVA.waitElement('#owner-container')
               .then(container => {
                  // playlist page
                  insertToHTML({ 'url': playlistURL, 'container': container });
               });
            break;
      }

      function insertToHTML({ url = required(), container = required() }) {
         // console.debug('insertToHTML', ...arguments);
         if (!(container instanceof HTMLElement)) return console.error('container not HTMLElement:', container);

         // (document.getElementById(SELECTOR_ID) || (function () {
         (container.querySelector('#' + SELECTOR_ID) || (function () {
            const link = document.createElement('a');
            link.id = SELECTOR_ID;
            link.href = url;
            link.target = '_blank';
            // btn.className = `ytp-button ${SELECTOR_CLASS}`;
            link.innerHTML =
               // `<svg viewBox="-28.364 -29.444 42.324 42.822" height="100%" width="100%">
               `<svg viewBox="-40 -40 55 55" height="100%" width="100%" style="width: auto;">
                  <g fill="currentColor">
                     <path fill="#F60" d="M-17.392 7.875c0 3.025-2.46 5.485-5.486 5.485s-5.486-2.46-5.486-5.485c0-3.026 2.46-5.486 5.486-5.486s5.486 2.461 5.486 5.486zm31.351 5.486C14.042.744 8.208-11.757-1.567-19.736c-7.447-6.217-17.089-9.741-26.797-9.708v9.792C-16.877-19.785-5.556-13.535.344-3.66a32.782 32.782 0 0 1 4.788 17.004h8.827v.017zm-14.96 0C-.952 5.249-4.808-2.73-11.108-7.817c-4.821-3.956-11.021-6.184-17.255-6.15v8.245c6.782-.083 13.432 3.807 16.673 9.774a19.296 19.296 0 0 1 2.411 9.326h8.278v-.017z"/>
                  </g>
               </svg>`;
            Object.assign(link.style, {
               height: '20px',
               display: 'inline-block',
               padding: '5px',
            });
            container.prepend(link);
            return document.getElementById(SELECTOR_ID);
            // return container.appendChild(link);
         })())
            .href = url;

         addMetaLink();

         async function addMetaLink() {
            if (channelId = await NOVA.getChannelId()) {
               document.head.insertAdjacentHTML('beforeend',
                  `<link rel="alternate" type="application/rss+xml" title="RSS" href="${genChannelURL(channelId)}">`);
            }
         }
      }

   },
});
window.nova_plugins.push({
   id: 'scroll-to-top',
   title: 'Scroll to top button',
   'title:zh': '滚动到顶部按钮',
   'title:ja': 'トップボタンまでスクロール',
   'title:ko': '맨 위로 스크롤 버튼',
   'title:id': 'Gulir ke tombol atas',
   'title:es': 'Desplazarse al botón superior',
   'title:pt': 'Role para o botão superior',
   'title:fr': 'Faites défiler vers le haut',
   'title:it': 'Scorri fino al pulsante in alto',
   'title:tr': 'Üst düğmeye kaydır',
   'title:de': 'Nach oben scrollen',
   'title:pl': 'Przycisk przewijania do góry',
   'title:ua': 'Прокрутити до гори',
   run_on_pages: 'all, -embed, -mobile',
   section: 'other',
   desc: 'Displayed on long pages',
   'desc:zh': '出现在长页面上',
   'desc:ja': '長いページに表示されます',
   'desc:ko': '긴 페이지에 표시됨',
   'desc:id': 'Ditampilkan di halaman panjang',
   'desc:es': 'Mostrado en páginas largas',
   'desc:pt': 'Exibido em páginas longas',
   'desc:fr': 'Affiché sur de longues pages',
   'desc:it': 'Visualizzato su pagine lunghe',
   'desc:tr': 'Uzun sayfalarda görüntüleniyor',
   'desc:de': 'Wird auf langen Seiten angezeigt',
   'desc:pl': 'Wyświetlaj na długich stronach',
   'desc:ua': 'Відображається на довгих сторінках',
   _runtime: user_settings => {

      document.addEventListener('scroll', appendBtn, { capture: true, once: true });

      function appendBtn() {
         const SELECTOR_ID = 'nova-scrollTop-btn';

         const btn = document.createElement('button');
         btn.id = SELECTOR_ID;
         Object.assign(btn.style, {
            position: 'fixed',
            cursor: 'pointer',
            bottom: 0,
            left: '20%',
            // display: 'none',
            visibility: 'hidden',
            opacity: .5,
            width: '40%',
            height: '40px',
            border: 'none',
            // transition: 'opacity 200ms ease-in',
            outline: 'none',
            'z-index': 1,
            'border-radius': '100% 100% 0 0',
            'font-size': '16px',
            'background-color': 'rgba(0,0,0,.3)',
            'box-shadow': '0 16px 24px 2px rgba(0, 0, 0, .14), 0 6px 30px 5px rgba(0, 0, 0, .12), 0 8px 10px -5px rgba(0, 0, 0, .4)',
         });
         btn.addEventListener('click', () => {
            window.scrollTo({
               top: 0,
               // left: window.pageXOffset,
               behavior: user_settings.scroll_to_top_smooth ? 'smooth' : 'instant',
            });
            if (user_settings.scroll_to_top_autoplay && NOVA.currentPage == 'watch'
               // && NOVA.videoElement?.paused // restart ENDED
               && ['UNSTARTED', 'PAUSED'].includes(NOVA.getPlayerState())
            ) {
               movie_player.playVideo();
               // NOVA.videoElement?.play();
            }
         });

         // create arrow
         const arrow = document.createElement('span');
         Object.assign(arrow.style, {
            border: 'solid white',
            'border-width': '0 3px 3px 0',
            display: 'inline-block',
            padding: '4px',
            'vertical-align': 'middle',
            transform: 'rotate(-135deg)',
         });
         btn.append(arrow);
         document.body.append(btn);

         // btn hover style
         NOVA.css.push(
            `#${SELECTOR_ID}:hover {
               opacity: 1 !important;
               background-color: rgba(0,0,0,.6) !important;
            }`);

         // scroll event
         const scrollTop_btn = document.getElementById(SELECTOR_ID);
         let sOld;
         window.addEventListener('scroll', () => {
            // trigger if (current scroll > 50% viewport)
            const sCurr = document.documentElement.scrollTop > (window.innerHeight / 2);
            if (sCurr == sOld) return;
            sOld = sCurr;
            scrollTop_btn.style.visibility = sCurr ? 'visible' : 'hidden';
            // console.debug('visibility:', scrollTop_btn.style.visibility);
         });
      }

   },
   options: {
      scroll_to_top_smooth: {
         _tagName: 'input',
         label: 'Smooth',
         'label:zh': '光滑的',
         'label:ja': 'スムーズ',
         'label:ko': '매끄러운',
         'label:id': 'Mulus',
         'label:es': 'Suave',
         'label:pt': 'Suave',
         'label:fr': 'Lisse',
         'label:it': 'Scorrimento fluido',
         'label:tr': 'Düz',
         'label:de': 'Glatt',
         'label:pl': 'Płynnie',
         'label:ua': 'Плавно',
         type: 'checkbox',
      },
      scroll_to_top_autoplay: {
         _tagName: 'input',
         label: 'Video unPause',
         'label:zh': '视频取消暂停',
         'label:ja': 'ビデオの一時停止解除',
         'label:ko': '비디오 일시 중지 해제',
         'label:id': 'Video batalkan Jeda',
         'label:es': 'Reanudar video',
         'label:pt': 'Retomar vídeo',
         'label:fr': 'Annuler la pause de la vidéo',
         'label:it': 'Annulla pausa video',
         'label:tr': 'Videoyu Duraklat',
         'label:de': 'Video wieder anhalten',
         'label:pl': 'Wyłącz wstrzymanie odtwarzania filmu',
         'label:ua': 'Продовжити програвання відео',
         type: 'checkbox',
      },
   }
});
// for test
// https://www.youtube.com/channel/UC9qr4fem8L5HEx0IDoktEpw/videos - many live

window.nova_plugins.push({
   id: 'thumbs-hide',
   title: 'Thumbnails filtering',
   'title:zh': '缩略图过滤',
   'title:ja': 'サムネイルのフィルタリング',
   'title:ko': '썸네일 필터링',
   'title:id': 'Pemfilteran gambar mini',
   'title:es': 'Filtrado de miniaturas',
   'title:pt': 'Filtragem de miniaturas',
   'title:fr': 'Filtrage des vignettes',
   'title:it': 'Filtraggio miniature',
   'title:tr': 'Küçük resim filtreleme',
   'title:de': 'Filtrowanie miniatur',
   'title:pl': 'Ukryj kilka miniatur',
   'title:ua': 'Фільтрування мініатюр',
   run_on_pages: 'home, results, feed, channel, watch',
   section: 'other',
   _runtime: user_settings => {

      // alt - https://greasyfork.org/en/scripts/446507-youtube-sub-feed-filter-2

      const
         thumbsSelectors = [
            'ytd-rich-item-renderer', // home, channel
            'ytd-video-renderer', // results
            'ytd-grid-video-renderer', // feed
            'ytd-compact-video-renderer', // sidepanel in watch
            'ytm-compact-video-renderer', // mobile
         ]
            .join(',');

      // page update event
      document.addEventListener('yt-action', evt => {
         // console.log(evt.detail?.actionName);
         if ([
            'yt-append-continuation-items-action', // home, results, feed, channel, watch
            'ytd-update-grid-state-action', // feed, channel
            'yt-service-request', // results, watch
            'ytd-rich-item-index-update-action', // home
         ]
            .includes(evt.detail?.actionName)
         ) {
            switch (NOVA.currentPage) {
               case 'home':
                  thumbRemove.live();
                  thumbRemove.mix()
                  break;

               case 'results':
                  thumbRemove.live();
                  thumbRemove.shorts();
                  break;

               case 'feed':
                  thumbRemove.live();
                  thumbRemove.streamed();
                  thumbRemove.shorts();
                  thumbRemove.premieres();
                  thumbRemove.mix()
                  break;

               case 'channel':
                  thumbRemove.live();
                  thumbRemove.streamed();
                  thumbRemove.shorts();
                  thumbRemove.premieres();
                  break;

               case 'watch':
                  thumbRemove.live();
                  thumbRemove.mix()
                  break;

               // default:
               //    thumbRemove.live();
               //    break;
            }
         }
      });


      const thumbRemove = {
         shorts() {
            if (!user_settings.shorts_disable) return;
            // exсlude "short" tab in channel
            if (NOVA.currentPage == 'channel' && location.pathname.split('/').pop() == 'shorts') return;

            document.body.querySelectorAll('a#thumbnail[href*="shorts/"]')
               .forEach(el => el.closest(thumbsSelectors)?.remove());
            // for test
            // .forEach(el => {
            //       if (thumb = el.closest(thumbsSelectors)) {
            //          // thumb.remove();
            //          // thumb.style.display = 'none';

            //          // console.debug('#shorts:', thumb);
            //          thumb.style.border = '2px solid orange'; // mark for test
            //       }
            //    });

            if (+user_settings.shorts_disable_min_duration) {
               document.body.querySelectorAll('#thumbnail #overlays #text:not(:empty)')
                  .forEach(el => {
                     if ((thumb = el.closest(thumbsSelectors))
                        && NOVA.timeFormatTo.hmsToSec(el.textContent.trim()) < (+user_settings.shorts_disable_min_duration || 60)
                     ) {
                        thumb.remove();
                        // thumb.style.display = 'none';

                        // console.debug('#shorts:', thumb);
                        // thumb.style.border = '2px solid blue'; // mark for test
                     }
                  });
            }
         },

         premieres() {
            if (!user_settings.premieres_disable) return;
            // announced
            document.body.querySelectorAll(
               `#thumbnail #overlays [aria-label="Premiere"],
               #thumbnail #overlays [aria-label="Upcoming"]`
            )
               .forEach(el => el.closest(thumbsSelectors)?.remove());
            // for test
            // .forEach(el => {
            //    if (thumb = el.closest(thumbsSelectors)) {
            //       // thumb.remove();
            //       // thumb.style.display = 'none';

            //       console.debug('Premieres:', thumb);
            //       thumb.style.border = '2px solid red'; // mark for test
            //    }
            // });

            // streaming
            // #overlays > :not(ytd-thumbnail-overlay-time-status-renderer)
            // #video-badges > .badge-style-type-live-now-alternate
            document.body.querySelectorAll('#video-badges > [class*="live-now"]')
               .forEach(el => el.closest(thumbsSelectors)?.remove());
            // for test
            // .forEach(el => {
            //    if (thumb = el.closest(thumbsSelectors)) {
            //       // thumb.remove();
            //       // thumb.style.display = 'none';

            //       console.debug('Premieres:', thumb);
            //       thumb.style.border = '2px solid violet'; // mark for test
            //    }
            // });
         },

         live() {
            if (!user_settings.live_disable) return;
            // exсlude "LIVE" tab in channel
            if (NOVA.currentPage == 'channel' && location.pathname.split('/').pop() == 'streams') return;

            // #thumbnail #overlays [overlay-style="LIVE"],
            document.body.querySelectorAll('#thumbnail img[src*="_live.jpg"]')
               .forEach(el => el.closest(thumbsSelectors)?.remove());
            // for test
            // .forEach(el => {
            //    if (thumb = el.closest(thumbsSelectors)) {
            //       // thumb.remove();
            //       // thumb.style.display = 'none';

            //       console.debug('live now:', thumb);
            //       thumb.style.border = '2px solid orange'; // mark for test
            //    }
            // });
         },

         streamed() {
            if (!user_settings.streamed_disable) return;
            // exсlude "LIVE" tab in channel
            if (NOVA.currentPage == 'channel' && location.pathname.split('/').pop() == 'streams') return;

            document.body.querySelectorAll('#metadata-line > span.inline-metadata-item:last-of-type')
               .forEach(el => {
                  if (el.textContent?.split(' ').length === 4 // "Streamed 5 days ago"
                     && (thumb = el.closest(thumbsSelectors))) {
                     thumb.remove();
                     // thumb.style.display = 'none';

                     // console.debug('streamed:', thumb);
                     // thumb.style.border = '2px solid green'; // mark for test
                  }
               });
         },

         mix() {
            if (!user_settings.thumb_mix_disable) return;

            document.body.querySelectorAll(
               `a[href*="list="][href*="start_radio="]:not([hidden]),
               a[title^="Mix -"]:not([hidden])`
            )
               .forEach(el => el.closest(thumbsSelectors)?.remove());
            // for test
            // .forEach(el => {
            //    if (thumb = el.closest(thumbsSelectors)) {
            //       // thumb.style.display = 'none';
            //       console.debug('has Mix:', thumb);
            //       thumb.style.border = '2px solid red'; // mark for test
            //    }
            // });
         },
      };

   },
   options: {
      shorts_disable: {
         _tagName: 'input',
         label: 'Hide Shorts',
         'label:zh': '隐藏短裤',
         'label:ja': 'ショーツを隠す',
         'label:ko': '반바지 숨기기',
         'label:id': 'Sembunyikan Celana Pendek',
         'label:es': 'Ocultar pantalones cortos',
         'label:pt': 'Ocultar shorts',
         'label:fr': 'Masquer les shorts',
         'label:it': 'Nascondi pantaloncini',
         'label:tr': 'Şort Gizle',
         'label:de': 'Shorts verstecken',
         'label:pl': 'Ukryj YouTube Shorts',
         'label:ua': 'Приховати прев`ю',
         type: 'checkbox',
         // title: '',
      },
      shorts_disable_min_duration: {
         _tagName: 'input',
         label: 'Min duration in sec',
         'label:zh': '最短持续时间（以秒为单位）',
         'label:ja': '秒単位の最小期間',
         'label:ko': '최소 지속 시간(초)',
         'label:id': 'Durasi lebih sedikit dalam detik',
         'label:es': 'Duración mínima en segundos',
         'label:pt': 'Duração mínima em segundos',
         'label:fr': 'Durée minimale en secondes',
         'label:it': 'Meno durata in sec',
         'label:tr': 'Saniye cinsinden minimum süre',
         'label:de': 'Mindestdauer in Sekunden',
         'label:pl': 'Poniżej czasu trwania w sekundach',
         'label:ua': 'Мінімальна тривалість в секундах',
         type: 'number',
         // title: '60 - default',
         // title: 'Minimum duration in seconds',
         title: '0 - disable',
         placeholder: '60-300',
         step: 1,
         min: 0,
         max: 3600,
         value: 0,
         'data-dependent': { 'shorts_disable': true },
      },
      premieres_disable: {
         _tagName: 'input',
         label: 'Hide Premieres',
         // 'label:zh': '',
         'label:ja': 'プレミア公開を非表示',
         'label:ko': '프리미어 숨기기',
         'label:id': 'Sembunyikan pemutaran perdana',
         // 'label:es': '',
         // 'label:pt': '',
         // 'label:fr': '',
         // 'label:it': '',
         // 'label:tr': '',
         // 'label:de': '',
         'label:pl': 'Ukrywaj premiery',
         'label:ua': 'Приховати прем`єри',
         type: 'checkbox',
         title: 'Premiere Announcements',
      },
      live_disable: {
         _tagName: 'input',
         label: 'Hide Live Streams',
         // 'label:zh': '',
         // 'label:ja': '',
         // 'label:ko': '',
         // 'label:id': '',
         // 'label:es': '',
         // 'label:pt': '',
         // 'label:fr': '',
         // 'label:it': '',
         // 'label:tr': '',
         // 'label:de': '',
         'label:pl': 'Ukryj strumień (na żywo)',
         'label:ua': 'Приховати живі трансляції',
         type: 'checkbox',
         title: 'airing',
      },
      streamed_disable: {
         _tagName: 'input',
         label: 'Finished streams',
         'label:zh': '已完成的广播',
         'label:ja': '放送終了',
         'label:ko': '방송 후',
         'label:id': 'Siaran selesai Aliran selesai',
         'label:es': 'Emisiones completadas',
         'label:pt': 'Transmissões concluídas',
         'label:fr': 'Flux terminés',
         'label:it': 'Stream finiti',
         'label:tr': 'Bitmiş akışlar',
         'label:de': 'nach der Sendung',
         'label:pl': 'Po streamie',
         'label:ua': 'Завершені трансляції',
         type: 'checkbox',
         //title: '',
         'data-dependent': { 'live_disable': true },
      },
      thumbnails_mix_hide: {
         _tagName: 'input',
         label: "Hide 'Mix' thumbnails",
         'label:zh': '隐藏[混合]缩略图',
         'label:ja': '「Mix」サムネイルを非表示',
         'label:ko': '"믹스" 썸네일 숨기기',
         'label:id': 'Sembunyikan gambar mini "Mix"',
         'label:es': "Ocultar miniaturas de 'Mix'",
         'label:pt': "Ocultar miniaturas de 'Mix'",
         'label:fr': 'Masquer les vignettes "Mix"',
         'label:it': 'Nascondi le miniature "Mix".',
         'label:tr': "'Karıştır' küçük resimlerini gizle",
         'label:de': '„Mix“-Thumbnails ausblenden',
         'label:pl': 'Ukryj miniaturki "Mix"',
         'label:ua': 'Приховати мікс мініатюр',
         type: 'checkbox',
         title: '[Mix] offers to rewatch what has already saw',
         'title:zh': '[混合]提供重新观看已经看过的内容',
         'title:ja': '「Mix」は、すでに見たものを再視聴することを提案します',
         'title:ko': '[Mix]는 이미 본 것을 다시 볼 것을 제안합니다',
         'title:id': '[Mix] menawarkan untuk menonton ulang apa yang telah dilihat',
         'title:es': '[Mix] ofrece volver a ver lo que ya vio',
         'title:pt': '[Mix] se oferece para rever o que já viu',
         'title:it': '[Mix] si offre di rivedere ciò che ha già visto',
         'title:tr': '[Mix], daha önce görmüş olanı yeniden izlemeyi teklif ediyor',
         'title:de': '[Mix] bietet an, bereits Gesehenes noch einmal anzuschauen',
         'title:pl': '[Mix] proponuje ponowne obejrzenie już obejrzanych filmów',
         'title:ua': '[Mix] пропонує передивитися вже побачене',
      },
   }
});
window.nova_plugins.push({
   id: 'page-title-time',
   title: 'Show time in tab title',
   'title:zh': '在标签标题中显示时间',
   'title:ja': 'タブタイトルに時間を表示する',
   'title:ko': '탭 제목에 시간 표시',
   'title:id': 'Tampilkan waktu di judul tab',
   'title:es': 'Mostrar la hora en el título de la pestaña',
   'title:pt': 'Mostrar tempo no título da guia',
   'title:fr': "Afficher l'heure dans le titre de l'onglet",
   'title:it': "Mostra l'ora nel titolo della scheda",
   'title:tr': 'Sekme başlığında zamanı göster',
   'title:de': 'Zeit im Tab-Titel anzeigen',
   'title:pl': 'Pokaż czas w tytule karty',
   'title:ua': 'Відображення часу в заголовку вкладки',
   run_on_pages: 'watch',
   section: 'other',
   // desc: 'Show the current time of the video on the title',
   _runtime: user_settings => {

      NOVA.waitElement('video')
         .then(video => {
            // remove saved title
            document.addEventListener('yt-navigate-start', () => pageTitle.backup = null);
            // save title
            video.addEventListener('playing', pageTitle.save.bind(pageTitle));
            // update title
            video.addEventListener('timeupdate', () => pageTitle.update(video));
            // restore title
            video.addEventListener('pause', () => pageTitle.restore(video));
            video.addEventListener('ended', () => pageTitle.restore(video));
         });


      const pageTitle = {
         // backup: document.title,

         strSplit: ' | ',
         // strSplit: ' • ',

         save() {
            if (this.backup
               || movie_player.getVideoData().isLive // live
               || movie_player.classList.contains('ad-showing') // ad-video
               || new RegExp(`^((\\d?\\d:){1,2}\\d{2})(${this.strSplit.replace('|', '\\|')})`, '').test(document.title) // title has time "0:00:00${this.strSplit}"
            ) {
               return;
            }
            // this.backup = document.title;
            this.backup = movie_player.getVideoData().title;
            // console.debug('save', this.backup);
         },

         update(video = NOVA.videoElement) {
            if (!this.backup) return;

            let newTitleArr = [];

            switch (movie_player.getVideoData().isLive ? 'current' : user_settings.page_title_time_mode) {
               case 'current':
                  newTitleArr = [video.currentTime];
                  break;

               case 'current-duration':
                  if (!isNaN(video.duration)) {
                     newTitleArr = [video.currentTime, ' / ', video.duration]; // string
                  }
                  break;

               // case 'left':
               default:
                  if (!isNaN(video.duration)) {
                     newTitleArr = [video.duration - video.currentTime];
                  }
            }

            // add playbackRate if it is not default
            // if (this.playbackRate !== 1) newTitleArr.push(` (${this.playbackRate}x)`);

            newTitleArr = newTitleArr
               .map(t => typeof t === 'string' ? t : NOVA.timeFormatTo.HMS.digit(t / video.playbackRate))
               .join('');

            this.set([newTitleArr, this.backup]);
         },

         restore(video = NOVA.videoElement) {
            if (!this.backup) return;

            this.set([movie_player.getVideoData().isLive && video.currentTime, this.backup]);
         },

         set(arr) {
            document.title = arr
               .filter(Boolean) // filter null/undefined
               .join(this.strSplit);
         },
      };

   },
   options: {
      page_title_time_mode: {
         _tagName: 'select',
         label: 'Mode',
         'label:zh': '模式',
         'label:ja': 'モード',
         'label:ko': '방법',
         // 'label:id': 'Mode',
         'label:es': 'Modo',
         'label:pt': 'Modo',
         // 'label:fr': 'Mode',
         'label:it': 'Modalità',
         'label:tr': 'Mod',
         'label:de': 'Modus',
         'label:pl': 'Tryb',
         'label:ua': 'Режим',
         options: [
            // { label: 'current', value: 'current', 'label:ua': 'поточний', 'label:zh': '现在', 'label:ja': '現在', 'label:ko': '현재의', label:id': '', 'label:es': 'actual', 'label:pt': 'atual', 'label:fr': 'courant', 'label:it': '', 'label:tr': 'akım', 'label:de': 'strom' },
            { label: 'left', value: 'left', selected: true, 'label:zh': '剩下', 'label:ja': '左', 'label:ko': '왼쪽', /*'label:id': '',*/ 'label:es': 'izquierda', 'label:pt': 'deixou', 'label:fr': 'à gauche', /*'label:it': '',*/ 'label:tr': 'o ayrıldı', 'label:de': 'links', 'label:pl': 'pozostało', 'label:ua': 'Лишилось' },
            { label: 'current/duration', value: 'current-duration', 'label:zh': '现在/期间', 'label:ja': '現在/期間', 'label:ko': '현재/기간', /*'label:id': '',*/ 'label:es': 'actual/duración', 'label:pt': 'atual/duração', 'label:fr': 'courant/durée', /*'label:it': '',*/ 'label:tr': 'akım/süre', 'label:de': 'strom/dauer', 'label:pl': 'bieżący czas', 'label:ua': 'Поточний/Тривалість' },
         ],
      },
   }
});
// for test:
// https://www.youtube.com/channel/UCl7OsED7y9eavZJbTGnK0xg/playlists - select Albums & Singles
// https://www.youtube.com/c/cafemusicbgmchannel/videos - live

window.nova_plugins.push({
   id: 'thumbnails-clear',
   title: 'Clear thumbnails',
   'title:zh': '清除缩略图',
   'title:ja': 'サムネイルをクリアする',
   'title:ko': '썸네일 지우기',
   'title:id': 'Hapus gambar mini',
   'title:es': 'Miniaturas claras',
   'title:pt': 'Limpar miniaturas',
   'title:fr': 'Effacer les vignettes',
   'title:it': 'Cancella miniature',
   'title:tr': 'Küçük resimleri temizle',
   'title:de': 'Miniaturansichten löschen',
   'title:pl': 'Wyczyść miniatury',
   'title:ua': 'Очистити мініатюри',
   run_on_pages: 'home, results, feed, channel, watch',
   // run_on_pages: 'all, -embed',
   section: 'other',
   desc: 'Replaces the predefined clickbait thumbnails',
   'desc:zh': '替换预定义的缩略图',
   'desc:ja': '事前定義されたサムネイルを置き換えます',
   'desc:ko': '미리 정의된 축소판을 대체합니다',
   'desc:id': 'Menggantikan gambar mini yang telah ditentukan sebelumnya',
   'desc:es': 'Reemplaza la miniatura predefinida',
   'desc:pt': 'Substitui a miniatura predefinida',
   // 'desc:fr': 'Remplace la vignette prédéfinie',
   'desc:it': 'Sostituisce la miniatura predefinita',
   'desc:tr': 'Önceden tanımlanmış küçük resmi değiştirir',
   'desc:de': 'Ersetzt das vordefinierte Thumbnail',
   'desc:pl': 'Zastępuje predefiniowaną miniaturkę',
   'desc:ua': 'Замінює попередньо визначені мініатюри клікбейти',
   _runtime: user_settings => {

      const
         ATTR_MARK = 'nova-thumb-preview-cleared',
         thumbsSelectors = [
            // 'ytd-rich-item-renderer', // home, channel
            'ytd-video-renderer', // results
            'ytd-grid-video-renderer', // feed
            // 'ytd-compact-video-renderer', // sidepanel in watch
            // 'ytm-compact-video-renderer', // mobile
         ];

      // Doesn't work
      // page update
      // document.addEventListener('yt-action', evt => {
      //    console.log(evt.detail?.actionName);
      //    if ([
      //       'yt-append-continuation-items-action', // home, results, feed, channel, watch
      //       'ytd-update-grid-state-action', // feed, channel
      //       'yt-service-request', // results, watch
      //       // 'ytd-rich-item-index-update-action', // home
      //    ]
      //       .includes(evt.detail?.actionName)
      //    ) {
      //       patchThumb();
      //    }
      // });

      // function patchThumb() {
      //    document.body.querySelectorAll(`#thumbnail:not(.ytd-playlist-thumbnail) img[src]:not([src*="qdefault_live.jpg"]):not([${ATTR_MARK}])`)
      //       .forEach(img => {
      //          img.setAttribute(ATTR_MARK, true);
      //          img.src = patchImg(img.src);
      //       });
      // }

      let DISABLE_YT_IMG_DELAY_LOADING_default = false; // fix conflict with yt-flags

      // Strategy 2
      // dirty fix bug with not updating thumbnails
      document.addEventListener('yt-navigate-finish', () =>
         document.body.querySelectorAll(`[${ATTR_MARK}]`).forEach(e => e.removeAttribute(ATTR_MARK)));

      NOVA.watchElements({
         selectors: ['#thumbnail:not(.ytd-playlist-thumbnail):not([href*="/shorts/"]) img[src]:not([src*="qdefault_live.jpg"])'],
         attr_mark: ATTR_MARK,
         callback: async img => {
            // fix conflict with yt-flags
            if (window.yt?.config_?.DISABLE_YT_IMG_DELAY_LOADING
               && DISABLE_YT_IMG_DELAY_LOADING_default !== window.yt?.config_?.DISABLE_YT_IMG_DELAY_LOADING
            ) {
               // alert('Plugin "Clear thumbnails" not available with current page config');
               DISABLE_YT_IMG_DELAY_LOADING_default = window.yt?.config_?.DISABLE_YT_IMG_DELAY_LOADING;

               await NOVA.sleep(100); // dirty fix.
               // Hard reset fn
               document.body.querySelectorAll(`[${ATTR_MARK}]`).forEach(e => e.removeAttribute(ATTR_MARK));
            }

            // skip "premiere", "live now"
            if ((thumb = img.closest(thumbsSelectors))
               && thumb.querySelector(
                  `#badges [class*="live-now"],
                  #overlays [aria-label="PREMIERE"],
                  ytd-thumbnail-overlay-time-status-renderer [overlay-style="UPCOMING"]`)
            ) {
               // console.debug('skiped thumbnails-preview-cleared', parent);
               return;
            }
            img.src = patchImg(img.src);
         },
      });

      if (user_settings.thumbnails_clear_overlay) {
         NOVA.css.push(
            `#hover-overlays {
               visibility: hidden !important;
            }`);
      }

      // patch end card
      // if (user_settings.thumbnails_clear_videowall && !user_settings['disable-video-cards']) {
      //    // force show title
      //    NOVA.css.push(
      //       `.ytp-videowall-still .ytp-videowall-still-info-content {
      //          opacity: 1 !important;
      //          text-shadow: rgb(0, 0, 0) 0 0 .1em;
      //       }
      //       .ytp-videowall-still:not(:hover) .ytp-videowall-still-info-author,
      //       .ytp-videowall-still:not(:hover) .ytp-videowall-still-info-live {
      //          opacity: 0 !important;
      //       }`);

      //    NOVA.waitElement('#movie_player')
      //       .then(movie_player => {
      //          movie_player.addEventListener('onStateChange', state => {
      //             // console.debug('playerState', NOVA.getPlayerState(state));
      //             if (NOVA.getPlayerState(state) == 'ENDED') {
      //                document.body.querySelectorAll('.ytp-videowall-still-image[style*="qdefault.jpg"]')
      //                   .forEach(img => {
      //                      img.style.backgroundImage = patchImg(img.style.backgroundImage);
      //                   });
      //             }
      //          });
      //       });
      //    // Does manual change work at the end of video time
      //    // NOVA.waitElement('video')
      //    //    .then(video => {
      //    //       video.addEventListener('ended', () => {
      //    //          document.body.querySelectorAll('.ytp-videowall-still-image[style*="qdefault.jpg"]')
      //    //             .forEach(img => {
      //    //                img.style.backgroundImage = patchImg(img.style.backgroundImage);
      //    //             });
      //    //       });
      //    //    });
      // }

      function patchImg(str) {
         // hq1,hq2,hq3,hq720,default,sddefault,mqdefault,hqdefault,maxresdefault(excluding for thumbs)
         // /(hq(1|2|3|720)|(sd|mq|hq|maxres)?default)/i - unnecessarily exact
         if ((re = /(\w{1}qdefault|hq\d+).jpg/i) && re.test(str)) {
            return str.replace(re, (user_settings.thumbnails_clear_preview_timestamp || 'hq2') + '.jpg');
         }
      }

   },
   options: {
      thumbnails_clear_preview_timestamp: {
         _tagName: 'select',
         label: 'Thumbnail timestamps',
         'label:zh': '缩略图时间戳',
         'label:ja': 'サムネイルのタイムスタンプ',
         'label:ko': '썸네일 타임스탬프',
         'label:id': 'Stempel waktu gambar mini',
         'label:es': 'Marcas de tiempo en miniatura',
         'label:pt': 'Carimbos de data e hora em miniatura',
         'label:fr': 'Horodatages des vignettes',
         'label:it': 'Timestamp in miniatura',
         'label:tr': 'Küçük resim zaman damgaları',
         'label:de': 'Thumbnail-Zeitstempel',
         'label:pl': 'Znaczniki czasowe miniatur',
         'label:ua': 'Мітки часу мініатюр',
         title: 'Show thumbnail from video time position',
         'title:zh': '从视频时间位置显示缩略图',
         'title:ja': 'ビデオの時間位置からサムネイルを表示',
         'title:ko': '비디오 시간 위치에서 썸네일 표시',
         'title:id': 'Tampilkan thumbnail dari posisi waktu video',
         'title:es': 'Mostrar miniatura de la posición de tiempo del video',
         'title:pt': 'Mostrar miniatura da posição no tempo do vídeo',
         'title:fr': 'Afficher la vignette à partir de la position temporelle de la vidéo',
         'title:it': "Mostra la miniatura dalla posizione dell'ora del video",
         'title:tr': 'Video zaman konumundan küçük resmi göster',
         'title:de': 'Miniaturansicht von der Videozeitposition anzeigen',
         'title:pl': 'Pokaż miniaturkę z pozycji czasu wideo',
         'title:ua': 'Показати мініатюру з часової позиції відео',
         options: [
            { label: 'start', value: 'hq1', 'label:zh': '开始', 'label:ja': '始まり', 'label:ko': '시작', /*'label:id': '',*/ 'label:es': 'comienzo', 'label:pt': 'começar', 'label:fr': 'le début', /*'label:it': '',*/ 'label:tr': 'başlat', 'label:de': 'anfang', 'label:pl': 'początek', 'label:ua': 'Початок' }, // often shows intro
            { label: 'middle', value: 'hq2', selected: true, 'label:zh': '中间', 'label:ja': '真ん中', 'label:ko': '~ 아니다', /*'label:id': '',*/ 'label:es': 'medio', 'label:pt': 'meio', 'label:fr': 'ne pas', /*'label:it': '',*/ 'label:tr': 'orta', 'label:de': 'mitte', 'label:pl': 'środek', 'label:ua': 'Середина' },
            { label: 'end', value: 'hq3', 'label:zh': '结尾', 'label:ja': '終わり', 'label:ko': '끝', /*'label:id': '',*/ 'label:es': 'fin', 'label:pt': 'fim', 'label:fr': 'finir', /*'label:it': '',*/ 'label:tr': 'son', 'label:de': 'ende', 'label:pl': 'koniec', 'label:ua': 'Кінець' }
         ],
      },
      thumbnails_clear_overlay: {
         _tagName: 'input',
         label: 'Hide overlay buttons on a thumbnail',
         'label:zh': '隐藏覆盖在缩略图上的按钮',
         'label:ja': 'サムネイルにオーバーレイされたボタンを非表示にする',
         'label:ko': '축소판에서 오버레이 버튼 숨기기',
         'label:id': 'Sembunyikan tombol overlay pada thumbnail',
         'label:es': 'Ocultar botones superpuestos en una miniatura',
         'label:pt': 'Ocultar botões de sobreposição em uma miniatura',
         'label:fr': 'Masquer les boutons de superposition sur une vignette',
         'label:it': 'Nascondi pulsanti sovrapposti su una miniatura',
         'label:tr': 'Küçük resimdeki bindirme düğmelerini gizle',
         'label:de': 'Überlagerungsschaltflächen auf einer Miniaturansicht ausblenden',
         'label:pl': 'Ukryj przyciski nakładki na miniaturce',
         'label:ua': 'Приховати кнопки на мініатюрі',
         type: 'checkbox',
         title: 'Hide [ADD TO QUEUE] [WATCH LATER]',
      },
      // thumbnails_clear_videowall: {
      //    _tagName: 'input',
      //    label: 'Apply for thumbnails after video ends',
      //    'label:zh': '视频结束后申请缩略图',
      //    'label:ja': '動画終了後にサムネイルを申請する',
      //    'label:ko': '영상 종료 후 썸네일 신청',
      //    'label:id': 'Terapkan untuk thumbnail setelah video berakhir',
      //    'label:es': 'Solicitar miniaturas después de que termine el video',
      //    'label:pt': 'Candidate-se a miniaturas após o término do vídeo',
      //    'label:fr': 'Demander des vignettes après la fin de la vidéo',
      //    'label:it': 'Richiedi le miniature al termine del video',
      //    'label:tr': 'Video bittikten sonra küçük resimler için başvurun',
      //    'label:de': 'Bewerben Sie sich nach dem Ende des Videos für Thumbnails',
      //    'label:pl': 'Złóż wniosek o miniatury po zakończeniu filmu',
      //    'label:ua': 'Активувати для мініатюр після перегляду відео',
      //    type: 'checkbox',
      // },
   }
});
window.nova_plugins.push({
   id: 'search-filter',
   title: 'Blocked channels',
   'title:zh': '屏蔽频道列表',
   'title:ja': 'ブロックされたチャネルのリスト',
   'title:ko': '차단된 채널 목록',
   'title:id': 'Saluran yang diblokir',
   'title:es': 'Lista de canales bloqueados',
   'title:pt': 'Lista de canais bloqueados',
   'title:fr': 'Liste des chaînes bloquées',
   'title:it': 'Canali bloccati',
   'title:tr': 'Engellenen kanalların listesi',
   'title:de': 'Liste der gesperrten Kanäle',
   'title:pl': 'Zablokowane kanały',
   'title:ua': 'Заблоковані канали',
   run_on_pages: 'results',
   section: 'other',
   desc: 'Hide channels on the search page',
   'desc:zh': '在搜索页面上隐藏频道',
   'desc:ja': '検索ページでチャンネルを非表示にする',
   'desc:ko': '검색 페이지에서 채널 숨기기',
   'desc:id': 'Sembunyikan saluran di halaman pencarian',
   'desc:es': 'Ocultar canales en la página de búsqueda',
   'desc:pt': 'Ocultar canais na página de pesquisa',
   'desc:fr': 'Masquer les chaînes sur la page de recherche',
   'desc:it': 'Nascondi i canali nella pagina di ricerca',
   'desc:tr': 'Arama sayfasında kanalları gizle',
   'desc:de': 'Kanäle auf der Suchseite ausblenden',
   'desc:pl': 'Ukryj kanały na stronie wyszukiwania',
   'desc:ua': 'Приховує канали на сторінці пошуку',
   _runtime: user_settings => {

      // textarea to array
      const keywords = user_settings.search_filter_channel_blocklist
         ?.split(/[\n,;]/)
         .map(e => e.toString().trim().toLowerCase())
         .filter(e => e.length);

      NOVA.watchElements({
         selectors: [
            'ytd-video-renderer', // results
            'ytd-playlist-renderer', // playlist group
            'ytm-compact-video-renderer' // mobile
         ],
         attr_mark: 'thumb-search-filtered',
         callback: thumb => {
            keywords.forEach(keyword => {
               // if (thumb.querySelector('ytd-channel-name:not(:empty), .compact-media-item-byline:not(:empty)')?.textContent.toLowerCase().includes(keyword)) {
               if (thumb.$['channel-name']?.innerText.toLowerCase().includes(keyword)) {
                  thumb.remove();
                  // thumb.style.display = 'none';

                  // thumb.style.border = '2px solid red'; // mark for test
                  // console.log('filter removed', keyword, thumb);
               }
            });
         }
      });

   },
   options: {
      search_filter_channel_blocklist: {
         _tagName: 'textarea',
         label: 'List',
         'label:zh': '频道列表',
         'label:ja': 'チャンネルリスト',
         'label:ko': '채널 목록',
         'label:id': 'Daftar',
         'label:es': 'Lista',
         'label:pt': 'Lista',
         'label:fr': 'Liste',
         'label:it': 'Elenco',
         'label:tr': 'Listesi',
         'label:de': 'Liste',
         'label:pl': 'Lista',
         'label:ua': 'Список',
         title: 'separator: "," or ";" or "new line"',
         'title:zh': '分隔器： "," 或 ";" 或 "新队"',
         'title:ja': 'セパレータ： "," または ";" または "改行"',
         'title:ko': '구분 기호: "," 또는 ";" 또는 "새 줄"',
         'title:id': 'pemisah: "," atau ";" atau "baris baru"',
         'title:es': 'separador: "," o ";" o "new line"',
         'title:pt': 'separador: "," ou ";" ou "new line"',
         'title:fr': 'séparateur : "," ou ";" ou "nouvelle ligne"',
         'title:it': 'separatore: "," o ";" o "nuova linea"',
         'title:tr': 'ayırıcı: "," veya ";" veya "new line"',
         'title:de': 'separator: "," oder ";" oder "new line"',
         'title:pl': 'separator: "," lub ";" lub "now linia"',
         'title:ua': 'розділювач: "," або ";" або "новий рядок"',
         placeholder: 'channel1, channel2',
         required: true,
      },
   }
});
// for test
// https://www.youtube.com/shorts/5ndfxasp2r0

window.nova_plugins.push({
   id: 'shorts-redirect',
   title: 'Redirect Shorts to regular (watch) URLs',
   'title:zh': '将 Shorts 重定向到常规（watch）URL',
   'title:ja': 'ショートパンツを通常の（watch）URLにリダイレクトする',
   'title:ko': 'Shorts를 일반(watch) URL로 리디렉션',
   'title:id': 'Redirect Shorts ke URL reguler (watch)',
   'title:es': 'Redirigir Shorts a URL normales (watch)',
   'title:pt': 'Redirecionar Shorts para URLs regulares (watch)',
   'title:fr': 'Rediriger les shorts vers des URL normales (watch)',
   'title:it': 'Reindirizza i cortometraggi a URL normali (watch).',
   'title:tr': "Shorts'ları normal (watch) URL'lerine yönlendirin",
   'title:de': 'Leiten Sie Shorts zu regulären (watch) URLs um',
   'title:pl': 'Przełączaj Shorts na zwykłe adresy URL',
   'title:ua': 'Перенаправляйте прев`ю на звичайні URL-адреси (для перегляду)',
   run_on_pages: 'results, feed, channel, shorts',
   // restart_on_transition: true,
   section: 'other',
   desc: 'Redirect Shorts video to normal player',
   'desc:zh': '将 Shorts 视频重定向到普通播放器',
   'desc:ja': 'ショートパンツのビデオを通常のプレーヤーにリダイレクトする',
   'desc:ko': 'Shorts 비디오를 일반 플레이어로 리디렉션',
   'desc:id': 'Redirect video Shorts ke pemutar normal',
   'desc:es': 'Redirigir el video de Shorts al reproductor normal',
   'desc:pt': 'Redirecionar o vídeo do Shorts para o player normal',
   'desc:fr': 'Rediriger la vidéo Short vers un lecteur normal',
   'desc:it': 'Reindirizza il video dei cortometraggi al lettore normale',
   'desc:tr': 'Shorts videosunu normal oynatıcıya yönlendir',
   'desc:de': 'Shorts-Video auf normalen Player umleiten',
   'desc:pl': 'Przełącza krótkie filmy do normalnego odtwarzacza',
   'desc:ua': 'Перенаправляйте прев`ю відео у звичайний відтворювач',
   _runtime: user_settings => {

      // page init
      redirectPageToNormal();
      // page update
      document.addEventListener('yt-navigate-finish', redirectPageToNormal);

      function redirectPageToNormal() {
         if ('shorts' == NOVA.currentPage) {
            // alt - https://github.com/YukisCoffee/yt-anti-shorts/blob/main/anti-shorts.user.js
            // alt2 - https://greasyfork.org/en/scripts/444710-byts-better-youtube-shorts-greasyfork-edition
            return location.href = location.href.replace('shorts/', 'watch?v=');
            // location.replace(location.href.replace('/shorts/', '/watch?v='));
         }
      }

      // add time to overlay
      if (user_settings.shorts_thumbnails_time
         && !user_settings['shorts_disable'] // conflict with plugin. Attention! After shorts redirect
      ) {

         // Strategy 1
         document.addEventListener('yt-action', evt => {
            // console.log(evt.detail?.actionName);
            if ([
               'yt-append-continuation-items-action', // home, results, feed, channel, watch
               'ytd-update-grid-state-action', // feed, channel
               'yt-service-request', // results, watch
               // 'ytd-rich-item-index-update-action', // home
            ]
               .includes(evt.detail?.actionName)
            ) {
               patchThumbShort();
            }
         });
      }

      const
         // ATTR_MARK = 'nova-thumb-shorts-pathed',
         linkQueryPatch = '&list=RDSH',
         thumbsSelectors = [
            'ytd-rich-item-renderer', // home, channel
            'ytd-video-renderer', // results
            'ytd-grid-video-renderer', // feed
            // 'ytd-compact-video-renderer', // sidepanel in watch
            'ytm-compact-video-renderer', // mobile
         ]
            .join(',');

      function patchThumbShort() {
         document.body.querySelectorAll(`a[href*="/shorts/"]:not([href$="${linkQueryPatch}"])`)
            .forEach(link => {
               link.href += linkQueryPatch; // fix href redirect to watch
               // link.href = link.href.replace('shorts/', 'watch?v=');

               if (thumb = link.closest(thumbsSelectors)) {
                  // console.debug('has #shorts:', thumb);
                  // thumb.style.border = '2px solid orange'; // mark for test

                  NOVA.waitElement('ytd-thumbnail-overlay-time-status-renderer', link)
                     .then(async overlay => {
                        if ((thumb = link.closest(thumbsSelectors)?.data)
                           && (time = getThumbTime(thumb))
                        ) {
                           // console.debug('time', time);
                           overlay.setAttribute('overlay-style', 'DEFAULT');
                           // if (timeLabelEl = overlay.querySelector('#text')) {
                           if (timeLabelEl = overlay.$['text']) {
                              timeLabelEl.textContent = time;
                           }
                        }
                     });
               }
            });
      }

      // Strategy 2

      // clear before restart_on_transition
      // document.addEventListener('yt-navigate-start', () =>
      //    NOVA.clear_watchElements(ATTR_MARK), { capture: true, once: true });

      // fix clear thumb on page update (change sort etc.)
      // document.addEventListener('yt-page-data-updated', () =>
      // document.addEventListener('yt-navigate-finish', () =>
      // document.body.querySelectorAll(`[${ATTR_MARK}]`).forEach(e => e.removeAttribute(ATTR_MARK))
      // , { capture: true, once: true });

      // NOVA.watchElements({
      //    selectors: ['a[href*="shorts/"]'],
      //    attr_mark: ATTR_MARK,
      //    callback: link => {
      //       link.href += '&list=RDSH'; // fix href redirect to watch
      //       // link.href = link.href.replace('shorts/', 'watch?v=');

      //       // console.debug('has #shorts:', link);
      //       // link.style.border = '2px solid green'; // mark for test

      //       // add time to overlay
      //       if (user_settings.shorts_thumbnails_time) {
      //          NOVA.waitElement('ytd-thumbnail-overlay-time-status-renderer', link)
      //             .then(async overlay => {
      //                if ((thumb = link.closest(thumbsSelectors))
      //                   && (time = getThumbTime(thumb.data))
      //                ) {
      //                   // console.debug('time', time);
      //                   console.debug('', overlay);
      //                   overlay.setAttribute('overlay-style', 'DEFAULT');
      //                   if (timeLabelEl = overlay.querySelector('#text')) {
      //                      timeLabelEl.textContent = time;
      //                   }
      //                }
      //             });
      //       }
      //    },
      // });

      function getThumbTime(videoData = required()) {
         // alt - https://github.com/YukisCoffee/yt-anti-shorts/blob/main/anti-shorts.user.js#L189 (extractLengthFromA11y fn)
         // document.body.querySelectorAll("ytd-video-renderer, ytd-grid-video-renderer")
         //    .forEach(videoRenderer => {
         const
            // videoData = videoRenderer.data,
            title = videoData.title.accessibility.accessibilityData?.label,
            publishedTimeText = videoData.publishedTimeText?.simpleText,
            viewCountText = videoData.viewCountText?.simpleText;

         let
            [minutes, seconds] = title.split(publishedTimeText)[1]?.split(viewCountText)[0] // "12 minutes, 17 seconds "
               ?.split(/\D/, 2).filter(Number).map(s => (+s === 1 ? 60 : +s) - 1); // fix minutes and offest

         if (!seconds) { // fix mixed up in places
            seconds = minutes;
            minutes = null;
         }
         if (String(seconds).length === 1) {// fix "0:3" > "0:30"
            seconds += '0';
         }
         // console.debug('>', [minutes, seconds]);
         return [minutes || 0, seconds].join(':');
         // });
      }

   },
   options: {
      shorts_thumbnails_time: {
         _tagName: 'input',
         label: 'Add time on thumbnails overlay',
         'label:zh': '在缩略图叠加上添加时间',
         'label:ja': 'サムネイルオーバーレイに時間を追加',
         'label:ko': '썸네일 오버레이에 시간 추가',
         'label:id': 'Tambahkan waktu pada hamparan gambar mini',
         'label:es': 'Agregar tiempo en la superposición de miniaturas',
         'label:pt': 'Adicionar tempo na sobreposição de miniaturas',
         'label:fr': 'Ajouter du temps sur la superposition des vignettes',
         'label:it': 'Aggiungi tempo sulla sovrapposizione delle miniature',
         'label:tr': 'Küçük resim yer paylaşımına zaman ekleyin',
         'label:de': 'Fügen Sie Zeit für die Überlagerung von Miniaturansichten hinzu',
         'label:pl': 'Dodaj czas na nakładce miniatur',
         'label:ua': 'Додайте час на накладення мініатюр',
         type: 'checkbox',
         // title: '',
      },
   }
});
window.nova_plugins.push({
   id: 'thumbs-title-filter',
   title: 'Block thumbnails by title',
   'title:zh': '按标题阻止缩略图',
   'title:ja': 'タイトルでサムネイルをブロックする',
   'title:ko': '제목으로 축소판 차단',
   'title:id': 'Blokir gambar mini berdasarkan judul',
   'title:es': 'Bloquear miniaturas por título',
   'title:pt': 'Bloquear miniaturas por título',
   'title:fr': 'Bloquer les vignettes par titre',
   'title:it': 'Blocca le miniature per titolo',
   'title:tr': 'Küçük resimleri başlığa göre engelle',
   'title:de': 'Thumbnails nach Titel blockieren',
   'title:pl': 'Blokuj miniatury według tytułu',
   'title:ua': 'Блокуйте мініатюри за назвою',
   run_on_pages: 'all, -embed, -mobile',
   section: 'other',
   // desc: '',
   _runtime: user_settings => {

      const keywords = user_settings.thumb_filter_title_blocklist
         ?.split(/[\n,;]/)
         .map(e => e.toString().trim().toLowerCase())
         .filter(e => e.length);

      const thumbsSelectors = [
         'ytd-rich-item-renderer', // home, channel
         'ytd-video-renderer', // results
         'ytd-grid-video-renderer', // feed
         'ytd-compact-video-renderer', // sidepanel in watch
         'ytm-compact-video-renderer', // mobile
      ]
         .join(',');

      // Strategy 1. More optimize.
      // page update
      document.addEventListener('yt-action', evt => {
         // console.log(evt.detail?.actionName);
         if ([
            'yt-append-continuation-items-action', // home, results, feed, channel, watch
            'ytd-update-grid-state-action', // feed, channel
            'yt-service-request', // results, watch
            // 'ytd-rich-item-index-update-action', // home
         ]
            .includes(evt.detail?.actionName)
         ) {
            hideThumb();
         }
      });

      function hideThumb() {
         document.body.querySelectorAll('#video-title')
            .forEach(el => {
               keywords.forEach(keyword => {
                  if (el.textContent.toLowerCase().includes(keyword) && (thumb = el.closest(thumbsSelectors))) {
                     thumb.remove();
                     // thumb.style.display = 'none';

                     // console.log('filter removed', keyword, thumb);
                     // thumb.style.border = '2px solid orange'; // mark for test
                  }
               });
            });
      }

      // NOVA.watchElements({
      //    selectors: [
      //       'ytd-rich-item-renderer', // home
      //       'ytd-video-renderer', // results
      //       'ytd-grid-video-renderer', // feed, channel
      //       'ytd-compact-video-renderer', // sidepanel in watch
      //       'ytm-compact-video-renderer', // mobile
      //    ],
      //    attr_mark: 'thumb-title-filtered',
      //    callback: thumb => {
      //       keywords.forEach(keyword => {
      //          if (thumb.querySelector('#video-title')?.textContent.toLowerCase().includes(keyword)) {
      //             thumb.remove();
      //             // thumb.style.border = '2px solid orange'; // mark for test
      //             // console.log('filter removed', keyword, thumb);
      //          }
      //       });
      //    }
      // });

   },
   options: {
      thumb_filter_title_blocklist: {
         _tagName: 'textarea',
         label: 'Words list',
         'label:zh': '单词列表',
         'label:ja': '単語リスト',
         'label:ko': '단어 목록',
         'label:id': 'Daftar kata',
         'label:es': 'lista de palabras',
         'label:pt': 'Lista de palavras',
         'label:fr': 'Liste de mots',
         'label:it': 'Elenco di parole',
         'label:tr': 'Kelime listesi',
         'label:de': 'Wortliste',
         'label:pl': 'Lista słów',
         'label:ua': 'Список слів',
         title: 'separator: "," or ";" or "new line"',
         'title:zh': '分隔器： "," 或 ";" 或 "新队"',
         'title:ja': 'セパレータ： "," または ";" または "改行"',
         'title:ko': '구분 기호: "," 또는 ";" 또는 "새 줄"',
         'title:id': 'pemisah: "," atau ";" atau "baris baru"',
         'title:es': 'separador: "," o ";" o "new line"',
         'title:pt': 'separador: "," ou ";" ou "new line"',
         'title:fr': 'séparateur : "," ou ";" ou "nouvelle ligne"',
         'title:it': 'separatore: "," o ";" o "nuova linea"',
         'title:tr': 'ayırıcı: "," veya ";" veya "new line"',
         'title:de': 'separator: "," oder ";" oder "new line"',
         'title:pl': 'separator: "," lub ";" lub "now linia"',
         'title:ua': 'розділювач: "," або ";" або "новий рядок"',
         placeholder: 'text1, text2',
         required: true,
      },
   }
});
// for test - https://www.youtube.com/c/miyanomamoru/featured

window.nova_plugins.push({
   id: 'channel-trailer-stop-preload',
   title: 'Stop channel trailer',
   'title:zh': '停止频道预告片',
   'title:ja': 'チャンネルの予告編を停止する',
   'title:ko': '채널 예고편 중지',
   'title:id': 'Hentikan cuplikan saluran',
   'title:es': 'Detener el tráiler del canal',
   'title:pt': 'Parar o trailer do canal',
   'title:fr': 'Arrêter la bande-annonce de la chaîne',
   'title:it': 'Interrompi il trailer del canale',
   'title:tr': 'Kanal fragmanını durdur',
   'title:de': 'Kanaltrailer stoppen',
   'title:pl': 'Zatrzymaj zwiastun kanału',
   'title:ua': 'Не відтворювати трейлер каналу',
   run_on_pages: 'channel, -mobile',
   restart_on_transition: true,
   section: 'channel',
   // desc: '',
   _runtime: user_settings => {

      NOVA.waitElement('#c4-player')
         .then(player => player.stopVideo());

   },
});
window.nova_plugins.push({
   id: 'thumbnails-title-normalize',
   title: 'Decapitalize thumbnails title',
   'title:zh': '从大写中删除缩略图标题',
   'title:ja': 'サムネイルのタイトルを大文字から外す',
   'title:ko': '썸네일 제목을 대문자로',
   'title:id': 'Judul gambar mini decapitalize',
   'title:es': 'Descapitalizar el título de las miniaturas',
   'title:pt': 'Decapitalize o título das miniaturas',
   'title:fr': 'Démajuscule le titre des vignettes',
   'title:it': 'Decapitalizza il titolo delle miniature',
   'title:tr': 'Küçük resim başlığının büyük harflerini kaldır',
   'title:de': 'Thumbnails-Titel entfernen',
   'title:pl': 'Zmniejsz czcionkę w tytule miniatur',
   'title:ua': 'Завжди маленькі літери для назв мініатюр',
   run_on_pages: 'home, feed, channel, watch, -results',
   // run_on_pages: 'home, results, feed, channel, watch',
   // run_on_pages: 'all, -embed, -results',
   section: 'other',
   desc: 'Upper Case thumbnails title back to normal',
   'desc:ua': 'Зняти слова з великої літери для назв мініатюр',
   _runtime: user_settings => {

      const
         VIDEO_TITLE_SELECTOR = '#video-title:not(:empty):not([hidden]), a > h3.large-media-item-headline:not(:empty):not([hidden]), h1.title',
         MAX_CAPS_LETTERS = +user_settings.thumbnails_title_normalize_smart_max_words || 2,
         ATTR_MARK = 'nova-thumb-title-normalized',
         clearOfEmoji = str => str.replace(/[^\p{L}\p{N}\p{P}\p{Z}{\^\$}]/gu, ' ').replace(/\s{2,}/g, ' ');

      // dirty fix bug with not updating thumbnails
      let oldSortQuery = NOVA.queryURL.get('sort');
      document.addEventListener('yt-navigate-finish', () => {
         if ((sortQuery = NOVA.queryURL.get('sort')) && sortQuery != oldSortQuery) {
            oldSortQuery = sortQuery;
            location.reload();
         }
      });
      // // document.addEventListener('yt-page-data-updated', () =>
      // document.addEventListener('yt-navigate-finish', () =>
      //    document.body.querySelectorAll(`[${ATTR_MARK}]`).forEach(e => e.removeAttribute(ATTR_MARK)));

      if (user_settings.thumbnails_title_normalize_show_full) {
         NOVA.css.push(
            VIDEO_TITLE_SELECTOR + `{
               display: block !important;
               max-height: unset !important;
            }`);
      }

      // Letters(Lu) + Dash punctuation(Pd) + Decimal number(Nd): Upper case letter unicode - https://apps.timwhitlock.info/js/regex
      const UpperCaseLetterRegex = new RegExp("([\-0-9A-ZÀ-ÖØ-ÞĀĂĄĆĈĊČĎĐĒĔĖĘĚĜĞĠĢĤĦĨĪĬĮİĲĴĶĹĻĽĿŁŃŅŇŊŌŎŐŒŔŖŘŚŜŞŠŢŤŦŨŪŬŮŰŲŴŶŸ-ŹŻŽƁ-ƂƄƆ-ƇƉ-ƋƎ-ƑƓ-ƔƖ-ƘƜ-ƝƟ-ƠƢƤƦ-ƧƩƬƮ-ƯƱ-ƳƵƷ-ƸƼǄǇǊǍǏǑǓǕǗǙǛǞǠǢǤǦǨǪǬǮǱǴǶ-ǸǺǼǾȀȂȄȆȈȊȌȎȐȒȔȖȘȚȜȞȠȢȤȦȨȪȬȮȰȲȺ-ȻȽ-ȾɁɃ-ɆɈɊɌɎͰͲͶΆΈ-ΊΌΎ-ΏΑ-ΡΣ-ΫϏϒ-ϔϘϚϜϞϠϢϤϦϨϪϬϮϴϷϹ-ϺϽ-ЯѠѢѤѦѨѪѬѮѰѲѴѶѸѺѼѾҀҊҌҎҐҒҔҖҘҚҜҞҠҢҤҦҨҪҬҮҰҲҴҶҸҺҼҾӀ-ӁӃӅӇӉӋӍӐӒӔӖӘӚӜӞӠӢӤӦӨӪӬӮӰӲӴӶӸӺӼӾԀԂԄԆԈԊԌԎԐԒԔԖԘԚԜԞԠԢԱ-Ֆ֊־٠-٩۰-۹߀-߉०-९০-৯੦-੯૦-૯୦-୯௦-௯౦-౯೦-೯൦-൯๐-๙໐-໙༠-༩၀-၉႐-႙Ⴀ-Ⴥ០-៩᠆᠐-᠙᥆-᥏᧐-᧙᭐-᭙᮰-᮹᱀-᱉᱐-᱙ḀḂḄḆḈḊḌḎḐḒḔḖḘḚḜḞḠḢḤḦḨḪḬḮḰḲḴḶḸḺḼḾṀṂṄṆṈṊṌṎṐṒṔṖṘṚṜṞṠṢṤṦṨṪṬṮṰṲṴṶṸṺṼṾẀẂẄẆẈẊẌẎẐẒẔẞẠẢẤẦẨẪẬẮẰẲẴẶẸẺẼẾỀỂỄỆỈỊỌỎỐỒỔỖỘỚỜỞỠỢỤỦỨỪỬỮỰỲỴỶỸỺỼỾἈ-ἏἘ-ἝἨ-ἯἸ-ἿὈ-ὍὙὛὝὟὨ-ὯᾸ-ΆῈ-ΉῘ-ΊῨ-ῬῸ-Ώ‐-―ℂℇℋ-ℍℐ-ℒℕℙ-ℝℤΩℨK-ℭℰ-ℳℾ-ℿⅅↃⰀ-ⰮⱠⱢ-ⱤⱧⱩⱫⱭ-ⱯⱲⱵⲀⲂⲄⲆⲈⲊⲌⲎⲐⲒⲔⲖⲘⲚⲜⲞⲠⲢⲤⲦⲨⲪⲬⲮⲰⲲⲴⲶⲸⲺⲼⲾⳀⳂⳄⳆⳈⳊⳌⳎⳐⳒⳔⳖⳘⳚⳜⳞⳠⳢ⸗⸚〜〰゠꘠-꘩ꙀꙂꙄꙆꙈꙊꙌꙎꙐꙒꙔꙖꙘꙚꙜꙞꙢꙤꙦꙨꙪꙬꚀꚂꚄꚆꚈꚊꚌꚎꚐꚒꚔꚖꜢꜤꜦꜨꜪꜬꜮꜲꜴꜶꜸꜺꜼꜾꝀꝂꝄꝆꝈꝊꝌꝎꝐꝒꝔꝖꝘꝚꝜꝞꝠꝢꝤꝦꝨꝪꝬꝮꝹꝻꝽ-ꝾꞀꞂꞄꞆꞋ꣐-꣙꤀-꤉꩐-꩙︱-︲﹘﹣－０-９Ａ-Ｚ]|\ud801[\udc00-\udc27\udca0-\udca9]|\ud835[\udc00-\udc19\udc34-\udc4d\udc68-\udc81\udc9c\udc9e-\udc9f\udca2\udca5-\udca6\udca9-\udcac\udcae-\udcb5\udcd0-\udce9\udd04-\udd05\udd07-\udd0a\udd0d-\udd14\udd16-\udd1c\udd38-\udd39\udd3b-\udd3e\udd40-\udd44\udd46\udd4a-\udd50\udd6c-\udd85\udda0-\uddb9\uddd4-\udded\ude08-\ude21\ude3c-\ude55\ude70-\ude89\udea8-\udec0\udee2-\udefa\udf1c-\udf34\udf56-\udf6e\udf90-\udfa8\udfca\udfce-\udfff]){2,}", 'g');

      // Doesn't work.
      // // first letter uppercase
      // NOVA.css.push({
      //    'text-transform': 'uppercase',
      //    // color: '#8A2BE2', // indicator
      // }, `[${ATTR_MARK}]:first-letter`, 'important');

      NOVA.watchElements({
         selectors: VIDEO_TITLE_SELECTOR,
         attr_mark: ATTR_MARK,
         callback: title => {
            let countCaps = 0;
            const normalizedText = title.textContent.replace(UpperCaseLetterRegex, match => {
               // console.debug('match', match);
               countCaps++;
               // skip hasNumber
               return /\d/.test(match) ? match : match.toLowerCase();
            });

            // Upper case
            if (countCaps > MAX_CAPS_LETTERS) {
               title.textContent = normalizedText.trim();
               // console.debug('normalize:', countCaps, '\n' + title.title, '\n' + title.textContent);
            }

            if (user_settings.thumbnails_title_clear_emoji) {
               title.textContent = clearOfEmoji(title.textContent);
            }
         }
      });

   },
   options: {
      thumbnails_title_normalize_show_full: {
         _tagName: 'input',
         label: 'Show full title',
         'label:zh': '显示完整标题',
         'label:ja': '完全なタイトルを表示',
         'label:ko': '전체 제목 표시',
         'label:id': 'Tampilkan judul lengkap',
         'label:es': 'Mostrar título completo',
         'label:pt': 'Mostrar título completo',
         'label:fr': 'Afficher le titre complet',
         'label:it': 'Mostra il titolo completo',
         'label:tr': 'Tam başlığı göster',
         'label:de': 'Vollständigen Titel anzeigen',
         'label:pl': 'Pokaż pełny tytuł',
         'label:ua': 'Показати повну назву',
         type: 'checkbox'
      },
      thumbnails_title_normalize_smart_max_words: {
         _tagName: 'input',
         label: 'Max words in uppercase',
         'label:zh': '大写字数上限',
         'label:ja': '大文字の最大単語数',
         'label:ko': '대문자의 최대 단어 수',
         'label:id': 'Maks kata dalam huruf besar',
         'label:es': 'Máximo de palabras en mayúsculas',
         'label:pt': 'Máximo de palavras em maiúsculas',
         'label:fr': 'Mots maximum en majuscules',
         'label:it': 'Max parole in maiuscolo',
         'label:tr': 'Büyük harfli maksimum kelime',
         'label:de': 'Maximale Wörter in Großbuchstaben',
         'label:pl': 'Maksymalna liczba słów pisanych wielkimi literami',
         'label:ua': 'Максимальна кількість слів ВЕЛИКИМИ літерами',
         type: 'number',
         // title: '',
         placeholder: '1-10',
         min: 1,
         max: 10,
         value: 2,
      },
      thumbnails_title_clear_emoji: {
         _tagName: 'input',
         label: 'Clear emoji',
         'label:zh': '从表情符号中清除标题',
         'label:ja': 'クリア絵文字',
         'label:ko': '이모티콘 지우기',
         'label:id': 'Hapus emoji',
         'label:es': 'Borrar emoji',
         'label:pt': 'Limpar emoji',
         'label:fr': 'Emoji clair',
         'label:it': 'Emoji trasparenti',
         'label:tr': 'Emojiyi temizle',
         'label:de': 'Emoji löschen',
         'label:pl': 'Usuń emoji',
         'label:ua': 'Очистити емодзі',
         type: 'checkbox',
      },
   }
});
window.nova_plugins.push({
   id: 'miniplayer-disable',
   title: 'Disable miniplayer',
   // 'title:zh': '',
   // 'title:ja': '',
   // 'title:ko': '',
   // 'title:id': '',
   // 'title:es': '',
   // 'title:pt': '',
   // 'title:fr': '',
   // 'title:it': '',
   // 'title:tr': '',
   // 'title:de': '',
   // 'title:pl': '',
   'title:ua': 'Вимкнути мінівідтворювач',
   run_on_pages: 'watch',
   section: 'other',
   // desc: '',
   _runtime: user_settings => {

      // hide player button
      NOVA.css.push(
         `.ytp-right-controls .ytp-miniplayer-button {
            display: none !important;
         }`);

      document.addEventListener('yt-action', evt => {
         if (NOVA.currentPage != 'watch' && evt.detail?.actionName.includes('miniplayer')) {
            // console.log(evt.detail?.actionName);
            // 'yt-cache-miniplayer-page-action'
            // 'yt-miniplayer-endpoint-changed'
            // 'yt-miniplayer-play-state-changed'
            // 'yt-miniplayer-active'
            document.body.querySelector('#movie_player button.ytp-miniplayer-close-button')?.click();
         }
      });

      // remove from page
      // NOVA.waitElement('.ytp-chrome-bottom button[class^="ytp-miniplayer"]')
      //    .then(() => {
      //       document.querySelectorAll('[class^="ytp-miniplayer"]')
      //          .forEach(el => el.remove());
      //    });

      // disable hotkey
      // document.addEventListener('keydown', ({ keyCode }) => (keyCode === 13)
      // document.addEventListener('keydown', ({ key }) => {
      // document.addEventListener('keydown', evt => {
      //    if (['input', 'textarea'].includes(target.localName) || target.isContentEditable) return;
      //    // if (NOVA.currentPage == 'watch' && evt.code === 'KeyI') {
      //    if (NOVA.currentPage == 'watch' && evt.key === 'i') {
      //       alert(1);
      //       evt.preventDefault(); // Doesn't work. Replace to preventDefault patch
      //       evt.stopImmediatePropagation(); // Doesn't work. Replace to preventDefault patch
      //       evt.stopPropagation(); // Doesn't work. Replace to preventDefault patch
      //    }
      // });

   },
});
// http://babruisk.com/ - test embed page

window.nova_plugins.push({
   id: 'pause-background-tab',
   // title: 'only one player instance playing',
   // title: 'Autopause when switching tabs',
   // title: 'Pauses playing videos in other tabs',
   title: 'Autopause all background tabs except the active one',
   'title:zh': '自动暂停除活动选项卡以外的所有选项卡',
   'title:ja': 'アクティブなタブを除くすべてのタブを自動一時停止',
   'title:ko': '활성 탭을 제외한 모든 탭 자동 일시 중지',
   'title:id': 'Jeda otomatis semua tab latar belakang kecuali yang aktif',
   'title:es': 'Pausar automáticamente todas las pestañas excepto la activa',
   'title:pt': 'Pausar automaticamente todas as guias, exceto a ativa',
   'title:fr': "Interrompt la lecture des vidéos dans d'autres onglets",
   'title:it': 'Metti automaticamente in pausa tutte le schede in background tranne quella attiva',
   'title:tr': 'Etkin olan dışındaki tüm sekmeleri otomatik duraklat',
   'title:de': 'Alle Tabs außer dem aktiven automatisch pausieren',
   'title:pl': 'Zatrzymanie kart w tle oprócz aktywnej',
   'title:ua': 'Автобауза усіх фонових вкладок окрім активної',
   run_on_pages: 'watch, embed',
   section: 'player',
   desc: 'Supports iframes and other windows',
   'desc:zh': '支持 iframe 和其他窗口',
   'desc:ja': 'iframeやその他のウィンドウをサポート',
   'desc:ko': 'iframe 및 기타 창 지원',
   'desc:id': 'Mendukung iframe dan jendela lainnya',
   'desc:es': 'Soporta iframes y otras ventanas',
   'desc:pt': 'Suporta iframes e outras janelas',
   'desc:fr': 'Prend en charge les iframes et autres fenêtres',
   'desc:it': 'Supporta iframe e altre finestre',
   'desc:tr': "iframe'leri ve diğer pencereleri destekler",
   'desc:de': 'Unterstützt iframes und andere Fenster',
   'desc:pl': 'Obsługa ramek iframe i innych okien',
   'desc:ua': 'Підтримує iframe та інші вікна',
   _runtime: user_settings => {

      // redirect for localStorage common storage space
      if (location.hostname.includes('youtube-nocookie.com')) location.hostname = 'youtube.com';

      const
         storeName = 'playngInstanceIDTab',
         currentPageName = NOVA.currentPage, // watch or embed. Unchanged during the transition
         instanceID = Math.random(), // Generate a random script instance ID
         removeStorage = () => localStorage.removeItem(storeName);

      NOVA.waitElement('video')
         .then(video => {
            // mark a playing
            video.addEventListener('playing', () => localStorage.setItem(storeName, instanceID));
            // remove mark if video stop play
            ['pause', 'suspend', 'ended'].forEach(evt => video.addEventListener(evt, removeStorage));
            // remove mark if tab closed
            window.addEventListener('beforeunload', removeStorage);

            // auto play on tab focus
            if (user_settings.pause_background_tab_autoplay_onfocus) {
               // document.addEventListener('visibilitychange', () => {
               //    // if other tabs are not playing
               //    if (document.visibilityState == 'visible'
               //       && !localStorage.hasOwnProperty(storeName) // store empty
               //       // && video.paused  // dont see ENDED
               //       && ['UNSTARTED', 'PAUSED'].includes(NOVA.getPlayerState())
               //    ) {
               //       // console.debug('play video in focus');
               //       video.play();
               //    }
               // });
               window.addEventListener('focus', () => {
                  // if other tabs are not playing
                  if (!localStorage.hasOwnProperty(storeName) // store empty
                     // && video.paused  // dont see ENDED
                     && ['UNSTARTED', 'PAUSED'].includes(NOVA.getPlayerState())
                  ) {
                     // console.debug('play video in focus');
                     video.play();
                  }
               });
            }
            // if tab unfocus apply pause
            window.addEventListener('storage', store => {
               if ((document.visibilityState == 'hidden' || currentPageName == 'embed') // tab unfocus
                  && store.key === storeName && store.storageArea === localStorage // checking store target
                  && localStorage.hasOwnProperty(storeName) && localStorage.getItem(storeName) !== instanceID // active tab not current
                  && 'PLAYING' == NOVA.getPlayerState()
               ) {
                  // console.debug('video pause', localStorage[storeName]);
                  video.pause();
               }
            });
            // pause on tab unfocuse
            if (user_settings.pause_background_tab_autopause_unfocus) {
               window.addEventListener('blur', () => {
                  if ('PLAYING' == NOVA.getPlayerState()) {
                     video.pause();
                  }
               });
               // window.addEventListener('blur', async () => {
               //    await NOVA.sleep(100); // dirty fix. document.visibilityState update AFTER blur

               //    if (document.visibilityState == 'hidden'
               //       && 'PLAYING' == NOVA.getPlayerState()
               //    ) {
               //       // console.debug('document.visibilityState', document.visibilityState);
               //       video.pause();
               //    }
               // });
            }

         });

      // PiP auto enable
      // alt https://chrome.google.com/webstore/detail/always-video-%E1%B4%B4%E1%B4%B7-beta-pip/gcfcmfbcpibcjmcinnimklngkpkkcing?hl=en
      // NOVA.waitElement('video')
      //    .then(video => {
      //       // Detect Picture-in-Picture Support
      //       if (!document.pictureInPictureEnabled/* || video.disablePictureInPicture*/) {
      //          return alert('Picture-in-Picture not supported!');
      //       }
      //       let PiP_lock;
      //       // enable PiP
      //       document.addEventListener('visibilitychange', () => {
      //          // tab on focus - exit PiP
      //          if (document.visibilityState == 'visible'
      //             && document.pictureInPictureElement
      //             && PiP_lock
      //          ) {
      //             console.debug('exitPictureInPicture');
      //             // video.disablePictureInPicture = true;
      //             // setTimeout(() => video.disablePictureInPicture = false, 1000 * 2);
      //             // clearTimeout(timeoutPiP);
      //             return document.exitPictureInPicture();
      //          }
      //          // tab unfocus - enable PiP
      //          if (document.visibilityState == 'hidden'
      //             && !document.pictureInPictureElement // PiP not activated
      //             // && localStorage.hasOwnProperty(storeName) && localStorage.getItem(storeName) !== instanceID // active tab not current
      //             && ['PLAYING'].includes(NOVA.getPlayerState())
      //             // && !video.disablePictureInPicture
      //             && !PiP_lock
      //          ) {
      //             console.debug('requestPictureInPicture');
      //             // video.disablePictureInPicture = false;
      //             video.requestPictureInPicture();

      //             // timeoutPiP = setTimeout(() => video.requestPictureInPicture(), 1000 * 2);
      //          }
      //       });
      //       // exit PiP
      //       ['suspend', 'ended'].forEach(evt =>
      //          video.addEventListener(evt, () => document.pictureInPictureElement && document.exitPictureInPicture()));
      //       video.addEventListener('leavepictureinpicture', () => {
      //          console.debug('leavepictureinpicture');
      //          PiP_lock = false;
      //       });
      //       video.addEventListener('enterpictureinpicture', () => {
      //          console.debug('enterpictureinpicture');
      //          PiP_lock = true;
      //       });
      //    });

      // https://stackoverflow.com/questions/6877403/how-to-tell-if-a-video-element-is-currently-playing
      // Object.defineProperty(HTMLMediaElement.prototype, 'playing', {
      //    get: function () {
      //       return !!(this.currentTime > 0 && !this.paused && !this.ended && this.readyState > 2);
      //    }
      // })
      // if (NOVA.videoElement?.playing) { // checks if element is playing right now
      //    // Do anything you want to
      // }


      // replaced with generic HTML5 method
      // const onPlayerStateChange = state => ('PLAYING' == NOVA.getPlayerState(state)) ? localStorage.setItem(storeName, instanceID) : removeStorage();

      // NOVA.waitElement('#movie_player')
      //    .then(movie_player => {
      //       movie_player.addEventListener('onStateChange', onPlayerStateChange);

      //       // remove storage if this tab closed
      //       window.addEventListener('beforeunload', removeStorage);

      //       window.addEventListener('storage', store => {
      //          if (
      //             // checking the right item
      //             store.key === storeName && store.storageArea === localStorage
      //             // has storage
      //             && localStorage[storeName] && localStorage[storeName] !== instanceID
      //             // this player is playing
      //             && 'PLAYING' == NOVA.getPlayerState()
      //          ) {
      //             console.debug('pause player', localStorage[storeName]);
      //             movie_player.pauseVideo();
      //          }
      //       });

      //    });

   },
   options: {
      pause_background_tab_autoplay_onfocus: {
         _tagName: 'input',
         label: 'Autoplay on tab focus',
         'label:zh': '在标签焦点上自动播放',
         'label:ja': 'タブフォーカスでの自動再生',
         'label:ko': '탭 포커스에서 자동 재생',
         'label:id': 'Putar otomatis pada fokus tab',
         'label:es': 'Reproducción automática en el enfoque de la pestaña',
         'label:pt': 'Reprodução automática no foco da guia',
         'label:fr': "Lecture automatique sur le focus de l'onglet",
         'label:it': 'Riproduzione automatica su tab focus',
         'label:tr': 'Sekme odağında otomatik oynatma',
         'label:de': 'Autoplay bei Tab-Fokus',
         'label:pl': 'Autoodtwarzanie po wybraniu karty',
         'label:ua': 'Автовідтворення при виборі вкладки',
         type: 'checkbox',
         // title: '',
      },
      pause_background_tab_autopause_unfocus: {
         _tagName: 'input',
         label: 'Autopause video if tab loses focus',
         'label:zh': '如果选项卡失去焦点，则自动暂停视频',
         'label:ja': 'タブがフォーカスを失った場合にビデオを自動一時停止',
         'label:ko': '탭이 초점을 잃으면 비디오 자동 일시 중지',
         'label:id': 'Jeda otomatis video jika tab kehilangan fokus',
         'label:es': 'Pausa automática del video si la pestaña pierde el foco',
         'label:pt': 'Pausar automaticamente o vídeo se a guia perder o foco',
         'label:fr': "Pause automatique de la vidéo si l'onglet perd le focus",
         'label:it': 'Metti automaticamente in pausa il video se la scheda perde la messa a fuoco',
         'label:tr': 'Sekme odağı kaybederse videoyu otomatik duraklat',
         'label:de': 'Video automatisch pausieren, wenn der Tab den Fokus verliert',
         'label:pl': 'Automatycznie wstrzymaj wideo, jeśli karta straci ostrość',
         'label:ua': 'Автопауза при зміні вкладки',
         type: 'checkbox',
         // title: '',
      },
   }
});
// for test
// https://www.youtube.com/watch?v=ig2b_obsCQ8 - has chapters

window.nova_plugins.push({
   id: 'player-loop',
   title: 'Add repeat (loop) playback button',
   // Repeat the video you're watching.
   'title:zh': '添加循环播放按钮',
   'title:ja': 'ループ再生ボタンを追加する',
   'title:ko': '루프 재생 버튼 추가',
   'title:id': 'Tambahkan tombol pemutaran ulangi (loop)',
   'title:es': 'Agregar un botón de reproducción en bucle',
   'title:pt': 'Adicionar um botão de reprodução em loop',
   'title:fr': 'Ajouter un bouton de lecture en boucle',
   'title:it': 'Aggiungi il pulsante di riproduzione ripetuta (loop).',
   'title:tr': 'Döngü oynatma düğmesi ekle',
   'title:de': 'Füge einen Loop-Play-Button hinzu',
   'title:pl': 'Dodaj przycisk odtwarzania pętli',
   'title:ua': 'Додати кнопку повтор',
   run_on_pages: 'watch',
   section: 'player',
   // desc: 'Loop video playback',
   // 'desc:zh': '循环播放视频',
   // 'desc:ja': 'ビデオ再生をループする',
   // 'desc:ko': '루프 비디오 재생',
   // 'desc:id': '',
   // 'desc:es': 'Reproducción de video en bucle',
   // 'desc:pt': 'Reprodução de vídeo em loop',
   // 'desc:fr': 'Lecture vidéo en boucle',
   // 'desc:it': '',
   // 'desc:tr': 'Döngü video oynatma',
   // 'desc:de': 'Loop-Videowiedergabe',
   // 'desc:pl': 'Odtwarzanie filmów w pętli',
   // 'desc:ua': 'Зациклювання відео',
   _runtime: user_settings => {

      // createPlayerButton
      NOVA.waitElement('.ytp-left-controls .ytp-play-button')
         .then(container => {
            const
               SELECTOR_CLASS = 'nova-right-custom-button', // same class in "player-buttons-custom" plugin
               btn = document.createElement('button');

            // "ye-repeat-button"
            btn.className = `ytp-button ${SELECTOR_CLASS}`;
            btn.style.opacity = .5;
            btn.style.minWidth = getComputedStyle(container).width || '48px'; // fix if has chapters
            btn.title = 'Repeat';
            // btnPopup.setAttribute('aria-label','');
            btn.innerHTML =
               `<svg viewBox="-6 -6 36 36" height="100%" width="100%">
                  <g fill="currentColor">
                     <path d="M7 7h10v3l4-4-4-4v3H5v6h2V7zm10 10H7v-3l-4 4 4 4v-3h12v-6h-2v4zm-4-2V9h-1l-2 1v1h1.5v4H13z"/>
                  </g>
               </svg>`;
            btn.addEventListener('click', () => {
               if (!NOVA.videoElement) return console.error('btn > videoElement empty:', NOVA.videoElement);

               NOVA.videoElement.loop = !NOVA.videoElement.loop;
               // fix ad
               if (movie_player.classList.contains('ad-showing')) NOVA.videoElement.removeAttribute('loop');

               btn.style.opacity = NOVA.videoElement.hasAttribute('loop') ? 1 : .5;
            });

            container.after(btn);
         });

      // NOVA.waitElement('video')
      //    .then(video => {
      //       video.loop = true;
      //       video.addEventListener('loadeddata', ({ target }) => target.loop = true);
      //    });

      // Doesn't work
      // NOVA.waitElement('#movie_player')
      //    .then(movie_player => movie_player.setLoop());

   },
});
// for test
// https://www.youtube.com/embed/yWUMMg3dmFY?wmode=opaque&amp;rel=0&amp;controls=0&amp;modestbranding=1&amp;showinfo=0&amp;enablejsapi=1 - embed when disable chrome-bottom
// https://radio.nv.ua/online-radio-nv - live embed

window.nova_plugins.push({
   id: 'player-float-progress-bar',
   title: 'Float player progress bar',
   'title:zh': '浮动播放器进度条',
   'title:ja': 'フロートプレーヤーのプログレスバー',
   'title:ko': '플로팅 플레이어 진행률 표시줄',
   'title:id': 'Bilah kemajuan pemain mengambang',
   'title:es': 'Barra de progreso flotante del jugador',
   'title:pt': 'Barra de progresso do jogador flutuante',
   'title:fr': 'Barre de progression du joueur flottant',
   'title:it': 'Barra di avanzamento del giocatore mobile',
   'title:tr': 'Kayan oyuncu ilerleme çubuğu',
   'title:de': 'Float-Player-Fortschrittsbalken',
   'title:pl': 'Pływający pasek postępu odtwarzacza',
   'title:ua': 'Плаваючий індикатор прогресу відтворення',
   run_on_pages: 'watch, embed',
   section: 'player',
   // desc: '',
   _runtime: user_settings => {

      // alt - https://chrome.google.com/webstore/detail/tweaks-for-youtube/ogkoifddpkoabehfemkolflcjhklmkge

      if (NOVA.currentPage == 'embed' && window.self.location.href.includes('live_stream')
         // && (window.self.location.href.includes('live_stream') || movie_player.getVideoData().isLive)
      ) return;

      const
         SELECTOR_ID = 'nova-player-float-progress-bar', // Do not forget patch plugin "player-control-autohide"
         SELECTOR = '#' + SELECTOR_ID,
         CHAPTERS_MARK_WIDTH_PX = '2px';

      NOVA.waitElement('video')
         .then(async video => {
            const
               // async fix embed when disable chrome-bottom (example: https://www.youtube.com/embed/yWUMMg3dmFY?controls=0)
               chromeBtn_zIndex = await NOVA.waitUntil(() => (chromeBtn = document.body.querySelector('.ytp-chrome-bottom')) && getComputedStyle(chromeBtn)['z-index']),
               container = renderFloatBar(chromeBtn_zIndex),
               bufferEl = document.getElementById(`${SELECTOR_ID}-buffer`),
               progressEl = document.getElementById(`${SELECTOR_ID}-progress`);

            renderChapters.init(video); // init

            // resetBar on new video loaded
            video.addEventListener('loadeddata', resetBar);
            document.addEventListener('yt-navigate-finish', resetBar);

            // render progress
            // NOVA.waitElement(`${SELECTOR}-progress`)
            //    .then(progressEl => {
            video.addEventListener('timeupdate', function () {
               if (notInteractiveToRender()) return;

               // Strategy 1 HTML5
               if (!isNaN(this.duration)) {
                  progressEl.style.transform = `scaleX(${this.currentTime / this.duration})`;
               }
               // Strategy 2
               // if (!isNaN(movie_player.getDuration())) {
               //    progressEl.style.transform = `scaleX(${movie_player.getCurrentTime() / movie_player.getDuration()})`;
               // }
            });
            // });

            // render buffer
            // NOVA.waitElement(`${SELECTOR}-buffer`)
            //    .then(bufferEl => {
            video.addEventListener('progress', renderBuffer.bind(video));
            video.addEventListener('seeking', renderBuffer.bind(video));

            function renderBuffer() {
               if (notInteractiveToRender()) return;

               // Strategy 1 HTML5
               // for (let i = 0; i < this.buffered.length; i++) {
               //    //    const bufferedSeconds = this.buffered.end(0) - this.buffered.start(0);
               //    //    console.debug(`${bufferedSeconds} seconds of video are ready to play.`);
               //    if (!isNaN(this.duration) && this.currentTime > this.buffered.start(i)) {
               //       bufferEl.style.transform = `scaleX(${this.buffered.end(i) / this.duration})`;
               //    }
               // }

               // Strategy 2
               if ((totalDuration = movie_player.getDuration()) && !isNaN(totalDuration)) {
                  bufferEl.style.transform = `scaleX(${
                     (movie_player.getVideoBytesLoaded() / totalDuration) * totalDuration
                     })`;
               }
            }
            // });

            function resetBar() {
               // hide if is stream.
               container.style.display = movie_player.getVideoData().isLive ? 'none' : 'initial'; // style.visibility - overridden

               // reset animation state
               container.classList.remove('transition');
               bufferEl.style.transform = 'scaleX(0)';
               progressEl.style.transform = 'scaleX(0)';
               container.classList.add('transition');

               renderChapters.init(video);
            }

            function notInteractiveToRender() {
               return (document.visibilityState == 'hidden' // tab inactive
                  || movie_player.getVideoData().isLive
                  // || !movie_player.classList.contains('ytp-autohide') // dubious optimization hack
               );
            }

         });

      function renderFloatBar(z_index = 60) {
         return document.getElementById(SELECTOR_ID) || (function () {
            movie_player?.insertAdjacentHTML('beforeend',
               `<div id="${SELECTOR_ID}" class="transition">
                  <div class="conteiner">
                     <div id="${SELECTOR_ID}-buffer" class="ytp-load-progress"></div>
                     <div id="${SELECTOR_ID}-progress" class="ytp-swatch-background-color"></div>
                  </div>
                  <div id="${SELECTOR_ID}-chapters"></div>
               </div>`);

            // const bufferColor = getComputedStyle(document.body.querySelector('.ytp-load-progress'))['background-color'] || 'rgba(255,255,255,.4)';

            NOVA.css.push(
               `[id|=${SELECTOR_ID}] {
                  position: absolute;
                  bottom: 0;
               }

               ${SELECTOR} {
                  --opacity: ${+user_settings.player_float_progress_bar_opacity || .7};
                  --height: ${+user_settings.player_float_progress_bar_height || 3}px;
                  --bg-color: ${getComputedStyle(document.body.querySelector('.ytp-progress-list'))['background-color'] || 'rgba(255,255,255,.2)'};
                  --zindex: ${z_index};

                  opacity: var(--opacity)
                  z-index: var(--zindex);
                  background-color: var(--bg-color);
                  width: 100%;
                  visibility: hidden;
               }

               /*.ytp-chrome-bottom[hidden],*/
               .ytp-autohide ${SELECTOR} {
                  visibility: visible;
               }

               /*${SELECTOR} .conteiner {
                  position: relative;
                  margin: 0 15px;
               }*/

               ${SELECTOR}.transition [id|=${SELECTOR_ID}] {
                  transition: transform .2s linear;
               }

               ${SELECTOR}-progress, ${SELECTOR}-buffer {
                  width: 100%;
                  height: var(--height);
                  transform-origin: 0 0;
                  transform: scaleX(0);
               }

               ${SELECTOR}-progress {
                  z-index: calc(var(--zindex) + 1);
               }

               /*${SELECTOR}-buffer {
                  background: var(--buffer-color);
               }*/

               ${SELECTOR}-chapters {
                  position: relative;
                  width: 100%;
                  display: flex;
                  justify-content: flex-end;
               }

               ${SELECTOR}-chapters span {
                  height: var(--height);
                  z-index:  calc(var(--zindex) + 1);
                  border-left: ${CHAPTERS_MARK_WIDTH_PX} solid rgba(255,255,255,.7);
                  /* border-left: ${CHAPTERS_MARK_WIDTH_PX} solid #000; */
                  margin-left: -${CHAPTERS_MARK_WIDTH_PX};
               }`);

            return document.getElementById(SELECTOR_ID);
         })();
      }

      const renderChapters = {
         async init(vid) {
            if (NOVA.currentPage == 'watch' && !(vid instanceof HTMLElement)) return console.error('vid not HTMLElement:', chaptersContainer);

            switch (NOVA.currentPage) {
               case 'watch':
                  await NOVA.waitUntil(() => !isNaN(vid.duration), 1000) // panel hides for a few seconds. No need to hurry
                  this.from_description(vid.duration);
                  break;

               // embed dont have description
               case 'embed':
                  await NOVA.waitUntil(() => (chaptersContainer = document.body.querySelector('.ytp-chapters-container')) && chaptersContainer?.children.length, 1000) // panel hides for a few seconds. No need to hurry
                  this.from_div(chaptersContainer);
                  break;
            }
         },

         from_description(duration = required()) {
            if (Math.sign(duration) !== 1) return console.error('duration not positive number:', duration);
            // <a href="/playlist?list=XX"> - erroneous filtering "t=XX" without the character "&"
            const selectorTimestampLink = 'a[href*="&t="]';
            // search in description
            NOVA.waitElement(`#description.ytd-watch-metadata ${selectorTimestampLink}`)
               .then(() => renderChaptersMarks(duration));

            // search in first/pinned comment
            NOVA.waitElement(`#comments ytd-comment-thread-renderer:first-child #content ${selectorTimestampLink}`)
               .then(() => renderChaptersMarks(duration));

            function renderChaptersMarks(duration) {
               // console.debug('renderChaptersMarks', ...arguments);
               if (chaptersConteiner = document.getElementById(`${SELECTOR_ID}-chapters`)) {
                  chaptersConteiner.innerHTML = ''; // clear old
                  // if (!isNaN(duration)) {
                  NOVA.getChapterList(duration)
                     ?.forEach((chapter, i, chapters_list) => {
                        // console.debug('chapter', (newChapter.sec / duration) * 100 + '%');
                        const newChapter = document.createElement('span');
                        const nextChapterSec = chapters_list[i + 1]?.sec || duration;

                        newChapter.style.width = ((nextChapterSec - chapter.sec) / duration) * 100 + '%';
                        if (chapter.title) newChapter.title = chapter.title;
                        newChapter.setAttribute('time', chapter.time);

                        chaptersConteiner.append(newChapter);
                     });
                  // }
               }
            }
         },

         from_div(chaptersContainer = required()) {
            if (!(chaptersContainer instanceof HTMLElement)) return console.error('container not HTMLElement:', chaptersContainer);
            const
               progressContainerWidth = parseInt(getComputedStyle(chaptersContainer).width),
               chaptersConteiner = document.getElementById(`${SELECTOR_ID}-chapters`);

            for (const chapter of chaptersContainer.children) {
               const
                  newChapter = document.createElement('span'),
                  { width, marginLeft, marginRight } = getComputedStyle(chapter), // chapterWidth = width
                  chapterMargin = parseInt(marginLeft) + parseInt(marginRight);

               newChapter.style.width = (((width + chapterMargin) / progressContainerWidth) * 100) + '%';

               chaptersConteiner.append(newChapter);
            }
         },
      };

   },
   options: {
      player_float_progress_bar_height: {
         _tagName: 'input',
         label: 'Height',
         'label:zh': '高度',
         'label:ja': '身長',
         'label:ko': '키',
         'label:id': 'Tinggi',
         'label:es': 'Altura',
         'label:pt': 'Altura',
         'label:fr': 'Hauteur',
         'label:it': 'Altezza',
         'label:tr': 'Yükseklik',
         'label:de': 'Höhe',
         'label:pl': 'Wysokość',
         'label:ua': 'Висота',
         type: 'number',
         title: 'in pixels',
         placeholder: 'px',
         min: 1,
         max: 9,
         value: 3,
      },
      player_float_progress_bar_opacity: {
         _tagName: 'input',
         label: 'Opacity',
         'label:zh': '不透明度',
         'label:ja': '不透明度',
         'label:ko': '불투명',
         'label:id': 'Kegelapan',
         'label:es': 'Opacidad',
         'label:pt': 'Opacidade',
         'label:fr': 'Opacité',
         'label:it': 'Opacità',
         'label:tr': 'Opaklık',
         'label:de': 'Opazität',
         'label:pl': 'Przejrzystość',
         'label:ua': 'Прозорість',
         type: 'number',
         // title: '',
         placeholder: '0-1',
         step: .05,
         min: 0,
         max: 1,
         value: .7,
      },
   }
});
// for test
// the adjustment area depends on the video size. Problems are visible at non-standard proportions
// https://www.youtube.com/watch?v=embed%2FJVi_e - err - TypeError: Cannot read property 'playerMicroformatRenderer' of undefined

// fot "isMusic" fn test
// https://www.youtube.com/watch?v=kCHiSHxTXgg - svg icon "🎵"
// https://www.youtube.com/results?search_query=Highly+Suspect+-+Upperdrugs+-+2019 // test transition. Open firt thumb "Highly Suspect 🎵"
// https://www.youtube.com/embed/fEcGObUqzk4 - embed (music not recognized)

window.nova_plugins.push({
   id: 'rate-wheel',
   title: 'Playback speed control',
   'title:zh': '播放速度控制',
   'title:ja': '再生速度制御',
   'title:ko': '재생 속도 제어',
   'title:id': 'Kontrol kecepatan pemutaran',
   'title:es': 'Controle de velocidade de reprodução',
   'title:pt': 'Controle de velocidade de reprodução',
   'title:fr': 'Contrôle de la vitesse de lecture',
   'title:it': 'Controllo della velocità di riproduzione',
   'title:tr': 'Oynatma hızı kontrolü',
   'title:de': 'Steuerung der Wiedergabegeschwindigkeit',
   'title:pl': 'Kontrola prędkości odtwarzania',
   'title:ua': 'Контроль швидкості відтворення',
   run_on_pages: 'watch, embed',
   section: 'player',
   // desc: 'Use mouse wheel to change playback speed',
   desc: 'with mouse wheel',
   'desc:zh': '带鼠标滚轮',
   'desc:ja': 'マウスホイール付き',
   'desc:ko': '마우스 휠로',
   'desc:id': 'dengan roda mouse',
   'desc:es': 'con rueda de ratón',
   'desc:pt': 'com roda do mouse',
   'desc:fr': 'avec molette de la souris',
   'desc:it': 'con rotellina del mouse',
   'desc:tr': 'fare tekerleği ile',
   'desc:de': 'mit mausrad',
   'desc:pl': 'za pomocą kółka myszy',
   'desc:ua': 'За допомогою колеса мишки',
   _runtime: user_settings => {

      // NOVA.waitElement('#movie_player')
      //    .then(movie_player => {
      //       // trigger default indicator
      //       // Strategy 1. Default indicator doesn't work for html5 way (Strategy 2)
      //       movie_player.addEventListener('onPlaybackRateChange', rate => {
      //          console.debug('onPlaybackRateChange', rate);
      //       });
      //    });

      NOVA.waitElement('video')
         .then(video => {
            const sliderConteiner = renderSlider.apply(video);
            // console.debug('sliderConteiner', sliderConteiner);

            // trigger default indicator
            // Strategy 2
            video.addEventListener('ratechange', function () {
               // console.debug('ratechange', movie_player.getPlaybackRate(), this.playbackRate);
               NOVA.bezelTrigger(this.playbackRate + 'x');

               // slider update
               if (Object.keys(sliderConteiner).length) {
                  sliderConteiner.slider.value = this.playbackRate;
                  sliderConteiner.sliderLabel.textContent = `Speed (${this.playbackRate})`;
                  sliderConteiner.sliderCheckbox.checked = this.playbackRate === 1 ? false : true;
               }
            });

            setDefaultRate(); // init

            video.addEventListener('loadeddata', setDefaultRate); // update

            if (Object.keys(sliderConteiner).length) {
               sliderConteiner.slider.addEventListener('input', ({ target }) => playerRate.set(target.value));
               sliderConteiner.slider.addEventListener('change', ({ target }) => playerRate.set(target.value));
               sliderConteiner.slider.addEventListener('wheel', evt => {
                  evt.preventDefault();
                  const rate = playerRate.adjust(+user_settings.rate_step * Math.sign(evt.wheelDelta));
                  // console.debug('current rate:', rate);
               });
               sliderConteiner.sliderCheckbox.addEventListener('change', ({ target }) => target.checked || playerRate.set(1));
            }
         });

      // mousewheel in player area
      if (user_settings.rate_hotkey) {
         NOVA.waitElement('.html5-video-container')
            .then(container => {
               container.addEventListener('wheel', evt => {
                  evt.preventDefault();

                  if (evt[user_settings.rate_hotkey]
                     || (user_settings.rate_hotkey == 'none' && !evt.ctrlKey && !evt.altKey && !evt.shiftKey)) {
                     // console.debug('hotkey caught');
                     const rate = playerRate.adjust(+user_settings.rate_step * Math.sign(evt.wheelDelta));
                     // console.debug('current rate:', rate);
                  }
               });
            });
      }

      // during initialization, the icon can be loaded after the video
      if (+user_settings.rate_default !== 1 && user_settings.rate_default_apply_music) {
         // 'Official Artist' badge
         NOVA.waitElement('#upload-info #channel-name .badge-style-type-verified-artist')
            .then(icon => playerRate.set(1));

         NOVA.waitElement('#upload-info #channel-name a[href]')
            .then(channelName => {
               // channelNameVEVO
               if (/(VEVO|Topic|Records|AMV)$/.test(channelName.textContent)
                  || channelName.textContent.toUpperCase().includes('MUSIC')
               ) {
                  playerRate.set(1);
               }
               // channelNameRecords:
               // https://www.youtube.com/channel/UCQnWm_Nnn35u3QGVkcAf87Q
               // https://www.youtube.com/channel/UCpDJl2EmP7Oh90Vylx0dZtA
               // https://www.youtube.com/channel/UCC7ElkFVK3m03gEMfaq6Ung
               // channelNameAMV - https://www.youtube.com/channel/UCtrt9u1luNTxXFDuYIoK2FA
               // special case channelNameLyrics - https://www.youtube.com/channel/UCK9HbSctHJ8n-aZmJsGD7_w
            });
      }


      const playerRate = {
         // DEBUG: true,

         // default method requires a multiplicity of 0.25
         testDefault: rate => (+rate % .25) === 0
            && +rate <= 2
            && +user_settings.rate_default <= 2
            && (typeof movie_player !== 'undefined' && movie_player.hasOwnProperty('getPlaybackRate')),

         async set(level = 1) {
            this.log('set', ...arguments);
            if (this.testDefault(level)) {
               this.log('set:default');
               movie_player.setPlaybackRate(+level) && this.saveInSession(level);

            } else {
               this.log('set:html5');
               NOVA.videoElement = await NOVA.waitElement('video');
               if (NOVA.videoElement) { // fix - Uncaught SyntaxError: Invalid left-hand side in assignment
                  NOVA.videoElement.playbackRate = +level;
                  this.clearInSession();
               }
            }
         },

         adjust(rate_step = required()) {
            this.log('adjust', ...arguments);
            return this.testDefault(rate_step) ? this.default(+rate_step) : this.html5(+rate_step);
         },
         // Strategy 1
         default(playback_rate = required()) {
            this.log('default', ...arguments);
            const playbackRate = movie_player.getPlaybackRate();
            // const inRange = delta => {
            //    const rangeRate = movie_player.getAvailablePlaybackRates();
            //    const playbackRateIdx = rangeRate.indexOf(playbackRate);
            //    return rangeRate[playbackRateIdx + delta];
            // };
            // const newRate = inRange(Math.sign(+playback_rate));
            const inRange = step => {
               const setRateStep = playbackRate + step;
               return (.1 <= setRateStep && setRateStep <= 2) && +setRateStep.toFixed(2);
            };
            const newRate = inRange(+playback_rate);
            // set new rate
            if (newRate && newRate != playbackRate) {
               movie_player.setPlaybackRate(newRate);

               if (newRate === movie_player.getPlaybackRate()) {
                  this.saveInSession(newRate);

               } else {
                  console.error('playerRate:default different: %s!=%s', newRate, movie_player.getPlaybackRate());
               }
            }
            this.log('default return', newRate);
            return newRate === movie_player.getPlaybackRate() && newRate;
         },
         // Strategy 2
         html5(playback_rate = required()) {
            this.log('html5', ...arguments);
            if (!NOVA.videoElement) return console.error('playerRate > videoElement empty:', NOVA.videoElement);

            const playbackRate = NOVA.videoElement.playbackRate;
            const inRange = step => {
               const setRateStep = playbackRate + step;
               return (.1 <= setRateStep && setRateStep <= 3) && +setRateStep.toFixed(2);
            };
            const newRate = inRange(+playback_rate);
            // set new rate
            if (newRate && newRate != playbackRate) {
               // NOVA.videoElement?.defaultPlaybackRate = newRate;
               NOVA.videoElement.playbackRate = newRate;

               if (newRate === NOVA.videoElement.playbackRate) {
                  this.clearInSession();

               } else {
                  console.error('playerRate:html5 different: %s!=%s', newRate, NOVA.videoElement.playbackRate);
               }
            }
            this.log('html5 return', newRate);
            return newRate === NOVA.videoElement.playbackRate && newRate;
         },

         saveInSession(level = required()) {
            try {
               sessionStorage['yt-player-playback-rate'] = JSON.stringify({
                  creation: Date.now(), data: level.toString(),
               })
               this.log('playbackRate save in session:', ...arguments);

            } catch (err) {
               console.warn(`${err.name}: save "rate" in sessionStorage failed. It seems that "Block third-party cookies" is enabled`, err.message);
            }
         },

         clearInSession() {
            const keyName = 'yt-player-playback-rate';
            try {
               sessionStorage.hasOwnProperty(keyName) && sessionStorage.removeItem(keyName);
               this.log('playbackRate save in session:', ...arguments);

            } catch (err) {
               console.warn(`${err.name}: save "rate" in sessionStorage failed. It seems that "Block third-party cookies" is enabled`, err.message);
            }
         },

         log() {
            if (this.DEBUG && arguments.length) {
               console.groupCollapsed(...arguments);
               console.trace();
               console.groupEnd();
            }
         },
      };

      function setDefaultRate() {
         // init rate_default
         // console.debug('setDefaultRate', +user_settings.rate_default, user_settings.rate_default_apply_music, isMusic());
         if (+user_settings.rate_default !== 1) {
            const is_music = isMusic();
            if (NOVA.videoElement?.playbackRate !== +user_settings.rate_default
               && (!user_settings.rate_default_apply_music || !is_music)
            ) {
               // console.debug('update rate_default');
               playerRate.set(user_settings.rate_default);

            } else if (NOVA.videoElement?.playbackRate !== 1 && is_music) { // reset
               // console.debug('reset rate_default');
               playerRate.set(1);
            }
         }

         function isMusic() {
            const
               channelName = document.body.querySelector('#upload-info #channel-name a:not(:empty)')?.textContent,
               titleStr = movie_player.getVideoData().title
                  // add playlist title check
                  + ((playlistTitle = document.body.querySelector('#secondary #playlist #header-description a[href*="/playlist"]:not(:empty)')?.textContent) ? '.' + playlistTitle : ''), // https://www.youtube.com/watch?v=cEdVLDfV1e0&list=PLVrIzE02N3EE9mplAPO8BGleeenadCSNv&index=2
               titleWords = titleStr?.match(/\w+/g);

            if (user_settings.rate_default_apply_music == 'expanded') {
               // 【MAD】,『MAD』,「MAD」
               // warn false finding ex: "AUDIO visualizer" 'underCOVER','VOCALoid','write THEME','UI THEME','photo ALBUM', 'lolyPOP', 'ascENDING', speeED, 'LapOP' 'Ambient AMBILIGHT lighting', 'CD Projekt RED', TEASER
               if (titleStr.split(' - ').length === 2  // search for a hyphen. Ex.:"Artist - Song"
                  || ['【', '『', '「', 'CD', 'AUDIO', 'EXTENDED', 'FULL', 'TOP', 'TRACK', 'TRAP', 'THEME', 'PIANO', 'POP', '8-BIT'].some(i => titleWords?.map(w => w.toUpperCase()).includes(i))
               ) {
                  return true;
               }
            }

            return [
               titleStr,
               location.href, // 'music.youtube.com' or 'youtube.com#music'
               channelName,
               document.body.querySelector('ytd-watch, ytd-watch-flexy')?.playerData?.microformat.playerMicroformatRenderer.category, // exclude embed page
               // ALL BELOW - not updated after page transition!
               // window.ytplayer?.config?.args.title,
               // document.body.querySelector('meta[itemprop="genre"][content]')?.content,
               // window.ytplayer?.config?.args.raw_player_response.microformat?.playerMicroformatRenderer.category,
               // document.body.querySelector('ytd-player')?.player_?.getCurrentVideoConfig()?.args.raw_player_response?.microformat.playerMicroformatRenderer.category
            ]
               .some(i => i?.toUpperCase().includes('MUSIC') || i?.toUpperCase().includes('SOUND'))
               // 'Official Artist' badge
               || document.body.querySelector('#upload-info #channel-name .badge-style-type-verified-artist')
               // channelNameVEVO
               || /(VEVO|Topic|Records|AMV)$/.test(channelName) // https://www.youtube.com/channel/UCHV1I4axw-6pCeQTUu7YFhA
               // specific channel
               || ['MontageRock'].includes(channelName)
               // word
               || titleWords?.length && ['🎵', '♫', 'SONG', 'SOUND', 'SOUNDTRACK', 'LYRIC', 'LYRICS', 'AMBIENT', 'MIX', 'REMIX', 'VEVO', 'CLIP', 'KARAOKE', 'OPENING', 'COVER', 'VOCAL', 'INSTRUMENTAL', 'DNB', 'BASS', 'BEAT', 'ALBUM', 'PLAYLIST', 'DUBSTEP', 'CHILL', 'RELAX', 'CINEMATIC']
                  .some(i => titleWords.map(w => w.toUpperCase()).includes(i))
               // words
               || ['OFFICIAL VIDEO', 'OFFICIAL AUDIO', 'FEAT.', 'FT.', 'LIVE RADIO', 'DANCE VER', 'HIP HOP', 'HOUR VER', 'HOURS VER'] // 'FULL ALBUM'
                  .some(i => titleStr.toUpperCase().includes(i))
               // word (case sensitive)
               || titleWords?.length && ['OP', 'ED', 'MV', 'PV', 'OST', 'NCS', 'BGM', 'EDM', 'GMV', 'AMV', 'MMD', 'MAD']
                  .some(i => titleWords.includes(i));
         }
      }

      function renderSlider() {
         const
            SELECTOR_ID = 'nova-rate-slider-menu',
            SELECTOR = '#' + SELECTOR_ID; // for css

         NOVA.css.push(
            `${SELECTOR} [type="range"] {
               vertical-align: text-bottom;
               margin: '0 5px',
            }

            ${SELECTOR} [type="checkbox"] {
               appearance: none;
               outline: none;
               cursor: pointer;
            }

            ${SELECTOR} [type="checkbox"]:checked {
               background: #f00;
            }

            ${SELECTOR} [type="checkbox"]:checked:after {
               left: 20px;
               background-color: #fff;
            }`);

         // slider
         const slider = document.createElement('input');
         slider.className = 'ytp-menuitem-slider';
         slider.type = 'range';
         slider.min = +user_settings.rate_step;
         slider.max = Math.max(2, +user_settings.rate_default);
         slider.step = +user_settings.rate_step;
         slider.value = this.playbackRate;
         // slider.addEventListener('change', () => playerRate.set(slider.value));
         // slider.addEventListener('wheel', () => playerRate.set(slider.value));

         const sliderIcon = document.createElement('div');
         sliderIcon.className = 'ytp-menuitem-icon';

         const sliderLabel = document.createElement('div');
         sliderLabel.className = 'ytp-menuitem-label';
         sliderLabel.textContent = `Speed (${this.playbackRate})`;

         const sliderCheckbox = document.createElement('input');
         sliderCheckbox.className = 'ytp-menuitem-toggle-checkbox';
         sliderCheckbox.type = 'checkbox';
         sliderCheckbox.title = 'Remember speed';
         // sliderCheckbox.addEventListener('change', function () {
         //    this.value
         // });

         const out = {};

         // appends
         const right = document.createElement('div');
         right.className = 'ytp-menuitem-content';
         out.sliderCheckbox = right.appendChild(sliderCheckbox);
         out.slider = right.appendChild(slider);

         const speedMenu = document.createElement('div');
         speedMenu.className = 'ytp-menuitem';
         speedMenu.id = SELECTOR_ID;
         speedMenu.append(sliderIcon);
         out.sliderLabel = speedMenu.appendChild(sliderLabel);
         speedMenu.append(right);

         document.body.querySelector('.ytp-panel-menu')
            ?.append(speedMenu);

         return out;

         // append final html code
         // document.body.querySelector('.ytp-panel-menu')
         //    ?.insertAdjacentHTML('beforeend',
         //       `<div class="ytp-menuitem" id="rate-slider-menu">
         //          <div class="ytp-menuitem-icon"></div>
         //          <div class="ytp-menuitem-label">Speed (${user_settings.rate_default})</div>
         //          <div class="ytp-menuitem-content">
         //             <input type="checkbox" checked="${Boolean(user_settings.rate_default)}" title="Remember speed" class="ytp-menuitem-toggle-checkbox">
         //             <input type="range" min="0.5" max="4" step="0.1" class="ytp-menuitem-slider">
         //          </div>
         //       </div>`);
      }

   },
   options: {
      rate_default: {
         _tagName: 'input',
         // label: 'Default rate',
         label: 'Speed at startup',
         'label:zh': '启动速度',
         'label:ja': '起動時の速度',
         'label:ko': '시작 시 속도',
         'label:id': '',
         'label:es': 'Velocidad al inicio',
         'label:pt': 'Velocidade na inicialização',
         'label:fr': 'Rapidité au démarrage',
         'label:it': '',
         'label:tr': 'Başlangıçta hız',
         'label:de': 'Geschwindigkeit beim Start',
         'label:pl': 'Prędkość przy uruchamianiu',
         'label:ua': 'Звичайна швидкість',
         type: 'number',
         title: '1 - default',
         // placeholder: '1-3',
         step: 0.05,
         min: 1,
         // max: 3,
         value: 1,
      },
      rate_default_apply_music: {
         _tagName: 'select',
         label: 'Music genre',
         'label:zh': '音乐流派视频',
         'label:ja': '音楽ジャンルのビデオ',
         'label:ko': '음악 장르',
         'label:id': 'Genre musik',
         'label:es': 'Género musical',
         'label:pt': 'Gênero musical',
         'label:fr': 'Genre de musique',
         'label:it': 'Genere musicale',
         'label:tr': 'Müzik tarzı',
         'label:de': 'Musikrichtung',
         'label:pl': 'Gatunek muzyczny',
         'label:ua': 'Жарн музики',
         title: 'extended detection - may trigger falsely',
         'title:zh': '扩展检测 - 可能会错误触发',
         'title:ja': '拡張検出-誤ってトリガーされる可能性があります',
         'title:ko': '확장 감지 - 잘못 트리거될 수 있음',
         'title:id': 'deteksi diperpanjang - dapat memicu salah',
         // 'title:es': 'detección extendida - puede activarse falsamente',
         'title:pt': 'detecção estendida - pode disparar falsamente',
         'title:fr': 'détection étendue - peut se déclencher par erreur',
         'title:it': 'rilevamento esteso - potrebbe attivarsi in modo errato',
         'title:tr': 'genişletilmiş algılama - yanlış tetiklenebilir',
         'title:de': 'erweiterte Erkennung - kann fälschlicherweise auslösen',
         'title:pl': 'rozszerzona detekcja - może działać błędnie',
         'title:ua': 'Розширене виявлення - може спрацювати помилково',
         options: [
            { label: 'skip', value: true, selected: true, 'label:zh': '跳过', 'label:ja': 'スキップ', 'label:ko': '건너 뛰기', /*'label:id': '',*/ 'label:es': 'saltar', 'label:pt': 'pular', 'label:fr': 'sauter', /*'label:it': '',*/ 'label:tr': 'atlamak', 'label:de': 'überspringen'/*, 'label:pl': ''*/, 'label:ua': 'Пропустити' },
            { label: 'skip (extended)', value: 'expanded', 'label:zh': '跳过（扩展检测）', 'label:ja': 'スキップ（拡張検出）', 'label:ko': '건너뛰다(확장)', /*'label:id': '',*/ 'label:es': 'omitir (extendida)', 'label:pt': 'pular (estendido)', 'label:fr': 'sauter (étendu)', /*'label:it': '',*/ 'label:tr': 'atlamak (genişletilmiş)', 'label:de': 'überspringen (erweitert)'/*, 'label:pl': ''*/, 'label:ua': 'Пропустити (розширено)' },
            { label: 'force apply', value: false, 'label:zh': '施力', 'label:ja': '力を加える', 'label:ko': '강제 적용', /*'label:id': '',*/ 'label:es': 'aplicar fuerza', 'label:pt': 'aplicar força', 'label:fr': 'appliquer la force', /*'label:it': '',*/ 'label:tr': 'zorlamak', 'label:de': 'kraft anwenden'/*, 'label:pl': ''*/, 'label:ua': 'Примусово активувати' },
         ],
         'data-dependent': { 'rate_default': '!1' },
      },
      rate_step: {
         _tagName: 'input',
         label: 'Step',
         'label:zh': '步',
         'label:ja': 'ステップ',
         'label:ko': '단계',
         'label:id': 'Melangkah',
         'label:es': 'Paso',
         'label:pt': 'Degrau',
         'label:fr': 'Étape',
         'label:it': 'Fare un passo',
         'label:tr': 'Adım',
         'label:de': 'Schritt',
         'label:pl': 'Krok',
         'label:ua': 'Крок',
         type: 'number',
         title: '0.25 - default',
         placeholder: '0.1-1',
         step: 0.05,
         min: 0.1,
         max: 0.5,
         value: 0.25,
      },
      rate_hotkey: {
         _tagName: 'select',
         label: 'Hotkey',
         'label:zh': '热键',
         'label:ja': 'ホットキー',
         'label:ko': '단축키',
         'label:id': 'Tombol pintas',
         'label:es': 'Tecla de acceso rápido',
         'label:pt': 'Tecla de atalho',
         'label:fr': 'Raccourci',
         'label:it': 'Tasto di scelta rapida',
         'label:tr': 'Kısayol tuşu',
         'label:de': 'Schnelltaste',
         'label:pl': 'Klawisz skrótu',
         'label:ua': 'Гаряча клавіша',
         options: [
            { label: 'alt+wheel', value: 'altKey', selected: true },
            { label: 'shift+wheel', value: 'shiftKey' },
            { label: 'ctrl+wheel', value: 'ctrlKey' },
            { label: 'wheel', value: 'none' },
            { label: 'disable', value: false },
         ],
      },
   }
});
// for test
// the adjustment area depends on the video size. Problems are visible at non-standard aspect ratio

window.nova_plugins.push({
   id: 'volume-wheel',
   title: 'Volume',
   'title:zh': '体积',
   'title:ja': '音量',
   'title:ko': '용량',
   // 'title:id': 'Volume',
   'title:es': 'Volumen',
   // 'title:pt': 'Volume',
   'title:fr': 'Le volume',
   // 'title:it': 'Volume',
   'title:tr': 'Hacim',
   'title:de': 'Volumen',
   'title:pl': 'Głośność',
   'title:ua': 'Гучність',
   run_on_pages: 'watch, embed, -mobile',
   section: 'player',
   // desc: 'Use mouse wheel to change volume of video',
   desc: 'with mouse wheel',
   'desc:zh': '带鼠标滚轮',
   'desc:ja': 'マウスホイール付き',
   'desc:ko': '마우스 휠로',
   'desc:id': 'dengan roda mouse',
   'desc:es': 'con rueda de ratón',
   'desc:pt': 'com roda do mouse',
   'desc:fr': 'avec molette de la souris',
   'desc:it': 'con rotellina del mouse',
   'desc:tr': 'fare tekerleği ile',
   'desc:de': 'mit mausrad',
   'desc:pl': 'za pomocą kółka myszy',
   'desc:ua': 'З допомогою колеса мишки',
   _runtime: user_settings => {

      NOVA.waitElement('video')
         .then(video => {
            // trigger default indicator
            video.addEventListener('volumechange', function () {
               // bug? demonstration of different values
               // console.debug('volumechange', movie_player.getVolume(), this.volume);
               NOVA.bezelTrigger(movie_player.getVolume() + '%');
               playerVolume.buildVolumeSlider();

               if (user_settings.volume_mute_unsave) {
                  playerVolume.saveInSession(movie_player.getVolume());
               }
            });

            if (user_settings.volume_hotkey) {
               // mousewheel in player area
               document.body.querySelector('.html5-video-container')
                  .addEventListener('wheel', evt => {
                     evt.preventDefault();

                     if (evt[user_settings.volume_hotkey] || (user_settings.volume_hotkey == 'none' && !evt.ctrlKey && !evt.altKey && !evt.shiftKey)) {
                        // console.debug('hotkey caught');
                        if (step = +user_settings.volume_step * Math.sign(evt.wheelDelta)) {
                           playerVolume.adjust(step);
                        }
                     }
                  });
            }
            // init volume_level_default
            if (+user_settings.volume_level_default) {
               playerVolume.set(+user_settings.volume_level_default);
               // (user_settings.volume_unlimit || +user_settings.volume_level_default > 100)
               //    ? playerVolume.unlimit(+user_settings.volume_level_default)
               //    : playerVolume.set(+user_settings.volume_level_default);
            }
         });


      const playerVolume = {
         adjust(delta) {
            const level = movie_player?.getVolume() + +delta;
            return user_settings.volume_unlimit ? this.unlimit(level) : this.set(level);
         },
         // Strategy 1
         set(level = 50) {
            if (typeof movie_player === 'undefined' || !movie_player.hasOwnProperty('getVolume')) return console.error('Error getVolume');

            const newLevel = Math.max(0, Math.min(100, +level));

            // set new volume level
            if (newLevel !== movie_player.getVolume()) {
               movie_player.isMuted() && movie_player.unMute();
               movie_player.setVolume(newLevel); // 0 - 100

               if (newLevel === movie_player.getVolume()) {
                  this.saveInSession(newLevel);
                  // this.buildVolumeSlider();

               } else {
                  console.error('setVolumeLevel error! Different: %s!=%s', newLevel, movie_player.getVolume());
               }
            }
            return newLevel === movie_player.getVolume() && newLevel;
         },

         saveInSession(level = required()) {
            const storageData = {
               creation: Date.now(),
               data: { 'volume': +level, 'muted': (level ? 'false' : 'true') },
               // data: { 'volume': +level, 'muted': ((level || user_settings.volume_mute_unsave) ? 'false' : 'true') },
            };

            try {
               localStorage['yt-player-volume'] = JSON.stringify(
                  Object.assign({ expiration: Date.now() + 2592e6 }, storageData)
               );
               sessionStorage['yt-player-volume'] = JSON.stringify(storageData);
               // console.debug('volume saved', ...arguments);

            } catch (err) {
               console.warn(`${err.name}: save "volume" in sessionStorage failed. It seems that "Block third-party cookies" is enabled`, err.message);
            }
         },

         unlimit(level = 300) {
            if (level > 100) {
               if (!this.audioCtx) {
                  this.audioCtx = new AudioContext();
                  const source = this.audioCtx.createMediaElementSource(NOVA.videoElement);
                  this.node = this.audioCtx.createGain();
                  this.node.gain.value = 1;
                  source.connect(this.node);
                  this.node.connect(this.audioCtx.destination);
               }

               if (this.node.gain.value < 7) this.node.gain.value += 1; // 7(700%) max

               NOVA.bezelTrigger(movie_player.getVolume() * this.node.gain.value + '%');
               // this.buildVolumeSlider();

            } else {
               if (this.audioCtx && this.node.gain.value !== 1) {
                  this.node.gain.value = 1; // reset
               }

               this.set(level);
            }
            // console.debug('unlimit', this.node.gain.value);
         },

         buildVolumeSlider(timeout_ms = 800) {
            if (volumeArea = movie_player?.querySelector('.ytp-volume-area')) {
               // reset hide
               if (typeof this.showTimeout === 'number') clearTimeout(this.showTimeout);
               // show
               volumeArea.dispatchEvent(new Event('mouseover', { bubbles: true }));
               // hide
               this.showTimeout = setTimeout(() =>
                  volumeArea.dispatchEvent(new Event('mouseout', { bubbles: true }))
                  , timeout_ms); // 800ms

               insertToHTML({
                  'text': Math.round(movie_player.getVolume()),
                  'container': volumeArea,
               });
            }

            function insertToHTML({ text = '', container = required() }) {
               // console.debug('insertToHTML', ...arguments);
               if (!(container instanceof HTMLElement)) return console.error('container not HTMLElement:', container);
               const SELECTOR_ID = 'nova-volume-text';

               (document.getElementById(SELECTOR_ID) || (function () {
                  const SELECTOR = '#' + SELECTOR_ID; // for css

                  NOVA.css.push(`
                     ${SELECTOR} {
                        display: none;
                        text-indent: 2px;
                        font-size: 110%;
                        text-shadow: 0 0 2px rgba(0, 0, 0, 0.5);
                        cursor: default;
                     }
                     ${SELECTOR}:after { content: '%'; }

                     .ytp-volume-control-hover:not([aria-valuenow="0"])+${SELECTOR} {
                        display: block;
                     }`)

                  // container.insertAdjacentHTML('beforeend', `<span id="${SELECTOR_ID}">${text}</span>`);
                  // return document.getElementById(SELECTOR_ID);
                  const el = document.createElement('span');
                  el.id = SELECTOR_ID;
                  container.insertAdjacentElement('beforeend', el);
                  return el;
               })())
                  .textContent = text;

               container.title = `${text} %`;
            }
         }
      };

   },
   options: {
      volume_level_default: {
         _tagName: 'input',
         // label: 'Level at startup',
         label: 'Default level',
         'label:zh': '默认音量',
         'label:ja': 'デフォルトのボリューム',
         'label:ko': '기본 볼륨',
         'label:id': 'Tingkat default',
         'label:es': 'Volumen predeterminado',
         'label:pt': 'Volume padrão',
         'label:fr': 'Volume par défaut',
         'label:it': 'Livello predefinito',
         'label:tr': 'Varsayılan ses',
         'label:de': 'Standardlautstärke',
         'label:pl': 'Poziom domyślny',
         'label:ua': 'Базовий рівень',
         type: 'number',
         title: '0 - auto',
         placeholder: '%',
         step: 1,
         min: 0,
         max: 100,
         // max: 600,
         value: 100,
      },
      volume_step: {
         _tagName: 'input',
         label: 'Step',
         'label:zh': '步',
         'label:ja': 'ステップ',
         'label:ko': '단계',
         'label:id': 'Melangkah',
         'label:es': 'Paso',
         'label:pt': 'Degrau',
         'label:fr': 'Étape',
         'label:it': 'Fare un passo',
         'label:tr': 'Adım',
         'label:de': 'Schritt',
         'label:pl': 'Krok',
         'label:ua': 'Крок',
         type: 'number',
         title: 'in %',
         placeholder: '%',
         step: 5,
         min: 5,
         max: 30,
         value: 10,
      },
      volume_hotkey: {
         _tagName: 'select',
         label: 'Hotkey',
         'label:zh': '热键',
         'label:ja': 'ホットキー',
         'label:ko': '단축키',
         'label:id': 'Tombol pintas',
         'label:es': 'Tecla de acceso rápido',
         'label:pt': 'Tecla de atalho',
         'label:fr': 'Raccourci',
         'label:it': 'Tasto di scelta rapida',
         'label:tr': 'Kısayol tuşu',
         'label:de': 'Schnelltaste',
         'label:pl': 'Klawisz skrótu',
         'label:ua': 'Гаряча клавіша',
         options: [
            { label: 'wheel', value: 'none', selected: true },
            { label: 'shift+wheel', value: 'shiftKey' },
            { label: 'ctrl+wheel', value: 'ctrlKey' },
            { label: 'alt+wheel', value: 'altKey' },
            { label: 'disable', value: false },
         ],
      },
      volume_unlimit: {
         _tagName: 'input',
         label: 'Allow above 100%',
         'label:zh': '允许超过 100%',
         'label:ja': '100％以上を許可する',
         'label:ko': '100% 이상 허용',
         'label:id': 'Izinkan di atas 100%',
         'label:es': 'Permitir por encima del 100%',
         'label:pt': 'Permitir acima de 100%',
         'label:fr': 'Autoriser au-dessus de 100 %',
         'label:it': 'Consenti oltre il 100%',
         'label:tr': "%100'ün üzerinde izin ver",
         'label:de': 'Über 100 % zulassen',
         'label:pl': 'Zezwól powyżej 100%',
         'label:ua': 'Дозволити більше 100%',
         type: 'checkbox',
         // title: 'allow set volume above 100%',
         // 'title:zh': '允许设定音量高于 100%',
         // 'title:ja': '100％を超える設定ボリュームを許可する',
         // 'title:ko': '100% 이상의 설정 볼륨 허용',
         // 'title:id': 'izinkan volume yang disetel di atas 100%',
         // 'title:es': 'permitir el volumen establecido por encima del 100%',
         // 'title:pt': 'permitir volume definido acima de 100%',
         // 'title:fr': 'autoriser le réglage du volume au-dessus de 100 %',
         // 'title:it': 'consentire volume impostato superiore al 100%',
         // 'title:tr': "%100'ün üzerinde ses ayarına izin ver",
         // 'title:de': 'eingestellte Lautstärke über 100% zulassen',
         // 'title:pl': 'zezwala ustawić powyżej 100%',
         // 'title:ua': 'Дозволити встановити звук більше 100%',
      },
      volume_mute_unsave: {
         _tagName: 'input',
         // Force unmute for videos opened in new tabs while another video is muted
         label: 'Not keep muted state',
         // label: 'disable mute save state',
         // label: 'disable mute memory state',
         'label:zh': '不保存静音模式',
         'label:ja': 'マナーモードを保存しない',
         'label:ko': '무음 모드를 저장하지 않음',
         'label:id': 'Jangan simpan mode senyap',
         'label:es': 'No guarde el modo silencioso',
         'label:pt': 'Não salve o modo silencioso',
         'label:fr': 'Ne pas enregistrer le mode silencieux',
         'label:it': 'Non salvare la modalità silenziosa',
         'label:tr': 'Ne pas enregistrer le mode silencieux',
         'label:de': 'Silent-Modus nicht speichern',
         'label:pl': 'Nie zachowuj wyciszonego stanu',
         'label:ua': 'Не зберігати беззвучний режим',
         type: 'checkbox',
         title: 'only affects new tabs',
         'title:zh': '只影响新标签',
         'title:ja': '新しいタブにのみ影響します',
         'title:ko': '새 탭에만 영향',
         'title:id': 'hanya memengaruhi tab baru',
         'title:es': 'solo afecta a las pestañas nuevas',
         'title:pt': 'afeta apenas novas guias',
         'title:fr': "n'affecte que les nouveaux onglets",
         'title:it': 'riguarda solo le nuove schede',
         'title:tr': 'yalnızca yeni sekmeleri etkiler',
         'title:de': 'wirkt sich nur auf neue Registerkarten aus',
         'title:pl': 'dotyczy tylko nowych kart',
         'title:ua': 'Діє лише на нові вкладки',
      },
   }
});
// https://www.youtube.com/watch?v=9EvbqxBUG_c - great for testing
// https://www.youtube.com/watch?v=Il0S8BoucSA&t=99 - subtitle alignment bug
// https://youtu.be/XvJRE6Sm-lM - has sub

window.nova_plugins.push({
   id: 'subtitle-transparent',
   title: 'Transparent subtitles (captions)',
   'title:zh': '透明字幕',
   'title:ja': '透明な字幕',
   'title:ko': '투명한 자막',
   'title:id': 'Subtitle transparan',
   'title:es': 'Subtítulos transparentes',
   'title:pt': 'Legendas transparentes',
   'title:fr': 'Sous-titres transparents',
   'title:it': 'Sottotitoli trasparenti',
   'title:tr': 'Şeffaf altyazılar',
   'title:de': 'Transparente Untertitel',
   'title:pl': 'Napisy przezroczyste',
   'title:ua': 'Прозорі субтитри',
   run_on_pages: 'watch, embed, -mobile',
   section: 'player',
   // desc: '',
   _runtime: user_settings => {

      // movie_player.getSubtitlesUserSettings();
      // movie_player.updateSubtitlesUserSettings({ background: 'transparent',}); // Uncaught Error: 'transparent' is not a valid hex color

      let css = {
         'background': 'transparent',
         'text-shadow':
            `rgb(0, 0, 0) 0 0 .1em,
            rgb(0, 0, 0) 0 0 .2em,
            rgb(0, 0, 0) 0 0 .4em`,
      };

      if (user_settings.subtitle_bold) css['font-weight'] = 'bold';

      NOVA.css.push(css, `.ytp-caption-segment`, 'important');

      if (user_settings.subtitle_fixed) {
         // alt - https://greasyfork.org/en/scripts/442033-fix-youtube-caption-position
         NOVA.css.push(
            // `.ytp-larger-tap-buttons .caption-window.ytp-caption-window-bottom {
            `.caption-window {
               margin-bottom: 1px !important;
               bottom: 1% !important;
            }`);
      }

      if (user_settings.subtitle_selectable) {
         // alt - https://greasyfork.org/en/scripts/451626-make-youtube-caption-selectable
         // alt2 - https://greasyfork.org/en/scripts/435955-youtube%E5%AD%97%E5%B9%95%E5%8D%95%E8%AF%8D%E5%8F%AF%E4%BB%A5%E7%9B%B4%E6%8E%A5%E9%80%89%E4%B8%AD-%E6%96%B9%E4%BE%BFmac%E7%94%B5%E8%84%91%E5%BF%AB%E9%80%9F%E9%80%89%E4%B8%AD%E7%BF%BB%E8%AF%91%E5%8D%95%E8%AF%8D
         NOVA.watchElements({
            selectors: [
               '.ytp-caption-segment:not([selectable="true"]',
               //    'div.caption-window',
               //    '#caption-window-1:not([selectable="true"]'
            ],
            // attr_mark: ATTR_MARK,
            callback: el => {
               el.addEventListener('mousedown', evt => evt.stopPropagation(), true);
               el.setAttribute('draggable', 'false');
               el.setAttribute('selectable', 'true');
               el.style.userSelect = 'text';
               elem.style.WebkitUserSelect = 'text'; // for Safari
               el.style.cursor = 'text';
            }
         });
      }

   },
   options: {
      subtitle_bold: {
         _tagName: 'input',
         label: 'Bold text',
         'label:zh': '粗体',
         'label:ja': '太字',
         'label:ko': '굵은 텍스트',
         'label:id': 'Teks tebal',
         'label:es': 'Texto en negrita',
         'label:pt': 'Texto em negrito',
         'label:fr': 'Texte en gras',
         'label:it': 'Testo grassetto',
         'label:tr': 'Kalın yazı',
         'label:de': 'Fetter Text',
         'label:pl': 'Tekst pogrubiony',
         'label:ua': 'Жирний текст',
         type: 'checkbox',
      },
      subtitle_fixed: {
         _tagName: 'input',
         label: 'Fixed from below',
         'label:zh': '从下方固定',
         'label:ja': '下から固定',
         'label:ko': '아래에서 고정',
         'label:id': 'Diperbaiki dari bawah',
         'label:es': 'Fijado desde abajo',
         'label:pt': 'Fixo por baixo',
         'label:fr': 'Fixé par le bas',
         'label:it': 'Risolto dal basso',
         'label:tr': 'Risolto dal basso',
         'label:de': 'Von unten befestigt',
         'label:pl': 'Przyklejone na dole',
         'label:ua': 'Фіксація знизу',
         type: 'checkbox',
      },
      subtitle_selectable: {
         _tagName: 'input',
         label: 'Make subtitles selectable',
         'label:zh': '使字幕可选',
         'label:ja': '字幕を選択可能にする',
         'label:ko': '자막을 선택 가능하게 만들기',
         'label:id': 'Jadikan subtitle dapat dipilih',
         'label:es': 'Hacer subtítulos seleccionables',
         'label:pt': 'Faça legendas selecionáveis',
         'label:fr': 'Rendre les sous-titres sélectionnables',
         'label:it': 'Rendi selezionabili i sottotitoli',
         'label:tr': 'Altyazıları seçilebilir yap',
         'label:de': 'Untertitel wählbar machen',
         'label:pl': 'Ustaw napisy do wyboru',
         'label:ua': 'Зробити субтитри доступними для вибору',
         type: 'checkbox',
      },
   }
});
window.nova_plugins.push({
   id: 'player-indicator',
   title: 'Replace HUD (bezel)',
   'title:zh': '替换默认指示器',
   'title:ja': 'デフォルトのインジケーターを置き換える',
   'title:ko': '기본 표시기 교체',
   'title:id': 'Ganti HUD (bezel)',
   'title:es': 'Reemplazar indicador predeterminado',
   'title:pt': 'Substituir o indicador padrão',
   'title:fr': "Remplacer l'indicateur par défaut",
   'title:it': 'Sostituisci HUD (cornice)',
   'title:tr': 'Varsayılan göstergeyi değiştir',
   'title:de': 'Standardkennzeichen ersetzen',
   'title:pl': 'Zamień wskaźnik standardowy',
   'title:ua': 'Замінити стандартний інтерфейс',
   run_on_pages: 'watch, embed',
   section: 'player',
   // desc: '',
   _runtime: user_settings => {

      // alt:
      // https://greasyfork.org/en/scripts/376002-youtube-volume-mouse-controller
      // https://greasyfork.org/en/scripts/376155-youtube-scroll-volume
      const
         SELECTOR_ID = 'nova-player-indicator-info',
         COLOR_HUD = user_settings.player_indicator_color || '#ff0000';

      NOVA.waitElement('video')
         .then(video => {
            // volume
            video.addEventListener('volumechange', function () {
               // console.debug('volumechange', movie_player.getVolume(), this.volume); // there is a difference
               HUD.set({
                  'pt': Math.round(movie_player.getVolume()),
                  'suffix': '%',
                  // 'timeout_ms': 0,
               });
            });
            // rate
            video.addEventListener('ratechange', () => HUD.set({
               'pt': video.playbackRate,
               'suffix': 'x',
               // 'timeout_ms': 0,
            }));
         });

      // Listener default indicator
      NOVA.waitElement('.ytp-bezel-text')
         .then(target => {
            new MutationObserver(mutations => {
               let timeout_ms; // ms
               for (const mutation of mutations) {
                  // console.log('bezel mutation detected', mutation.type, target.textContent);
                  if (target.textContent) {
                     // increase delay for plugin "time-jump"
                     // target.textContent #1:"+30 sec • 10:00" - skip
                     // target.textContent #2:"chapter name • 10:00" - ok
                     if (!target.textContent.startsWith('+') && target.textContent.includes(' • ')) {
                        timeout_ms = 1800; // ms
                        // console.debug(`HUD delay increased: ${timeout_ms}ms`);
                     }
                     HUD.set({
                        'pt': target.textContent,
                        // 'suffix': '',
                        'timeout_ms': timeout_ms,
                     });
                     break;
                  }
               }
            })
               .observe(target, { childList: true }); // watch for textContent
         });

      const HUD = {
         get() {
            return this.conteiner || this.create();
         },
         // TODO The idea of ​​copying the progress bar. To display segments of time markers
         // a = el.cloneNode(true)
         // document.getElementById(SELECTOR_ID).innerHTML = a.innerHTML

         create() {
            // hide default indicator
            NOVA.css.push(
               `.ytp-bezel-text-wrapper,
               .ytp-doubletap-ui-legacy.ytp-time-seeking,
               /*.ytp-doubletap-seek-info-container,*/
               .ytp-chapter-seek {
                  display:none !important;
               }`);
            // init common css
            NOVA.css.push(
               `#${SELECTOR_ID} {
                  --color: #fff;
                  --bg-color: rgba(0,0,0,0.3);
                  --zindex: ${getComputedStyle(document.body.querySelector('.ytp-chrome-top'))['z-index'] || 60};

                  position: absolute;
                  right: 0;
                  z-index: calc(var(--zindex) + 1);
                  margin: 0 auto;
                  text-align: center;
                  opacity: 0;
                  background-color: var(--bg-color);
                  color: var(--color);
               }`);
            // template
            movie_player.insertAdjacentHTML('beforeend', `<div id="${SELECTOR_ID}"><span></span></div>`);

            this.conteiner = document.getElementById(SELECTOR_ID);
            this.hudSpan = this.conteiner.querySelector('span'); // export el

            // add to div user_settings.player_indicator_type style
            // const [indicator_type, span_align] = user_settings.player_indicator_type.split('=', 2); // 2 = max param;
            // switch (indicator_type) {
            switch (user_settings.player_indicator_type) {
               case 'bar-center':
                  Object.assign(this.conteiner.style, {
                     left: 0,
                     bottom: '20%',
                     width: '30%',
                     'font-size': '1.2em',
                  });
                  Object.assign(this.hudSpan.style, {
                     'background-color': COLOR_HUD,
                     transition: 'width 100ms ease-out 0s',
                     display: 'inline-block',
                  });
                  // if (span_align == 'left') {
                  //    Object.assign(this.hudSpan.style, {
                  //       float: 'left',
                  //    });
                  // }
                  break;

               case 'bar-vertical':
                  Object.assign(this.conteiner.style, {
                     top: 0,
                     height: '100%',
                     width: '25px',
                     'font-size': '1.2em',
                  });
                  Object.assign(this.hudSpan.style, {
                     position: 'absolute',
                     bottom: 0,
                     right: 0,
                     'background-color': COLOR_HUD,
                     transition: 'height 100ms ease-out 0s',
                     display: 'inline-block',
                     width: '100%',
                     'font-weight': 'bold',
                  });
                  break;

               // case 'text-top':
               default:
                  Object.assign(this.conteiner.style, {
                     top: 0,
                     width: '100%',
                     padding: '.2em',
                     'font-size': '1.55em',
                  });
            }
            return this.conteiner;
         },

         set({ pt = 100, suffix = '', timeout_ms = 800 }) {
            // console.debug('HUD set', ...arguments);
            if (typeof this.fateNovaHUD === 'number') clearTimeout(this.fateNovaHUD); // reset hide

            let hudConteiner = this.get();
            const text = pt + suffix;

            if (suffix == 'x') { // rate to pt
               const maxPercent = (+user_settings.rate_step % .25) === 0 ? 2 : 3;
               pt = (+pt / maxPercent) * 100;
            }
            pt = Math.round(pt);

            switch (user_settings.player_indicator_type) {
               case 'bar-center':
                  this.hudSpan.style.width = pt + '%';
                  this.hudSpan.textContent = text;
                  break;

               case 'bar-vertical':
                  this.hudSpan.style.height = pt + '%';
                  this.hudSpan.textContent = text;
                  break;

               case 'bar-top':
                  hudConteiner.style.background = `linear-gradient(to right, ${COLOR_HUD}50 ${pt}%, rgba(0,0,0,.8) ${pt}%)`;
                  this.hudSpan.style.width = pt + '%';
                  this.hudSpan.textContent = text;
                  break;

               // case 'text-top':
               default:
                  this.hudSpan.textContent = text;
            }

            hudConteiner.style.transition = 'none';
            hudConteiner.style.opacity = 1;
            // hudConteiner.style.visibility = 'visible';

            this.fateNovaHUD = setTimeout(() => {
               hudConteiner.style.transition = 'opacity 200ms ease-in';
               hudConteiner.style.opacity = null;
               // hudConteiner.style.visibility = 'hidden';
            }, timeout_ms); //total 1s = 800ms + 200ms(hudConteiner.style.transition)
         }
      };

   },
   options: {
      player_indicator_type: {
         _tagName: 'select',
         label: 'Indicator type',
         'label:zh': '指标类型',
         'label:ja': 'インジケータータイプ',
         'label:ko': '표시기 유형',
         'label:id': 'Gösterge tipi',
         'label:es': 'Tipo de indicador',
         'label:pt': 'Tipo de indicador',
         'label:fr': "Type d'indicateur",
         'label:it': 'Tipo di indicatore',
         'label:tr': 'Varsayılan göstergeyi değiştir',
         'label:de': 'Indikatortyp',
         'label:pl': 'Typ wskaźnika',
         'label:ua': 'Тип індикатора',
         options: [
            { label: 'text-top', value: 'text-top', selected: true },
            { label: 'bar-top', value: 'bar-top' },
            { label: 'bar-center', value: 'bar-center' },
            { label: 'bar-vertical', value: 'bar-vertical' },
         ],
      },
      player_indicator_color: {
         _tagName: 'input',
         type: 'color',
         value: '#ff0000', // red
         label: 'Color',
         'label:zh': '颜色',
         'label:ja': '色',
         'label:ko': '색깔',
         'label:id': 'Warna',
         // 'label:es': 'Color',
         'label:pt': 'Cor',
         'label:fr': 'Couleur',
         'label:it': 'Colore',
         'label:tr': 'Renk',
         'label:de': 'Farbe',
         'label:pl': 'Kolor',
         'label:ua': 'Колір',
         'data-dependent': { 'player_indicator_type': '!text-top' },
      },
   }
});
window.nova_plugins.push({
   id: 'disable-player-sleep-mode',
   title: 'Disable the [Continue watching?] popup',
   // title: 'Player stay active forever',
   // title: 'Disable player sleep mode',
   'title:zh': '玩家永远保持活跃',
   'title:ja': 'プレーヤーは永遠にアクティブなままです',
   'title:ko': '플레이어는 영원히 활성 상태를 유지',
   'title:id': 'Pemain tetap aktif selamanya',
   'title:es': 'El jugador permanece activo para siempre',
   'title:pt': 'Jogador permanece ativo para sempre',
   'title:fr': 'Le joueur reste actif pour toujours',
   'title:it': 'Il giocatore resta attivo per sempre',
   'title:tr': 'Sayfa uykusunu devre dışı bırak',
   'title:de': 'Spieler bleiben für immer aktiv',
   'title:pl': 'Wyłącz tryb uśpienia odtwarzacza',
   'title:ua': 'Вимкнути режим сну відтворювача',
   run_on_pages: 'watch, -mobile',
   section: 'player',
   // desc: 'prevent asking you to click "yes" to continue playing?',
   // desc: 'disable [Video paused] alert',
   // 'desc:zh': '防止[视频暂停]警报',
   // 'desc:ja': '「Video paused」アラートを防止します',
   // 'desc:ko': '[Video paused] 알림을 방지합니다',
   // 'desc:id': 'mencegah peringatan [Video dijeda]',
   // 'desc:es': 'evitar la alerta de [Video en pausa]',
   // 'desc:pt': 'evitar o alerta de [Vídeo pausado]',
   // 'desc:fr': "empêcher l'alerte [Vidéo en pause]",
   // 'desc:it': "impedire l'avviso [Video in pausa].",
   // 'desc:tr': '[Video duraklatıldı] uyarısını engelle',
   // 'desc:de': 'Warnung [Video pausiert] verhindern',
   // 'desc:pl': 'zapobiega wyświetlaniu alertu [Film wstrzymany]',
   // 'desc:ua': 'Вимикає спливаюче вікно "продовжити перегляд?"',
   _runtime: user_settings => {

      // Keyboard code - https://docs.microsoft.com/en-us/dotnet/api/android.views.keycode?view=xamarin-android-sdk-12
      // Strategy 1
      window.setInterval(() => {
         // window.wrappedJSObject._lact = Date.now(); - does work (source: https://greasyfork.org/en/scripts/447802-youtube-web-tweaks)
         document.dispatchEvent(new KeyboardEvent('keyup', { bubbles: true, cancelable: true, keyCode: 143, which: 143 }));
      }, 1000 * 60 * 5); // 5 min


      // Strategy 2
      // function skipConfirmDialog() {
      //    // NOVA.waitElement('yt-confirm-dialog-renderer #confirm-button, a.yt-simple-endpoint.style-scope.yt-button-renderer')
      //    // NOVA.waitElement('[role="dialog"] #confirm-button')
      //    NOVA.waitElement('#confirm-button')
      //       .then(btn => {
      //          console.debug('page page wake up', btn);
      //          btn.click();
      //          if (NOVA.videoElement?.paused) NOVA.videoElement.play();
      //          // movie_player.playVideo();
      //          skipConfirmDialog(); // recursion init state. What would work more than once
      //       });
      // }

      // skipConfirmDialog();
   },
});
window.nova_plugins.push({
   id: 'video-autopause',
   title: 'Video auto pause',
   'title:zh': '视频自动暂停',
   'title:ja': 'ビデオの自動一時停止',
   'title:ko': '비디오 자동 일시 중지',
   'title:id': 'Jeda otomatis video',
   'title:es': 'Pausa automática de video',
   'title:pt': 'Pausa automática de vídeo',
   'title:fr': 'Pause automatique de la vidéo',
   'title:it': 'Pausa automatica del video',
   'title:tr': 'Video otomatik duraklatma',
   'title:de': 'Automatische Pause des Videos',
   'title:pl': 'Automatyczne zatrzymanie wideo',
   'title:ua': 'Автопауза',
   run_on_pages: 'watch, embed',
   restart_on_transition: true,
   section: 'player',
   desc: 'Disable autoplay',
   'desc:zh': '禁用自动播放',
   'desc:ja': '自動再生を無効にする',
   'desc:ko': '자동 재생 비활성화',
   'desc:it': 'Nonaktifkan putar otomatis',
   'desc:es': 'Deshabilitar reproducción automática',
   'desc:pt': 'Desativar reprodução automática',
   'desc:fr': 'Désactiver la lecture automatique',
   'desc:it': 'Disabilita la riproduzione automatica',
   'desc:tr': 'Otomatik oynatmayı devre dışı bırak',
   'desc:de': 'Deaktiviere Autoplay',
   'desc:pl': 'Wyłącz autoodtwarzanie',
   'desc:ua': 'Вимкнути автовідтворення',
   _runtime: user_settings => {

      // better use this flag when launching the chrome/imum:
      //  --autoplay-policy=user-gesture-required

      if (user_settings['video-stop-preload'] && !user_settings.stop_preload_embed) return; // disable if a similar plugin of higher priority is active
      if (user_settings.video_autopause_embed && NOVA.currentPage != 'embed') return;

      // NOVA.waitElement('video')
      NOVA.waitElement('#movie_player video')
         .then(video => {
            if (user_settings.video_autopause_ignore_live && movie_player.getVideoData().isLive) return;

            forceVideoPause.apply(video);
            // video.addEventListener('timeupdate', forceVideoPause.bind(video), { capture: true, once: true });
         });

      function forceVideoPause() {
         if (user_settings.video_autopause_ignore_playlist && location.search.includes('list=')) return;
         // if (user_settings.video_autopause_ignore_playlist && NOVA.queryURL.has('list')) return;

         this.pause();

         const forceHoldPause = setInterval(() => this.paused || this.pause(), 200); // 200ms
         // setTimeout(() => clearInterval(forceHoldPause), 1000); // 1s

         document.addEventListener('click', stopForceHoldPause);
         document.addEventListener('keyup', keyupSpace);

         function stopForceHoldPause() {
            if (movie_player.contains(document.activeElement)) {
               clearInterval(forceHoldPause);
               document.removeEventListener('keyup', keyupSpace);
               document.removeEventListener('click', stopForceHoldPause);
            }
         }

         function keyupSpace(evt) {
            // console.debug('evt.code', evt.code); // no sense if latch wich { capture: true, once: true }
            switch (evt.code) {
               case 'Space':
                  stopForceHoldPause()
                  break;
            }
         }
      }

   },
   options: {
      video_autopause_ignore_playlist: {
         _tagName: 'input',
         label: 'Ignore playlist',
         'label:zh': '忽略播放列表',
         'label:ja': 'プレイリストを無視する',
         'label:ko': '재생목록 무시',
         'label:id': 'Abaikan daftar putar',
         'label:es': 'Ignorar lista de reproducción',
         'label:pt': 'Ignorar lista de reprodução',
         'label:fr': 'Ignorer la liste de lecture',
         'label:it': 'Ignora playlist',
         'label:tr': 'Oynatma listesini yoksay',
         'label:de': 'Wiedergabeliste ignorieren',
         'label:pl': 'Zignoruj listę odtwarzania',
         'label:ua': 'Ігнорувати список відтворення',
         type: 'checkbox',
         'data-dependent': { 'video_autopause_embed': false },
      },
      video_autopause_ignore_live: {
         _tagName: 'input',
         label: 'Ignore live',
         // 'label:zh': '',
         // 'label:ja': '',
         // 'label:ko': '',
         // 'label:id': '',
         // 'label:es': '',
         // 'label:pt': '',
         // 'label:fr': '',
         // 'label:it': '',
         // 'label:tr': '',
         // 'label:de': '',
         // 'label:pl': '',
         'label:ua': 'Ігнорувти живі трансляції',
         type: 'checkbox',
         'data-dependent': { 'video_autopause_embed': false },
      },
      // video_autopause_embed: {
      //    _tagName: 'input',
      //    label: 'Only for embedded videos',
      //    'label:zh': '仅适用于嵌入式视频',
      //    'label:ja': '埋め込みビデオのみ',
      //    'label:ko': '삽입된 동영상에만 해당',
      //    'label:id': 'Hanya untuk video tersemat',
      //    'label:es': 'Solo para videos incrustados',
      //    'label:pt': 'Apenas para vídeos incorporados',
      //    'label:fr': 'Uniquement pour les vidéos intégrées',
      //    'label:it': 'Solo per i video incorporati',
      //    'label:tr': 'Yalnızca gömülü videolar için',
      //    'label:de': 'Nur für eingebettete Videos',
      //    'label:pl': 'Tylko dla osadzonych filmów',
      //    'label:ua': 'Тільки для вбудованих відео',
      //    type: 'checkbox',
      // },
      video_autopause_embed: {
         _tagName: 'select',
         label: 'Apply to video',
         'label:ua': 'Застосувати до відео',
         options: [
            { label: 'all', value: false, selected: true, 'label:ua': 'всіх' },
            { label: 'embed', value: 'on', 'label:ua': 'вбудованих' },
         ],
      },
   }
});
window.nova_plugins.push({
   id: 'player-fullscreen-mode',
   // title: 'Auto full screen player,
   title: 'Auto full screen on playback',
   'title:zh': '播放时自动全屏',
   'title:ja': '再生時に全画面表示',
   'title:ko': '재생 시 자동 전체 화면',
   'title:id': 'Layar penuh otomatis saat diputar',
   'title:es': 'Pantalla completa automática en reproducción',
   'title:pt': 'Tela cheia automática na reprodução',
   'title:fr': 'Plein écran automatique lors de la lecture',
   'title:it': 'Schermo intero automatico durante la riproduzione',
   'title:tr': 'Oynatmada otomatik tam ekran',
   'title:de': 'Automatischer Vollbildmodus bei Wiedergabe',
   'title:pl': 'Pełny ekran podczas odtwarzania',
   'title:ua': 'Автоматичне ввімкнення повного екрану при відтворенні',
   run_on_pages: 'watch',
   section: 'player',
   // desc: '',
   _runtime: user_settings => {

      NOVA.waitElement('video')
         .then(video => {
            // init
            video.addEventListener('play', setFullscreen.bind(video), { capture: true, once: true });
            // on page reload
            video.addEventListener('loaddata', setFullscreen.bind(video));
            video.addEventListener('ended', exitFullscreen.bind(video));

            // exit fullscreen
            if (user_settings.player_fullscreen_mode_onpause) {
               // Strategy 1
               video.addEventListener('play', setFullscreen.bind(video));
               video.addEventListener('pause', exitFullscreen.bind(video));
               // Strategy 2
               // movie_player.addEventListener('onStateChange', state => {
               //    if (document.fullscreen && movie_player.isFullscreen() && (NOVA.getPlayerState(state) == 'ENDED')) {
               //       movie_player.toggleFullscreen();
               //    }
               // });
            }
         });

      function setFullscreen() {
         if (movie_player.classList.contains('ad-showing')) return;

         if (!movie_player.isFullscreen()) {
            if (location.host == 'm.youtube.com') {
               document.body.querySelector('button.fullscreen-icon')?.click();

            } else {
               movie_player.toggleFullscreen();
            }
         }
      }

      function exitFullscreen() {
         // WTF - TypeError: Failed to execute 'exitFullscreen' on 'Document': Illegal invocation
         document.fullscreenElement && document?.exitFullscreen();
      }

   },
   options: {
      player_fullscreen_mode_onpause: {
         _tagName: 'input',
         label: 'Exit full screen mode if video is paused',
         'label:zh': '如果视频暂停，则退出全屏模式',
         'label:ja': 'ビデオが一時停止している場合は、全画面表示モードを終了します',
         'label:ko': '비디오가 일시 중지되면 전체 화면 모드 종료',
         'label:id': 'Keluar dari mode layar penuh jika video dijeda',
         'label:es': 'Salga del modo de pantalla completa si el video está en pausa',
         'label:pt': 'Saia do modo de tela cheia se o vídeo estiver pausado',
         'label:fr': 'Quitter le mode plein écran si la vidéo est en pause',
         'label:it': 'Uscire dalla modalità a schermo intero se il video è in pausa',
         'label:tr': 'Video duraklatılırsa tam ekran modundan çıkın',
         'label:de': 'Beenden Sie den Vollbildmodus, wenn das Video angehalten ist',
         'label:pl': 'Wyjdź z trybu pełnoekranowego, jeśli wideo jest wstrzymane',
         'label:ua': 'Вихід з повного екрану зупиняє відео',
         type: 'checkbox',
      },
   }
});
window.nova_plugins.push({
   id: 'player-pin-scroll',
   title: 'Pin player while scrolling',
   'title:zh': '滚动时固定播放器',
   'title:ja': 'スクロール中にプレイヤーを固定する',
   'title:ko': '스크롤하는 동안 플레이어 고정',
   'title:id': 'Sematkan pemutar saat menggulir',
   'title:es': 'Fijar jugador mientras se desplaza',
   'title:pt': 'Fixar jogador enquanto rola',
   'title:fr': 'Épingler le lecteur pendant le défilement',
   'title:it': 'Blocca il lettore durante lo scorrimento',
   'title:tr': 'Kaydırırken oynatıcıyı sabitle',
   'title:de': 'Pin-Player beim Scrollen',
   'title:pl': 'Przypnij odtwarzacz podczas przewijania',
   'title:ua': 'Закріпити відтворювач коли гортаєш сторінку',
   run_on_pages: 'watch, -mobile',
   section: 'player',
   desc: 'Mini player',
   // desc: 'Player stays always visible while scrolling',
   // 'desc:zh': '滚动时播放器始终可见',
   // 'desc:ja': 'スクロール中、プレーヤーは常に表示されたままになります',
   // 'desc:ko': '스크롤하는 동안 플레이어가 항상 표시됨',
   // 'desc:id': '',
   // // 'desc:es': 'El jugador permanece siempre visible mientras se desplaza',
   // 'desc:pt': 'O jogador fica sempre visível enquanto rola',
   // // 'desc:fr': 'Le lecteur reste toujours visible pendant le défilement',
   // 'desc:it': '',
   // 'desc:tr': 'Kaydırma sırasında oyuncu her zaman görünür kalır',
   // 'desc:de': 'Player bleibt beim Scrollen immer sichtbar',
   // 'desc:ua': 'Відтворювач завжди залишається видимим коли гортаєш',
   _runtime: user_settings => {

      if (!('IntersectionObserver' in window)) return alert('Nova\n\nPin player Error!\nIntersectionObserver not supported.');

      if (user_settings['description-popup']
         && (user_settings['comments-popup'] || user_settings['comments-visibility'])
         && user_settings['related-visibility']
      ) return alert('Nova\nSimultaneous activation of such plugins as:\n- description-popup\n- comments-popup/visibility\n- related-visibility\n\nconflict with the plugin "Pin player"');

      // alt - https://developer.chrome.com/blog/media-updates-in-chrome-73/#auto-pip
      // only for PWA
      // NOVA.waitElement('video')
      //    .then(vid => {
      //       vid.setAttribute('autopictureinpicture', '');
      //    });
      // return;

      // Doesn't work because scroll is not part of the [user-trusted events](https://html.spec.whatwg.org/multipage/interaction.html#triggered-by-user-activation).
      // if (user_settings.player_pin_mode == 'pip') {
      //    // alt - https://chrome.google.com/webstore/detail/gcfcmfbcpibcjmcinnimklngkpkkcing
      //    if (!document.pictureInPictureEnabled) return console.error('document pip is disable');

      //    NOVA.waitElement('video')
      //       .then(video => {
      //          if (video.disablePictureInPicture) return console.error('video pip is disable');

      //          const pipBtn = document.createElement('button');
      //          pipBtn.style.display = 'none';
      //          pipBtn.addEventListener('click', () => document.pictureInPictureElement
      //             ? document.exitPictureInPicture() : NOVA.videoElement.requestPictureInPicture()
      //          );
      //          pipBtn.addEventListener('click', () => NOVA.videoElement.requestPictureInPicture());
      //          document.body.prepend(pipBtn);

      //          new window.IntersectionObserver(async ([entry]) => {
      //             if (entry.isIntersecting) {
      //                if (video === document.pictureInPictureElement) {
      //                   console.debug('exitPictureInPicture');
      //                   // await document.exitPictureInPicture();
      //                   simulClick(pipBtn);
      //                }
      //                return
      //             }
      //             if (!document.pictureInPictureElement && video.readyState > 0) {
      //                console.debug('requestPictureInPicture');
      //                // await video.requestPictureInPicture();
      //                simulClick(pipBtn);
      //             }
      //          }, {
      //             root: null,
      //             threshold: 0.2, // set offset 0.X means trigger if atleast X0% of element in viewport
      //          })
      //             .observe(video);

      //          function simulClick(el) {
      //             const clickEvent = document.createEvent('MouseEvents');
      //             clickEvent.initEvent('click', true, true);
      //             clickEvent.artificialevent = true;
      //             el.dispatchEvent(clickEvent);
      //          }
      //       });
      //    return;
      // }

      const
         CLASS_VALUE = 'nova-player-pin',
         PINNED_SELECTOR = '.' + CLASS_VALUE, // for css
         UNPIN_BTN_CLASS_VALUE = CLASS_VALUE + '-unpin-btn',
         UNPIN_BTN_SELECTOR = '.' + UNPIN_BTN_CLASS_VALUE; // for css

      // if player fullscreen desable float mode
      document.addEventListener('fullscreenchange', () =>
         (document.fullscreen || movie_player.isFullscreen()) && movie_player.classList.remove(CLASS_VALUE));

      // toggle
      NOVA.waitElement('#player-theater-container')
         .then(container => {
            // movie_player / #ytd-player
            new IntersectionObserver(([entry]) => {
               // leave viewport
               if (entry.isIntersecting) {
                  movie_player.classList.remove(CLASS_VALUE);
                  drag.reset(); // save old pos. Clear curr pos

               } else if (!movie_player.isFullscreen()) { // enter viewport // fix bug on scroll in fullscreen player mode
                  // } else { // enter viewport
                  movie_player.classList.add(CLASS_VALUE);
                  drag?.storePos?.X && drag.setTranslate(drag.storePos); // restore pos
               }

               window.dispatchEvent(new Event('resize')); // fix: restore player size if un/pin
            }, {
               // https://github.com/raingart/Nova-YouTube-extension/issues/28
               // threshold: (+user_settings.player_float_scroll_sensivity_range / 100) || .5, // set offset 0.X means trigger if atleast X0% of element in viewport
               threshold: .5, // set offset 0.X means trigger if atleast X0% of element in viewport
            })
               .observe(container);
         });

      NOVA.waitElement(PINNED_SELECTOR)
         .then(async player => {
            // add drag
            drag.init(player);

            // wait video size
            await NOVA.waitUntil(
               // movie_player.clientWidth && movie_player.clientHeight
               () => (NOVA.videoElement?.videoWidth && NOVA.videoElement?.videoHeight)
               // && document.getElementById('masthead-container')?.offsetHeight
               , 500) // 500ms

            initMiniStyles();

            NOVA.css.push(
               PINNED_SELECTOR + ` {
                  --zIndex: ${Math.max(
                  NOVA.css.getValue('#chat', 'z-index'),
                  NOVA.css.getValue('.ytp-chrome-top .ytp-cards-button', 'z-index'),
                  // NOVA.css.getValue('#description', 'z-index'), // consider plugin "description-popup"
                  // getComputedStyle(document.getElementById('chat'))['z-index'],
                  // getComputedStyle(document.body.querySelector('.ytp-chrome-top .ytp-cards-button'))['z-index'],
                  // // getComputedStyle(document.getElementById('description'))['z-index'], // consider plugin "description-popup"
                  601) + 1};
               }

               ${UNPIN_BTN_SELECTOR} { display: none; }

               ${PINNED_SELECTOR} ${UNPIN_BTN_SELECTOR} {
                  display: initial !important;
                  position: absolute;
                  cursor: pointer;
                  top: 10px;
                  left: 10px;
                  width: 28px;
                  height: 28px;
                  color: white;
                  border: none;
                  outline: none;
                  opacity: .1;
                  /* border-radius: 100%; */
                  z-index: var(--zIndex);
                  font-size: 24px;
                  font-weight: bold;
                  background-color: rgba(0, 0, 0, 0.8);
                  /* text-transform: uppercase; */
               }

               ${PINNED_SELECTOR}:hover ${UNPIN_BTN_SELECTOR} { opacity: .7; }
               ${UNPIN_BTN_SELECTOR}:hover { opacity: 1 !important; }`);

            // add unpin button
            const btnUnpin = document.createElement('button');
            btnUnpin.className = UNPIN_BTN_CLASS_VALUE;
            btnUnpin.title = 'Unpin player';
            btnUnpin.textContent = '×'; // ✖
            btnUnpin.addEventListener('click', () => {
               player.classList.remove(CLASS_VALUE);
               drag.reset('clear_storePos');
               window.dispatchEvent(new Event('resize')); // fix: restore player size if unpinned
            });
            player.append(btnUnpin);
         });

      function initMiniStyles() {
         const scrollbarWidth = (window.innerWidth - document.documentElement.clientWidth || 0) + 'px';
         const miniSize = NOVA.calculateAspectRatioFit({
            // 'srcWidth': movie_player.clientWidth,
            // 'srcHeight': movie_player.clientHeight,
            'srcWidth': NOVA.videoElement.videoWidth,
            'srcHeight': NOVA.videoElement.videoHeight,
            'maxWidth': (window.innerWidth / user_settings.player_float_scroll_size_ratio),
            'maxHeight': (window.innerHeight / user_settings.player_float_scroll_size_ratio),
         });

         let initcss = {
            width: miniSize.width + 'px',
            height: miniSize.height + 'px',
            position: 'fixed',
            'z-index': 'var(--zIndex)',
            'box-shadow': '0 16px 24px 2px rgba(0, 0, 0, 0.14),' +
               '0 6px 30px 5px rgba(0, 0, 0, 0.12),' +
               '0 8px 10px -5px rgba(0, 0, 0, 0.4)',
         };

         // set pin player position
         switch (user_settings.player_float_scroll_position) {
            // if enable header-unfixed plugin. masthead-container is unfixed
            case 'top-left':
               initcss.top = user_settings['header-unfixed'] ? 0
                  : (document.getElementById('masthead-container')?.offsetHeight || 0) + 'px';
               initcss.left = 0;
               break;
            case 'top-right':
               initcss.top = user_settings['header-unfixed'] ? 0
                  : (document.getElementById('masthead-container')?.offsetHeight || 0) + 'px';
               initcss.right = scrollbarWidth; // scroll right
               break;
            case 'bottom-left':
               initcss.bottom = 0;
               initcss.left = 0;
               break;
            case 'bottom-right':
               initcss.bottom = 0;
               initcss.right = scrollbarWidth; // scroll right
               break;
         }

         // apply css
         NOVA.css.push(initcss, PINNED_SELECTOR, 'important');

         // variable declaration for fix
         NOVA.css.push(
            PINNED_SELECTOR + `{
               --height: ${initcss.height} !important;
               --width: ${initcss.width} !important;
            }`);
         // fix control-player panel
         NOVA.css.push(`
            ${PINNED_SELECTOR} .ytp-preview,
            ${PINNED_SELECTOR} .ytp-scrubber-container,
            ${PINNED_SELECTOR} .ytp-hover-progress,
            ${PINNED_SELECTOR} .ytp-gradient-bottom { display:none !important; }
            ${PINNED_SELECTOR} .ytp-chrome-bottom { width: var(--width) !important; }
            ${PINNED_SELECTOR} .ytp-chapters-container { display: flex; }`);

         // fix video size in pinned
         NOVA.css.push(
            `${PINNED_SELECTOR} video {
               width: var(--width) !important;
               height: var(--height) !important;
               left: 0 !important;
               top: 0 !important;
            }

            .ended-mode video {
               visibility: hidden;
            }`);
      }

      const drag = {
         // DEBUG: true,

         // xOffset: 0,
         // yOffset: 0,
         // currentX: 0,
         // currentY: 0,
         // dragTarget: HTMLElement,
         // active: false,
         // storePos: { X, Y },
         attrNametoLock: 'force_fix_preventDefault', // preventDefault patch

         reset(clear_storePos) {
            // switchElement.style.transform = ''; // clear drag state
            this.dragTarget?.style.removeProperty('transform');// clear drag state
            if (clear_storePos) this.storePos = this.xOffset = this.yOffset = 0;
            else this.storePos = { 'X': this.xOffset, 'Y': this.yOffset }; // save pos
         },

         init(el_target = required(), callbackExport) { // init
            this.log('drag init', ...arguments);
            if (!(el_target instanceof HTMLElement)) return console.error('el_target not HTMLElement:', el_target);

            this.dragTarget = el_target;

            // touchs
            // document.addEventListener('touchstart', this.dragStart.bind(this));
            // document.addEventListener('touchend', this.dragEnd.bind(this));
            // document.addEventListener('touchmove', this.draging.bind(this));
            // mouse
            // document.addEventListener('mousedown', this.dragStart.bind(this));
            // document.addEventListener('mouseup', this.dragEnd.bind(this));
            // document.addEventListener('mousemove', this.draging.bind(this));
            document.addEventListener('mousedown', evt => {
               if (!el_target.classList.contains(CLASS_VALUE)) return;
               this.dragStart.apply(this, [evt]);
            });
            document.addEventListener('mouseup', evt => {
               if (this.active) this.dragTarget.removeAttribute(this.attrNametoLock); // fix broken preventDefault
               this.dragEnd.apply(this, [evt]);
            });
            document.addEventListener('mousemove', evt => {
               if (this.active && !this.dragTarget.hasAttribute(this.attrNametoLock)) {
                  this.dragTarget.setAttribute(this.attrNametoLock, true); // fix broken preventDefault
               }
               this.draging.apply(this, [evt]);
            });

            // fix broken preventDefault / preventDefault patch
            NOVA.css.push(
               `[${this.attrNametoLock}]:active {
                  pointer-events: none;
                  cursor: grab; /* <-- Doesn't work */
                  outline: 2px dashed #3ea6ff !important;
               }`);
         },

         dragStart(evt) {
            if (!this.dragTarget.contains(evt.target)) return;
            this.log('dragStart');

            switch (evt.type) {
               case 'touchstart':
                  this.initialX = evt.touches[0].clientX - (this.xOffset || 0);
                  this.initialY = evt.touches[0].clientY - (this.yOffset || 0);
                  break;
               case 'mousedown':
                  this.initialX = evt.clientX - (this.xOffset || 0);
                  this.initialY = evt.clientY - (this.yOffset || 0);
                  break;
            }
            this.active = true;
         },

         dragEnd(evt) {
            if (!this.active) return;
            this.log('dragEnd');

            this.initialX = this.currentX;
            this.initialY = this.currentY;
            this.active = false;
         },

         draging(evt) {
            if (!this.active) return;
            evt.preventDefault(); // Doesn't work. Replace to preventDefault patch
            evt.stopImmediatePropagation(); // Doesn't work. Replace to preventDefault patch

            this.log('draging');

            switch (evt.type) {
               case 'touchmove':
                  this.currentX = evt.touches[0].clientX - this.initialX;
                  this.currentY = evt.touches[0].clientY - this.initialY;
                  break;
               case 'mousemove':
                  this.currentX = evt.clientX - this.initialX;
                  this.currentY = evt.clientY - this.initialY;
                  break;
            }

            this.xOffset = this.currentX;
            this.yOffset = this.currentY;

            this.setTranslate({ 'X': this.currentX, 'Y': this.currentY });
         },

         setTranslate({ X = required(), Y = required() }) {
            this.log('setTranslate', ...arguments);
            this.dragTarget.style.transform = `translate3d(${X}px, ${Y}px, 0)`;
         },

         log() {
            if (this.DEBUG && arguments.length) {
               console.groupCollapsed(...arguments);
               console.trace();
               console.groupEnd();
            }
         },
      };

   },
   options: {
      // player_pin_mode: {
      //    _tagName: 'select',
      //    label: ' mode',
      //    label: 'Mode',
      //    'label:zh': '模式',
      //    'label:ja': 'モード',
      //    'label:ko': '방법',
      //    // 'label:id': 'Mode',
      //    'label:es': 'Modo',
      //    'label:pt': 'Modo',
      //    // 'label:fr': 'Mode',
      //    'label:it': 'Modalità',
      //    'label:tr': 'Mod',
      //    'label:de': 'Modus',
      //    'label:pl': 'Tryb',
      //    // title: '',
      //    options: [
      //       { label: 'Picture-in-Picture', value: 'pip', selected: true },
      //       { label: 'Float', value: 'float' },
      //    ],
      // },
      player_float_scroll_size_ratio: {
         _tagName: 'input',
         label: 'Player size',
         'label:zh': '播放器尺寸',
         'label:ja': 'プレーヤーのサイズ',
         'label:ko': '플레이어 크기',
         'label:id': 'Ukuran pemain',
         'label:es': 'Tamaño del jugador',
         'label:pt': 'Tamanho do jogador',
         'label:fr': 'Taille du joueur',
         'label:it': 'Dimensioni del giocatore',
         'label:tr': 'Oyuncu boyutu',
         'label:de': 'Spielergröße',
         'label:pl': 'Rozmiar odtwarzacza',
         'label:ua': 'Розмір відтворювача',
         type: 'number',
         title: 'less value - larger size',
         'title:zh': '较小的值 - 较大的尺寸',
         'title:ja': '小さい値-大きいサイズ',
         'title:ko': '더 작은 값 - 더 큰 크기',
         'title:id': 'Nilai lebih kecil - ukuran lebih besar',
         'title:es': 'Valor más pequeño - tamaño más grande',
         'title:pt': 'Valor menor - tamanho maior',
         'title:fr': 'Plus petite valeur - plus grande taille',
         'title:it': 'Meno valore - dimensioni maggiori',
         'title:tr': 'Daha az değer - daha büyük boyut',
         'title:de': 'Kleiner Wert - größere Größe',
         'title:pl': 'Mniejsza wartość - większy rozmiar',
         'title:ua': 'Менше значення - більший розмір',
         placeholder: '2-5',
         step: 0.1,
         min: 2,
         max: 5,
         value: 2.5,
         // 'data-dependent': { 'player_pin_mode': ['float'] },
      },
      player_float_scroll_position: {
         _tagName: 'select',
         label: 'Player position',
         'label:zh': '球员位置',
         'label:ja': 'プレイヤーの位置',
         'label:ko': '선수 위치',
         'label:id': 'Posisi pemain',
         'label:es': 'Posición de jugador',
         'label:pt': 'Posição do jogador',
         'label:fr': 'La position du joueur',
         'label:it': 'Posizione del giocatore',
         'label:tr': 'Oyuncu pozisyonu',
         'label:de': 'Spielerposition',
         'label:pl': 'Pozycja odtwarzacza',
         'label:ua': 'Позиція відтворювача',
         options: [
            { label: 'left-top', value: 'top-left' },
            { label: 'left-bottom', value: 'bottom-left' },
            { label: 'right-top', value: 'top-right', selected: true },
            { label: 'right-bottom', value: 'bottom-right' },
         ],
         // 'data-dependent': { 'player_pin_mode': ['float'] },
      },
      // player_float_scroll_sensivity_range: {
      //    _tagName: 'input',
      //    label: 'Player sensitivity visibility range',
      //    'label:zh': '播放器灵敏度可见范围',
      //    'label:ja': 'プレイヤーの感度の可視範囲',
      //    'label:ko': '플레이어 감도 가시 범위',
      //    'label:id': 'Rentang visibilitas sensitivitas pemain',
      //    'label:es': 'Rango de visibilidad de la sensibilidad del jugador',
      //    'label:pt': 'Faixa de visibilidade da sensibilidade do jogador',
      //    'label:fr': 'Plage de visibilité de la sensibilité du joueur',
      //    'label:it': 'Intervallo di visibilità della sensibilità del giocatore',
      //    'label:tr': 'Oyuncu duyarlılığı görünürlük aralığı',
      //    'label:de': 'Sichtbarkeitsbereich der Spielerempfindlichkeit',
      //    'label:pl': 'Pozycja odtwarzacza',
      //    'label:ua': 'Діапазон видимості чутливості відтворювача',
      //    type: 'number',
      //    title: 'in %',
      //    placeholder: '%',
      //    step: 10,
      //    min: 10,
      //    max: 100,
      //    value: 80,
      //    // 'data-dependent': { 'player_pin_mode': ['float'] },
      // },
      // 'player_float_scroll_pause_video': {
      //    _tagName: 'input',
      //    label: 'Pause pinned video',
      //    type: 'checkbox',
      // },
   }
});

// for testing
// https://www.youtube.com/watch?v=LhKT9NTH9HA - dont have 480p
// https://www.youtube.com/watch?v=FZovbrEP53o - dont have 480p

window.nova_plugins.push({
   id: 'video-quality',
   title: 'Video quality',
   'title:zh': '视频质量',
   'title:ja': 'ビデオ品質',
   'title:ko': '비디오 품질',
   'title:id': 'Kualitas video',
   'title:es': 'Calidad de video',
   'title:pt': 'Qualidade de vídeo',
   'title:fr': 'Qualité vidéo',
   'title:it': 'Qualità video',
   'title:tr': 'Video kalitesi',
   'title:de': 'Videoqualität',
   'title:pl': 'Jakość wideo',
   'title:ua': 'Якість відео',
   run_on_pages: 'watch, embed',
   section: 'player',
   // desc: '',
   _runtime: user_settings => {

      let selectedQuality = user_settings.video_quality;

      NOVA.waitElement('#movie_player')
         .then(movie_player => {
            // keep save manual quality in the session
            if (user_settings.video_quality_manual_save_in_tab && NOVA.currentPage == 'watch') { // no sense if in the embed
               movie_player.addEventListener('onPlaybackQualityChange', quality => {
                  // console.debug('document.activeElement,',document.activeElement);
                  if (document.activeElement.getAttribute('role') == 'menuitemradio' // focuse on setting menu
                     && quality !== selectedQuality // the new quality
                  ) {
                     console.info(`keep quality "${quality}" in the session`);
                     selectedQuality = quality;
                  }
               });
            }

            setQuality(); // init

            movie_player.addEventListener('onStateChange', setQuality); // update
         });

      function setQuality(state) {
         if (!selectedQuality) return console.error('selectedQuality unavailable', selectedQuality);
         // console.debug('playerState', NOVA.getPlayerState(state));

         // if ((1 == state || 3 == state) && !setQuality.quality_busy) {
         if (['PLAYING', 'BUFFERING'].includes(NOVA.getPlayerState(state)) && !setQuality.quality_busy) {
            setQuality.quality_busy = true;

            const waitQuality = setInterval(() => {
               const availableQualityLevels = movie_player.getAvailableQualityLevels();

               if (availableQualityLevels?.length) {
                  clearInterval(waitQuality);

                  const maxAvailableQuality = Math.max(availableQualityLevels.indexOf(selectedQuality), 0);
                  const newQuality = availableQualityLevels[maxAvailableQuality];

                  // if (!newQuality || movie_player.getPlaybackQuality() == selectedQuality) {
                  //    return console.debug('skip set quality');
                  // }

                  // if (!availableQualityLevels.includes(selectedQuality)) {
                  //    console.info(`no has selectedQuality: "${selectedQuality}". Choosing instead the top-most quality available "${newQuality}" of ${JSON.stringify(availableQualityLevels)}`);
                  // }

                  if (movie_player.hasOwnProperty('setPlaybackQuality')) {
                     // console.debug('use setPlaybackQuality');
                     movie_player.setPlaybackQuality(newQuality);
                  }

                  // set QualityRange
                  if (movie_player.hasOwnProperty('setPlaybackQualityRange')) {
                     // console.debug('use setPlaybackQualityRange');
                     movie_player.setPlaybackQualityRange(newQuality, newQuality);
                  }

                  // console.debug('availableQualityLevels:', availableQualityLevels);
                  // console.debug("try set quality:", newQuality);
                  // console.debug('current quality:', movie_player.getPlaybackQuality());
               }
            }, 50); // 50ms

            // } else if (['UNSTARTED', 'ENDED'].includes(NOVA.getPlayerState(state))) {
         } else if (state <= 0) {
            setQuality.quality_busy = false;
         }
      }

      // error detector
      NOVA.waitElement('.ytp-error [class*="reason"]')
         .then(error_reason_el => {
            if (alertText = error_reason_el.textContent) {
               // err ex:
               // This video isn't available at the selected quality. Please try again later.
               // An error occurred. Please try again later. (Playback ID: Ame9qzOk-p5tXqLS) Learn More
               // alert(alertText);
               throw alertText; // send to _pluginsCaptureException
            }
         });

   },
   options: {
      video_quality: {
         _tagName: 'select',
         label: 'Default quality',
         'label:zh': '默认视频质量',
         'label:ja': 'デフォルトのビデオ品質',
         'label:ko': '기본 비디오 품질',
         'label:id': 'Kualitas bawaan',
         'label:es': 'Calidad predeterminada',
         'label:pt': 'Qualidade padrão',
         'label:fr': 'Qualité par défaut',
         'label:it': 'Qualità predefinita',
         'label:tr': 'Varsayılan kalite',
         'label:de': 'Standardvideoqualität',
         'label:pl': 'Domyślna jakość',
         'label:ua': 'Звичайна якість',
         title: 'If unavailable, set max available quality',
         'title:zh': '如果不可用，将选择可用的最高质量。',
         'title:ja': '利用できない場合は、利用可能な最高の品質が選択されます。',
         'title:ko': '사용할 수 없는 경우 사용 가능한 최대 품질을 설정합니다.',
         'title:id': 'Jika tidak tersedia, atur kualitas maksimal yang tersedia',
         'title:es': 'Si no está disponible, establezca la calidad máxima disponible',
         'title:pt': 'Se não estiver disponível, defina a qualidade máxima disponível',
         'title:fr': 'Si non disponible, définissez la qualité maximale disponible',
         'title:it': 'Se non disponibile, imposta la massima qualità disponibile',
         'title:tr': 'Mevcut değilse, maksimum kullanılabilir kaliteyi ayarlayın',
         // 'title:de': 'Wenn nicht verfügbar, stellen Sie die maximal verfügbare Qualität ein',
         'title:pl': 'Jeśli nie dostępna, ustaw maksymalną dostępną jakość',
         'title:ua': 'Якщо недоступно, обрати максимальну доступну якість',
         // multiple: null,
         options: [
            // Available ['highres','hd2880','hd2160','hd1440','hd1080','hd720','large','medium','small','tiny']
            { label: '8K/4320p', value: 'highres' },
            // { label: '5K/2880p', value: 'hd2880' }, // missing like https://www.youtube.com/watch?v=Hbj3z8Db4Rk
            { label: '4K/2160p', value: 'hd2160' },
            { label: 'QHD/1440p', value: 'hd1440' },
            { label: 'FHD/1080p', value: 'hd1080', selected: true },
            { label: 'HD/720p', value: 'hd720' },
            { label: 'SD/480p', value: 'large' },
            { label: 'SD/360p', value: 'medium' },
            { label: 'SD/240p', value: 'small' },
            { label: 'SD/144p', value: 'tiny' },
            // { label: 'Auto', value: 'auto' }, // no sense, deactivation does too
         ],
      },
      video_quality_manual_save_in_tab: {
         _tagName: 'input',
         // label: 'Manually selected qualities are saved in the current tab' // too much long
         label: 'Save manually selected for the same tab',
         'label:zh': '手动选择的质量保存在当前选项卡中',
         'label:ja': '手動で選択した品質が現在のタブに保存されます',
         'label:ko': '동일한 탭에 대해 수동으로 선택한 저장',
         'label:id': 'Simpan dipilih secara manual untuk tab yang sama',
         'label:es': 'Guardar seleccionado manualmente para la misma pestaña',
         'label:pt': 'Salvar selecionado manualmente para a mesma guia',
         'label:fr': 'Enregistrer sélectionné manuellement pour le même onglet',
         'label:it': 'Salva selezionato manualmente per la stessa scheda',
         'label:tr': 'Aynı sekme için manuel olarak seçili kaydet',
         'label:de': 'Manuell für dieselbe Registerkarte ausgewählt speichern',
         'label:pl': 'Właściwości dla obecnej karty',
         'label:ua': 'Зберігати власноруч обрану якість для вкладки',
         type: 'checkbox',
         title: 'Affects to next videos',
         'title:zh': '对下一个视频的影响',
         'title:ja': '次の動画への影響',
         'title:ko': '다음 동영상에 영향',
         'title:id': 'Mempengaruhi video berikutnya',
         'title:es': 'Afecta a los siguientes videos',
         'title:pt': 'Afeta para os próximos vídeos',
         'title:fr': 'Affecte aux prochaines vidéos',
         'title:it': 'Influisce sui prossimi video',
         'title:tr': 'Sonraki videoları etkiler',
         'title:de': 'Beeinflusst die nächsten Videos',
         'title:pl': 'Zmiany w następnych filmach',
         'title:ua': 'Впливає на наступні відео',
      },
   }
});
window.nova_plugins.push({
   id: 'player-resume-playback',
   title: 'Remember playback time',
   // title: 'Resume playback time position',
   'title:zh': '恢复播放时间状态',
   'title:ja': '再生時間の位置を再開します',
   'title:ko': '재생 시간 위치 재개',
   'title:id': 'Lanjutkan posisi waktu pemutaran',
   'title:es': 'Reanudar posición de tiempo de reproducción',
   'title:pt': 'Retomar a posição do tempo de reprodução',
   'title:fr': 'Reprendre la position de temps de lecture',
   'title:it': 'Riprende la posizione del tempo di riproduzione',
   'title:tr': 'Oynatma süresi konumunu devam ettir',
   'title:de': 'Wiedergabezeitposition fortsetzen',
   'title:pl': 'Powrót do pozycji czasowej odtwarzania',
   'title:ua': 'Запам`ятати час відтворення',
   run_on_pages: 'watch, embed',
   section: 'player',
   desc: 'On page reload - resume playback',
   'desc:zh': '在页面重新加载 - 恢复播放',
   'desc:ja': 'ページがリロードされると、再生が復元されます',
   'desc:ko': '페이지 새로고침 시 - 재생 재개',
   'desc:id': 'Muat ulang halaman - lanjutkan pemutaran',
   'desc:es': 'En la recarga de la página - reanudar la reproducción',
   'desc:pt': 'Recarregar na página - retomar a reprodução',
   'desc:fr': 'Lors du rechargement de la page - reprendre la lecture',
   'desc:it': 'Ricarica alla pagina: riprende la riproduzione',
   'desc:tr': 'Sayfayı yeniden yükle - oynatmaya devam et',
   'desc:de': 'Auf Seite neu laden - Wiedergabe fortsetzen',
   'desc:pl': 'Przy ponownym załadowaniu strony - wznawiaj odtwarzanie',
   'desc:ua': 'Після завантаження - продовжити відтворення',
   _runtime: user_settings => {
      // fix - Failed to read the 'sessionStorage' property from 'Window': Access is denied for this document.
      if (!navigator.cookieEnabled && NOVA.currentPage == 'embed') return;

      // TODO adSkip alt. - add comparison by duration. Need stream test
      const
         CACHE_PREFIX = 'resume-playback-time',
         getCacheName = () => CACHE_PREFIX + ':' + (NOVA.queryURL.get('v') || movie_player.getVideoData().video_id);

      let cacheName = getCacheName(); // for optimization

      NOVA.waitElement('video')
         .then(video => {
            resumePlayback.apply(video);

            video.addEventListener('loadeddata', resumePlayback.bind(video));

            video.addEventListener('timeupdate', savePlayback.bind(video));

            // embed dont support "t=" parameter
            if (user_settings.player_resume_playback_url_mark && NOVA.currentPage != 'embed') {
               // ignore if initialized with a "t=" parameter
               if (NOVA.queryURL.has('t')) {
                  // for next video
                  document.addEventListener('yt-navigate-start',
                     connectSaveStateInURL.bind(video), { capture: true, once: true });

               } else {
                  connectSaveStateInURL.apply(video);
               }
            }
         });

      function savePlayback() {
         // ad skip
         if (this.currentTime > 5 && this.duration > 30 && !movie_player.classList.contains('ad-showing')) {
            // console.debug('save progress time', this.currentTime);
            sessionStorage.setItem(cacheName, ~~this.currentTime);
            // new URL(location.href).searchParams.set('t', ~~this.currentTime); // url way
         }
      }

      function resumePlayback() {
         if (NOVA.queryURL.has('t')
            // https://www.youtube.com/watch?time_continue=68&v=yWUMMg3dmFY&feature=emb_title
            // || NOVA.queryURL.has('time_continue')
         ) return;
         cacheName = getCacheName(); // for optimization

         if ((time = +sessionStorage.getItem(cacheName))
            && (time < (this.duration - 1)) // fix for playlist
         ) {
            // console.debug('resumePlayback', `${time}/${this.duration}`);
            this.currentTime = time;
         }
      }

      // function resumePlayback() {
      //    if (!isNaN(this.duration) && this.currentTime < this.duration) {
      //       window.location.hash = "t=" + this.currentTime;
      //    }
      // }

      function connectSaveStateInURL() {
         const changeUrl = (new_url = required()) => window.history.replaceState(null, null, new_url);
         let delaySaveOnPauseURL; // fix glitch update url when rewinding video
         // save
         this.addEventListener('pause', () => {
            if (this.currentTime < (this.duration - 1) && this.currentTime > 5 && this.duration > 10) { // fix video ended
               delaySaveOnPauseURL = setTimeout(() => {
                  changeUrl(NOVA.queryURL.set({ 't': ~~this.currentTime + 's' }));
               }, 100); // 100ms
            }
         })
         // clear
         this.addEventListener('play', () => {
            if (typeof delaySaveOnPauseURL === 'number') clearTimeout(delaySaveOnPauseURL);

            if (NOVA.queryURL.has('t')) changeUrl(NOVA.queryURL.remove('t'));
         });
      }

   },
   options: {
      player_resume_playback_url_mark: {
         _tagName: 'input',
         label: 'Mark time in URL when paused',
         'label:zh': '暂停时在 URL 中节省时间',
         'label:ja': '一時停止したときにURLで時間を節約する',
         'label:ko': '일시 중지 시 URL에 시간 표시',
         'label:id': 'Tandai waktu di URL saat dijeda',
         'label:es': 'Marcar tiempo en URL cuando está en pausa',
         'label:pt': 'Marcar tempo no URL quando pausado',
         'label:fr': "Marquer l'heure dans l'URL en pause",
         'label:it': "Segna il tempo nell'URL quando è in pausa",
         'label:tr': "Duraklatıldığında zamanı URL'de işaretleyin",
         'label:de': 'Zeit in URL markieren, wenn pausiert',
         'label:pl': 'Zaznacz czas w adresie URL po wstrzymaniu',
         'label:ua': 'Маркувати час в URL-посиланні під час паузи',
         type: 'checkbox',
         title: 'update ?t=',
      },
   }
});
// for test:
// https://www.youtube.com/watch?v=Xt2sbtvBuk8 - have 3-digit timestamps in description, Manual chapter numbering
// https://www.youtube.com/watch?v=SgQ_Jk49FRQ - timestamp in pinned comment
// https://www.youtube.com/watch?v=tlICDvcCkog - timestamp in pinned comment#3 (bug has 1 chapters blocks). Manual chapter numbering
// https://www.youtube.com/watch?v=IvZOmE36PLc - many extra characters. Manual chapter numbering
// https://www.youtube.com/watch?v=hLXIK9DBxAo - very long text line of timestamp
// correct chapters:
// https://www.youtube.com/watch?v=egAB2qtVWFQ - ctitle of chapters before timestamp. Manual chapter numbering
// https://www.youtube.com/watch?v=IR0TBQV147I = lots 3-digit timestamp
// https://www.youtube.com/embed/JxTyMVPaOXY?autoplay=1 - embed
// false detect:
// https://www.youtube.com/watch?v=E-6gg0xKTPY - lying timestamp
// https://www.youtube.com/watch?v=Dg30oEk5Mw0 - timestamp in pinned comment #2 (once)
// https://www.youtube.com/watch?v=tNkZsRW7h2c - live

// test TitleOffset
// https://youtu.be/t_fbcgzmxHs

window.nova_plugins.push({
   id: 'time-jump',
   title: 'Time jump',
   'title:zh': '时间跳跃',
   'title:ja': 'タイムジャンプ',
   'title:ko': '시간 점프',
   'title:id': 'Lompatan waktu',
   'title:es': 'Salto de tiempo',
   'title:pt': 'Salto no tempo',
   'title:fr': 'Saut dans le temps',
   'title:it': 'Salto nel tempo',
   'title:tr': 'Zaman atlama',
   'title:de': 'Zeitsprung',
   'title:pl': 'Skok czasowy',
   'title:ua': 'Стрибок часу',
   run_on_pages: 'watch, embed, -mobile',
   section: 'player',
   desc: 'Use to skip the intro or ad inserts',
   'desc:zh': '用于跳过介绍或广告插入',
   'desc:ja': 'イントロや広告挿入をスキップするために使用します',
   'desc:ko': '인트로 또는 광고 삽입을 건너뛸 때 사용',
   'desc:id': 'Gunakan untuk melewati intro atau sisipan iklan',
   // 'desc:es': 'Úselo para omitir la introducción o las inserciones de anuncios.',
   'desc:pt': 'Use para pular a introdução ou inserções de anúncios',
   'desc:fr': "Utiliser pour ignorer l'intro ou les encarts publicitaires",
   // 'desc:it': "Utilizzare per saltare l'introduzione o gli inserti pubblicitari",
   'desc:tr': 'Girişi veya reklam eklerini atlamak için kullanın',
   // 'desc:de': 'Verwenden Sie diese Option, um das Intro oder Werbeeinblendungen zu überspringen',
   'desc:pl': 'Służy do pomijania wstępu lub wstawek reklamowych',
   'desc:ua': 'Використовуйте щоб пропустити інтро',
   _runtime: user_settings => {

      if (user_settings.time_jump_title_offset) addTitleOffset();

      switch (NOVA.currentPage) {
         case 'watch':
            let chapterList;

            // reset chapterList
            NOVA.waitElement('video')
               .then(video => video.addEventListener('loadeddata', () => chapterList = []));

            NOVA.waitElement('#movie_player')
               .then(movie_player => {
                  doubleKeyPressListener(timeLeap, user_settings.time_jump_hotkey);

                  function timeLeap() {
                     if (chapterList !== null && !chapterList?.length) { // null - chapterList is init: skiping
                        chapterList = NOVA.getChapterList(movie_player.getDuration()) || null;
                        // console.debug('chapterList:', chapterList);
                     }
                     const
                        nextChapterIndex = chapterList?.findIndex(c => c.sec > movie_player.getCurrentTime()),
                        separator = ' • ';
                     // console.debug('nextChapterIndex', nextChapterIndex);
                     let msg;
                     // has chapters and chapters not ended
                     if (chapterList?.length && nextChapterIndex !== -1) {
                        // has chapters blocks (Important! more than 1. See e.g. "(bug has 1 chapters blocks)"
                        if (movie_player.querySelectorAll('.ytp-chapter-hover-container')?.length > 1) {
                           // console.debug(`nextChapterIndex jump [${nextChapterIndex}] ${movie_player.getCurrentTime()?.toFixed(0)} > ${chapterList[nextChapterIndex].sec} sec`);
                           movie_player.seekToChapterWithAnimation(nextChapterIndex);

                           // querySelector update after seek
                           // const chapterTitleEl = movie_player.querySelector('.ytp-chapter-title-content');

                           // msg = (chapterTitleEl?.textContent || chapterList[nextChapterIndex].title)
                           //    + separator + chapterList[nextChapterIndex].time;

                           msg = chapterList[nextChapterIndex].title + separator + chapterList[nextChapterIndex].time;

                           // if (chapterTitleEl && user_settings.time_jump_chapters_list_show) {
                           //    chapterTitleEl.click()
                           // }

                        } else { // chapters blocks none, but has timestamp
                           const nextChapterData = chapterList?.find(({ sec }) => sec >= movie_player.getCurrentTime());
                           // console.debug(`nextChapterData jump [${nextChapterData.index}] ${movie_player.getCurrentTime()?.toFixed(0)} > ${nextChapterData.sec} sec`);
                           // +0.5 fix paused jump (ex: https://www.youtube.com/watch?v=Xt2sbtvBuk8)
                           movie_player.seekTo(nextChapterData.sec + .5);

                           msg = nextChapterData.title + separator + nextChapterData.time;
                        }

                     } else { // chapters none
                        movie_player.seekBy(+user_settings.time_jump_step);

                        msg = `+${user_settings.time_jump_step} sec` + separator + NOVA.timeFormatTo.HMS.digit(movie_player.getCurrentTime());
                     }

                     NOVA.bezelTrigger(msg); // trigger default indicator
                  }
               });
            break;

         case 'embed':
            NOVA.waitElement('video')
               .then(video => {
                  doubleKeyPressListener(timeLeap.bind(video), user_settings.time_jump_hotkey);

                  function timeLeap() {
                     let sec = +user_settings.time_jump_step + this.currentTime;

                     if (secNextChapter = seekToNextChapter.apply(this)) {
                        sec = secNextChapter;
                        // wait chapter-title update
                        document.body.querySelector('.ytp-chapter-title-content')
                           ?.addEventListener('DOMNodeInserted', ({ target }) => {
                              NOVA.bezelTrigger(
                                 target.textContent + ' • ' + NOVA.timeFormatTo.HMS.digit(video.currentTime)
                              );// trigger default indicator
                           }, { capture: true, once: true });
                     } else {
                        NOVA.bezelTrigger(`+${user_settings.time_jump_step} sec`); // trigger default indicator
                     }
                     // console.debug('seekTo', sec);
                     this.currentTime = sec;

                     function seekToNextChapter() {
                        if ((chaptersContainer = document.body.querySelector('.ytp-chapters-container'))
                           && chaptersContainer?.children.length > 1
                           && (progressContainerWidth = parseInt(getComputedStyle(chaptersContainer).width))
                        ) {
                           const progressRatio = this.currentTime / this.duration;
                           let passedWidth = 0;
                           for (const chapter of chaptersContainer.children) {
                              const
                                 { width, marginLeft, marginRight } = getComputedStyle(chapter),
                                 chapterWidth = parseInt(width),
                                 chapterMargin = parseInt(marginLeft) + parseInt(marginRight),
                                 chapterRatio = (passedWidth + chapterWidth) / progressContainerWidth;

                              // console.debug('Chapter', chapterRatio, chapterWidth);
                              if (chapterRatio >= progressRatio && chapterRatio < 1) {
                                 return ~~(chapterRatio * this.duration) + chapterMargin + 1;
                              }
                              // accumulate passed
                              passedWidth += chapterWidth + chapterMargin;
                           }
                           // console.debug('passedWidth', 'total=' + passedWidth, 'chapter count=' + chaptersContainer?.children.length, progressContainerWidth, '/', progressRatio);
                        }
                     }
                  }
               });
            break;
      }

      function addTitleOffset() {
         NOVA.css.push(
            `.ytp-tooltip-text:after {
               content: attr(data-before);
               color: #ffcc00;
            }`);
         // color: ${getComputedStyle(document.body.querySelector('.ytp-swatch-background-color'))['background-color'] || '#f00'};

         NOVA.waitElement('.ytp-progress-bar')
            .then(progressContainer => {
               if (tooltipEl = document.body.querySelector('.ytp-tooltip-text')) {
                  progressContainer.addEventListener('mousemove', () => {
                     if (movie_player.getVideoData().isLive
                        || (NOVA.currentPage == 'embed' && window.self.location.href.includes('live_stream'))
                     ) return;

                     const
                        cursorTime = NOVA.timeFormatTo.hmsToSec(tooltipEl.textContent),
                        offsetTime = cursorTime - NOVA.videoElement?.currentTime,
                        sign = offsetTime >= 1 ? '+' : Math.sign(offsetTime) === -1 ? '-' : '';
                     // updateOffsetTime
                     // console.debug('offsetTime', offsetTime, cursorTime, sign);
                     tooltipEl.setAttribute('data-before', ` ${sign + NOVA.timeFormatTo.HMS.digit(offsetTime)}`);
                  });
                  // hide titleOffset
                  progressContainer.addEventListener('mouseleave', () => tooltipEl.removeAttribute('data-before'));
               }
            });
      }

      function doubleKeyPressListener(callback, keyCodeFilter) {
         let
            pressed,
            isDoublePress,
            lastPressed = parseInt(keyCodeFilter) || null;

         const
            timeOut = () => setTimeout(() => isDoublePress = false, 500), // 500ms
            handleDoublePresss = key => {
               // console.debug(key.key, 'pressed two times');
               if (callback && typeof callback === 'function') return callback(key);
            };

         function keyPress(evt) {
            if (['input', 'textarea'].includes(evt.target.localName) || evt.target.isContentEditable) return;

            pressed = evt.keyCode;
            // console.debug('doubleKeyPressListener %s=>%s=%s', lastPressed, pressed, isDoublePress);
            if (isDoublePress && pressed === lastPressed) {
               isDoublePress = false;
               handleDoublePresss(evt);
            } else {
               isDoublePress = true;
               timeOut();
            }

            if (!keyCodeFilter) lastPressed = pressed;
         }
         document.addEventListener('keyup', keyPress);
      }

   },
   options: {
      time_jump_step: {
         _tagName: 'input',
         label: 'Step time',
         // 'label:ja': 'ステップ時間',
         'label:zh': '步骤时间',
         'label:ko': '단계 시간',
         'label:id': 'Langkah waktu',
         'label:es': 'Tiempo de paso',
         'label:pt': 'Tempo da etapa',
         'label:fr': 'Temps de pas',
         'label:it': 'Tempo di passaggio',
         'label:tr': 'Adım süresi',
         'label:de': 'Schrittzeit',
         'label:pl': 'Krok czasowy',
         'label:ua': 'Крок часу',
         type: 'number',
         title: 'in seconds',
         placeholder: 'sec',
         min: 3,
         max: 300,
         value: 30,
      },
      time_jump_hotkey: {
         _tagName: 'select',
         label: 'Hotkey (double click)',
         'label:zh': '热键（双击）',
         'label:ja': 'Hotkey (ダブルプレス)',
         'label:ko': '단축키(더블 클릭)',
         'label:id': 'Tombol pintas (klik dua kali)',
         'label:es': 'Tecla de acceso rápido (doble clic)',
         'label:pt': 'Atalho (duplo clique)',
         'label:fr': 'Raccourci clavier (double clic)',
         'label:it': 'Tasto di scelta rapida (doppio clic)',
         'label:tr': 'Kısayol tuşu (çift tıklama)',
         'label:de': 'Hotkey (Doppelklick)',
         'label:pl': 'Klawisz skrótu (podwójne kliknięcie)',
         'label:ua': 'Гаряча клавіша (двічі натиснути)',
         options: [
            // https://css-tricks.com/snippets/javascript/javascript-keycodes/
            { label: 'alt', value: 18 },
            { label: 'shift', value: 16 },
            { label: 'ctrl', value: 17, selected: true },
         ],
      },
      time_jump_title_offset: {
         _tagName: 'input',
         label: 'Show time offset on progress bar',
         'label:zh': '在进度条中显示时间偏移',
         'label:ja': 'プログレスバーに時間オフセットを表示する',
         'label:ko': '진행률 표시줄에 시간 오프셋 표시',
         'label:id': 'Tampilkan offset waktu di bilah kemajuan',
         'label:es': 'Mostrar compensación de tiempo en la barra de progreso',
         'label:pt': 'Mostrar a diferença de tempo na barra de progresso',
         'label:fr': 'Afficher le décalage horaire sur la barre de progression',
         'label:it': "Mostra l'offset di tempo sulla barra di avanzamento",
         'label:tr': 'İlerleme çubuğunda zaman ofsetini göster',
         'label:de': 'Zeitverschiebung im Fortschrittsbalken anzeigen',
         'label:pl': 'Pokaż przesunięcie czasu na pasku postępu',
         'label:ua': 'Показувати часовий зсув на панелі прогресу',
         type: 'checkbox',
         // title: 'When you hover offset current playback time',
         title: 'Time offset from current playback time',
         'title:zh': '与当前播放时间的时间偏移',
         'title:ja': '現在の再生時間からの時間オフセット',
         'title:ko': '현재 재생 시간으로부터의 시간 오프셋',
         'label:id': 'Waktu offset dari waktu pemutaran saat ini',
         'title:es': 'Desfase de tiempo del tiempo de reproducción actual',
         'title:pt': 'Deslocamento de tempo do tempo de reprodução atual',
         'title:fr': "Décalage temporel par rapport à l'heure de lecture actuelle",
         'title:it': 'Spostamento temporale dal tempo di riproduzione corrente',
         'title:tr': 'Geçerli oynatma süresinden zaman farkı',
         'title:de': 'Zeitverschiebung zur aktuellen Wiedergabezeit',
         'title:pl': 'Przesunięcie czasu względem bieżącego czasu odtwarzania',
         'title:ua': 'Часовий зсув відносно поточного часу відтворення',
      },
      // time_jump_chapters_list_show: {
      //    _tagName: 'input',
      //    label: 'Show chapters list section',
      //    'label:zh': '显示章节列表块',
      //    'label:ja': 'チャプターリストブロックを表示',
      //    'label:ko': '챕터 목록 섹션 표시',
      //    'label:id': 'Tampilkan bagian daftar bab',
      //    'label:es': 'Mostrar bloque de lista de capítulos',
      //    'label:pt': 'Mostrar bloco de lista de capítulos',
      //    'label:fr': 'Afficher la section de la liste des chapitres',
      //    'label:it': "Mostra la sezione dell'elenco dei capitoli",
      //    'label:tr': 'Bölüm listesi bölümünü göster',
      //    'label:de': 'Kapitellistenblock anzeigen',
      //    'label:pl': 'Pokaż sekcję listy rozdziałów',
      //    'label:ua': 'Показати розділ списку розділів',
      //    type: 'checkbox',
      // },
   }
});
window.nova_plugins.push({
   id: 'player-control-autohide',
   title: 'Hide controls on player',
   'title:zh': '播放器上的自动隐藏控件',
   'title:ja': 'プレーヤーのコントロールを自動非表示',
   'title:ko': '플레이어의 자동 숨기기 컨트롤',
   'title:id': 'Sembunyikan kontrol pada pemutar',
   'title:es': 'Ocultar automáticamente los controles en el reproductor',
   'title:pt': 'Auto-ocultar controles no player',
   'title:fr': 'Masque le panneau de contrôle du lecteur',
   'title:it': 'Nascondi i controlli sul giocatore',
   'title:tr': 'Oynatıcıdaki kontrolleri otomatik gizle',
   'title:de': 'Blendet das Player-Bedienfeld aus',
   'title:pl': 'Ukrywaj elementy w odtwarzaczu',
   'title:ua': 'Приховати панель керування у відтворювачі',
   run_on_pages: 'watch, -mobile',
   section: 'player',
   desc: 'Hover controls to display it',
   'desc:zh': '将鼠标悬停在它上面以显示它',
   'desc:ja': 'カーソルを合わせると表示されます',
   'desc:ko': '그것을 표시하려면 그 위로 마우스를 가져갑니다',
   'desc:id': 'Arahkan kontrol untuk menampilkannya',
   'desc:es': 'Coloca el cursor sobre él para mostrarlo',
   'desc:pt': 'Passe o mouse sobre ele para exibi-lo',
   'desc:fr': "Survolez-le pour l'afficher",
   'desc:it': 'Passa il mouse sui controlli per visualizzarlo',
   'desc:tr': 'Görüntülemek için üzerine gelin',
   'desc:de': 'Bewegen Sie den Mauszeiger darüber, um es anzuzeigen',
   'desc:pl': 'Najedź, aby wyświetlić',
   'desc:ua': 'Наведіть мишкою щоб показати',
   _runtime: user_settings => {

      NOVA.css.push(
         `.ytp-chrome-bottom {
            opacity: 0;
         }
         .ytp-chrome-bottom:hover {
            opacity: 1;
         }
         /* patch for plugin "player-float-progress-bar" */
         .ytp-chrome-bottom:not(:hover) ~ #nova-player-float-progress-bar {
            visibility: visible !important;
         }`);

   },
});
// for test
// https://www.youtube.com/watch?v=jx9LC2kyfcQ - ad rent block
// https://www.youtube.com/watch?v=jx9LC2kyfcQ - ad rent block

window.nova_plugins.push({
   id: 'ad-skip-button',
   // title: 'Auto click skip ads',
   title: 'Ad intro Skip',
   'title:zh': '广告视频跳过',
   'title:ja': '広告スキップ',
   'title:ko': '광고 건너뛰기',
   'title:id': 'Intro iklan Lewati',
   'title:es': 'Saltar anuncios',
   'title:pt': 'Pular anúncios',
   'title:fr': 'Ignorer les annonces',
   'title:it': 'Salta introduttivo',
   'title:tr': 'Reklam Atlama',
   'title:de': 'Anzeigen überspringen',
   'title:pl': 'Pomiń początkową reklamę',
   //'title:ua': 'Натиснути пропустити рекламу',
   'title:ua': 'Кнопка пропустити рекламу',
   run_on_pages: 'watch',
   section: 'player',
   desc: 'Auto click on [Skip Ad] button',
   'desc:zh': '自动点击“Skip Ad”按钮',
   'desc:ja': '「Skip Ad」ボタンの自動クリック',
   'desc:ko': '【광고 건너뛰기】버튼 자동 클릭',
   'desc:id': 'Klik otomatis pada tombol [Lewati Iklan]',
   'desc:es': 'Haga clic automáticamente en el botón [Omitir anuncio]',
   'desc:pt': 'Clique automaticamente no botão [Ignorar anúncio]',
   'desc:fr': "Clic automatique sur le bouton [Ignorer l'annonce]",
   'desc:it': 'Fare clic automaticamente sul pulsante [Salta annuncio].',
   'desc:tr': "Clic automatique sur le bouton [Ignorer l'annonce]",
   // 'desc:de': 'Klicken Sie automatisch auf die Schaltfläche [Anzeige überspringen]',
   'desc:pl': 'Auto kliknięcie przycisku [Pomiń reklamę]',
   'desc:ua': 'Автоматично натискати кнопку для пропуску реклами',
   _runtime: user_settings => {

      // NOVA.css.push( // hides the appearance when playing on the next video
      //    `#movie_player.ad-showing video {
      //       visibility: hidden !important;
      //    }`);

      NOVA.waitElement('#movie_player.ad-showing video')
         .then(video => {
            adSkip();

            video.addEventListener('loadeddata', adSkip.bind(video));
            video.addEventListener('canplay', adSkip.bind(video));
            // video.addEventListener('durationupdate', adSkip.bind(video)); // stream
         });

      // onSkipAdButtonClick
      function adSkip() {
         if (!movie_player.classList.contains('ad-showing')) return;

         this.currentTime = this.duration; // set end ad-video

         NOVA.waitElement('div.ytp-ad-text.ytp-ad-skip-button-text:not([hidden]), button.ytp-ad-skip-button:not([hidden])')
            .then(btn => btn.click()); // click skip-ad
      }
   },
});
window.nova_plugins.push({
   id: 'video-stop-preload',
   title: 'Stop video preload',
   'title:zh': '停止视频预加载',
   'title:ja': 'ビデオのプリロードを停止します',
   'title:ko': '비디오 미리 로드 중지',
   'title:id': 'Hentikan pramuat video',
   'title:es': 'Detener la precarga de video',
   'title:pt': 'Parar o pré-carregamento de vídeo',
   'title:fr': 'Arrêter le préchargement de la vidéo',
   'title:it': 'Interrompi il precaricamento del video',
   'title:tr': 'Video önyüklemesini durdur',
   'title:de': 'Beenden Sie das Vorladen des Videos',
   'title:pl': 'Zatrzymaj ładowanie wideo',
   'title:ua': 'Зупинити передзавантаження відео',
   run_on_pages: 'watch, embed',
   // restart_on_transition: true,
   section: 'player',
   desc: 'Prevent the player from buffering video before playing',
   _runtime: user_settings => {

      // alt - https://greasyfork.org/en/scripts/448590-youtube-autoplay-disable/code

      // if (user_settings['video-autopause']) return; // conflict with plugin. This plugin has a higher priority. that's why it's disabled/commented

      if (user_settings.stop_preload_embed) {
         // skip stoped embed - https://www.youtube.com/embed/668nUCeBHyY?autoplay=1
         if (NOVA.currentPage == 'embed' && window.self !== window.top// window.frameElement // is iframe?
            && !['0', 'false'].includes(NOVA.queryURL.get('autoplay'))
         ) {
            location.assign(NOVA.queryURL.set({ 'autoplay': false }));

         } else return;
      }

      NOVA.waitElement('#movie_player')
         .then(async movie_player => {
            let disableStop;

            // reset disableStop
            document.addEventListener('yt-navigate-start', () => disableStop = false);

            movie_player.addEventListener('onStateChange', onPlayerStateChange.bind(this));

            await NOVA.waitUntil(() => movie_player.hasOwnProperty('stopVideo')); // fix specific error for firefox
            movie_player.stopVideo(); // init before update onStateChange

            function onPlayerStateChange(state) {
               // console.debug('onStateChange', NOVA.getPlayerState(state), document.visibilityState);
               if (user_settings.stop_preload_ignore_playlist && location.search.includes('list=')) return;
               // // stop inactive tab
               // if (user_settings.stop_preload_ignore_active_tab && document.visibilityState == 'visible') {
               //    // console.debug('cancel stop in active tab');
               //    return;
               // }

               if (user_settings.stop_preload_ignore_live && movie_player.getVideoData().isLive) return;

               // -1: unstarted
               // 0: ended
               // 1: playing
               // 2: paused
               // 3: buffering
               // 5: cued
               // if (['BUFFERING', 'PAUSED', 'PLAYING'].includes(NOVA.getPlayerState(state))) {
               if (!disableStop && state > 0 && state < 5) {
                  movie_player.stopVideo();
               }
            }

            document.addEventListener('click', disableHoldStop);
            document.addEventListener('keyup', ({ code }) => (code == 'Space') && disableHoldStop());

            function disableHoldStop() {
               if (!disableStop && movie_player.contains(document.activeElement)) {
                  disableStop = true;
                  movie_player.playVideo(); // dirty fix. onStateChange starts before click/keyup
               }
            }
         });

   },
   options: {
      stop_preload_ignore_playlist: {
         _tagName: 'input',
         label: 'Ignore playlist',
         'label:zh': '忽略播放列表',
         'label:ja': 'プレイリストを無視する',
         'label:ko': '재생목록 무시',
         'label:id': 'Abaikan daftar putar',
         'label:es': 'Ignorar lista de reproducción',
         'label:pt': 'Ignorar lista de reprodução',
         'label:fr': 'Ignorer la liste de lecture',
         'label:it': 'Ignora playlist',
         'label:tr': 'Oynatma listesini yoksay',
         'label:de': 'Wiedergabeliste ignorieren',
         'label:pl': 'Zignoruj listę odtwarzania',
         'label:ua': 'Ігнорувати список відтворення',
         type: 'checkbox',
         'data-dependent': { 'stop_preload_embed': false },
      },
      stop_preload_ignore_live: {
         _tagName: 'input',
         label: 'Ignore live',
         // 'label:zh': '',
         // 'label:ja': '',
         // 'label:ko': '',
         // 'label:id': '',
         // 'label:es': '',
         // 'label:pt': '',
         // 'label:fr': '',
         // 'label:it': '',
         // 'label:tr': '',
         // 'label:de': '',
         // 'label:pl': '',
         'label:ua': 'Ігнорувати живі трансляції',
         type: 'checkbox',
         'data-dependent': { 'stop_preload_embed': false },
      },
      // stop_preload_embed: {
      //    _tagName: 'input',
      //    label: 'Only for embedded videos',
      //    'label:zh': '仅适用于嵌入式视频',
      //    'label:ja': '埋め込みビデオのみ',
      //    'label:ko': '삽입된 동영상에만 해당',
      //    'label:id': 'Hanya untuk video tersemat',
      //    'label:es': 'Solo para videos incrustados',
      //    'label:pt': 'Apenas para vídeos incorporados',
      //    'label:fr': 'Uniquement pour les vidéos intégrées',
      //    'label:it': 'Solo per i video incorporati',
      //    'label:tr': 'Yalnızca gömülü videolar için',
      //    'label:de': 'Nur für eingebettete Videos',
      //    'label:pl': 'Tylko dla osadzonych filmów',
      //    type: 'checkbox',
      // },
      stop_preload_embed: {
         _tagName: 'select',
         label: 'Apply to video',
         options: [
            { label: 'all', value: false, selected: true, 'label:ua': 'всіх' },
            { label: 'embed', value: 'on', 'label:ua': 'вбудованих' },
         ],
      },
      // stop_preload_ignore_active_tab: {
      //    _tagName: 'input',
      //    label: 'Only in inactive tab', // inactive - background
      //    // 'label:zh': '',
      //    // 'label:ja': '',
      //    // 'label:ko': '',
      //    // 'label:id': '',
      //    // 'label:es': '',
      //    // 'label:pt': '',
      //    // 'label:fr': '',
      //    // 'label:it': '',
      //    // 'label:tr': '',
      //    // 'label:de': '',
      //    // 'label:pl': '',
      //    // 'label:ua': '',
      //    type: 'checkbox',
      //    title: 'Ignore active tab',
      //    // 'title:zh': '',
      //    // 'title:ja': '',
      //    // 'title:ko': '',
      //    // 'label:id': '',
      //    // 'title:es': '',
      //    // 'title:pt': '',
      //    // 'title:fr': '',
      //    // 'title:it': '',
      //    // 'title:tr': '',
      //    // 'title:de': '',
      //    // 'title:pl': '',
      //    // 'label:ua': '',
      // },
   }
});
window.nova_plugins.push({
   id: 'theater-mode',
   title: 'Theater mode',
   // 'title:zh': '播放器全模式',
   // 'title:ja': 'プレーヤーフル-モード付き',
   // 'title:ko': '플레이어 풀-위드 모드',
   // 'title:id': '',
   // 'title:es': 'Reproductor completo con modo',
   // 'title:pt': 'Modo de jogador completo',
   // 'title:fr': 'Mode lecteur complet avec',
   // 'title:it': '',
   // 'title:tr': 'Oyuncu tam mod',
   // 'title:de': 'Player full-with-modus',
   'title:pl': 'Tryb kinowy',
   'title:ua': 'Режим кінотеарту',
   run_on_pages: 'watch, -mobile',
   section: 'player',
   // desc: '',
   _runtime: user_settings => {

      if (user_settings.player_full_viewport_mode == 'redirect_watch_to_embed') {
         return location.assign(`https://www.youtube.com/embed/` + NOVA.queryURL.get('v'));
      }

      // NOVA.waitElement('ytd-watch-flexy:not([theater])') // wrong way. Reassigns manual exit from the mode
      NOVA.waitElement('ytd-watch-flexy')
         .then(el => el.theaterModeChanged_(true));

      // for legacy user_settings
      if (!user_settings.player_full_viewport_mode && user_settings.cinema_mode) {
         user_settings.player_full_viewport_mode = 'cinema_mode';
      }

      NOVA.waitElement('#movie_player')
         .then(movie_player => {
            const
               PLAYER_CONTEINER_SELECTOR = 'ytd-watch-flexy[theater]:not([fullscreen]) #player-theater-container', // fix for "player-pin-scroll" plugin
               PLAYER_SCROLL_LOCK_CLASS_NAME = 'nova-lock-scroll',
               PLAYER_SELECTOR = `${PLAYER_CONTEINER_SELECTOR} #movie_player:not(.player-float):not(.${PLAYER_SCROLL_LOCK_CLASS_NAME})`, // fix for "player-pin-scroll" plugin
               zIindex = Math.max(
                  // getComputedStyle(document.getElementById('masthead-container'))['z-index'],
                  getComputedStyle(movie_player)['z-index'],
                  2020);

            addScrollDownBehavior();

            switch (user_settings.player_full_viewport_mode) {
               case 'force':
                  // alt - https://greasyfork.org/en/scripts/434075-youtube-fullscreen-mode
                  setPlayerFullViewport(user_settings.player_full_viewport_mode_exit);

               case 'smart':
                  // exclude shorts page #1
                  if (user_settings.player_full_viewport_mode_exclude_shorts && NOVA.currentPage == 'shorts') {
                     return;
                  }

                  NOVA.waitElement('video')
                     .then(video => {
                        video.addEventListener('loadeddata', function () {
                           // exclude shorts page #2
                           if (user_settings.player_full_viewport_mode_exclude_shorts && this.videoWidth < this.videoHeight) {
                              return;
                           }
                           const miniSize = NOVA.calculateAspectRatioFit({
                              'srcWidth': this.videoWidth,
                              'srcHeight': this.videoHeight,
                              // 'maxWidth': window.innerWidth,
                              // 'maxHeight': window.innerHeight,
                           });
                           // out of viewport
                           if (miniSize.width < window.innerWidth) {
                              setPlayerFullViewport('player_full_viewport_mode_exit');
                           }
                        });
                     });
                  break;

               case 'cinema_mode':
                  // alt - https://greasyfork.org/en/scripts/419359-youtube-simple-cinema-mode
                  NOVA.css.push(
                     PLAYER_CONTEINER_SELECTOR + `{ z-index: ${zIindex}; }

                     ${PLAYER_SELECTOR}:before {
                        content: '';
                        position: fixed;
                        top: 0;
                        left: 0;
                        width: 100%;
                        height: 100%;
                        background-color: rgba(0, 0, 0, ${+user_settings.cinema_mode_opacity});
                        opacity: 0;
                        transition: opacity .4s ease-in-out;
                        pointer-events: none;
                     }

                     /*#movie_player.paused-mode:before,*/
                     ${PLAYER_SELECTOR}.playing-mode:before {
                        opacity: 1;
                     }

                     /* fix */
                     .ytp-ad-player-overlay,
                     #playlist:hover,
                     #masthead-container:hover,
                     iframe, /*search result box*/
                     #guide,
                     [class*="popup"],
                     [role="navigation"],
                     [role="dialog"] {
                        z-index: ${zIindex + 1};
                     }
                     #playlist:hover {
                        position: relative;
                     }
                     /* Hide scrollbars */
                     body {
                        overflow: hidden;
                     }`);
                  break;
            }

            function setPlayerFullViewport(exclude_pause) {
               const CLASS_OVER_PAUSED = 'nova-player-fullviewport';
               NOVA.css.push(
                  `${PLAYER_SELECTOR}.playing-mode ${exclude_pause ? '' : `, ${PLAYER_SELECTOR}.paused-mode`}, ${PLAYER_SELECTOR}.${CLASS_OVER_PAUSED} {
                     width: 100vw;
                     height: 100vh;
                     position: fixed;
                     bottom: 0 !important;
                     z-index: ${zIindex};
                     background-color: black;
                  }
                  /* Hide scrollbars */
                  body {
                     overflow: hidden;
                  }`);

               // for fix
               if (user_settings.player_full_viewport_mode_exit) {
                  NOVA.waitElement('video')
                     .then(video => {
                        // fix restore video size
                        video.addEventListener('pause', () => window.dispatchEvent(new Event('resize')));
                        // video.addEventListener('playing', () => window.dispatchEvent(new Event('resize')));
                     });

                  // fix overlapped ".paused-mode" after you scroll the time in the player with the mouse
                  NOVA.waitElement('.ytp-progress-bar')
                     .then(progress_bar => {
                        ['mousedown', 'mouseup'].forEach(evt => {
                           progress_bar.addEventListener(evt, () => {
                              //    // if (movie_player.contains(document.activeElement)) {
                              // if (document.activeElement.matches('.ytp-progress-bar')) {
                              movie_player.classList.add(CLASS_OVER_PAUSED)
                              // }
                           });
                        });
                     });
               }
            }

            // add scroll-down behavior on player control panel
            function addScrollDownBehavior() {
               if (activateScrollElement = document.body.querySelector('.ytp-chrome-controls')) {
                  // const player = document.body.querySelector(PLAYER_SELECTOR);
                  activateScrollElement.addEventListener('wheel', evt => {
                     switch (Math.sign(evt.wheelDelta)) {
                        // case 1: // up
                        //    movie_player.classList.remove(PLAYER_SCROLL_LOCK_CLASS_NAME);
                        //    break;

                        case -1: // down
                           movie_player.classList.add(PLAYER_SCROLL_LOCK_CLASS_NAME);
                           // player.classList.add(PLAYER_SCROLL_LOCK_CLASS_NAME);
                           break;
                     }
                  });
                  // up (on top page)
                  document.addEventListener('scroll', evt => {
                     if (window.scrollY === 0
                        && movie_player.classList.contains(PLAYER_SCROLL_LOCK_CLASS_NAME)
                     ) {
                        movie_player.classList.remove(PLAYER_SCROLL_LOCK_CLASS_NAME);
                     }
                  });
               }
            }
         });

   },
   options: {
      player_full_viewport_mode: {
         _tagName: 'select',
         label: 'Toggle type',
         // 'label:zh': '模式',
         // 'label:ja': 'モード',
         // 'label:ko': '방법',
         // 'label:id': '',
         // 'label:es': 'Modo',
         // 'label:pt': 'Modo',
         // // 'label:fr': 'Mode',
         // 'label:it': '',
         // 'label:tr': 'Mod',
         // 'label:de': 'Modus',
         'label:pl': 'Typ',
         'label:ua': 'Обрати режим',
         options: [
            { label: 'Default', /*value: false,*/ selected: true },
            { label: 'Cinema', value: 'cinema_mode' },
            { label: 'Full-viewport (auto)', value: 'smart' },
            { label: 'Full-viewport', value: 'force' },
            { label: 'Redirect to embedded', value: 'redirect_watch_to_embed' },
         ],
      },
      player_full_viewport_mode_exit: {
         _tagName: 'input',
         // label: 'Exit Fullscreen on Video End',
         label: 'Full-viewport exit if video ends/pause',
         'label:zh': '视频结束/暂停时退出',
         'label:ja': 'ビデオが終了/一時停止したら終了します',
         'label:ko': '동영상이 종료/일시 중지되면 종료',
         'label:id': 'Keluar dari viewport penuh jika video berakhir/jeda',
         'label:es': 'Salir si el video termina/pausa',
         'label:pt': 'Sair se o vídeo terminar/pausar',
         'label:fr': 'Quitter si la vidéo se termine/pause',
         'label:it': 'Uscita dalla visualizzazione completa se il video termina/mette in pausa',
         'label:tr': 'Video biterse/duraklatılırsa çıkın',
         'label:de': 'Beenden, wenn das Video endet/pausiert',
         'label:pl': 'Wyjdź, gdy film się kończy/pauzuje',
         'label:ua': 'Вихід із повного вікна перегляду, якщо відео закінчується/призупиняється',
         type: 'checkbox',
         'data-dependent': { 'player_full_viewport_mode': ['force', 'smart'] },
      },
      player_full_viewport_mode_exclude_shorts: {
         _tagName: 'input',
         label: 'Full-viewport exclude shorts',
         'label:zh': '全视口不包括短裤',
         'label:ja': 'フルビューポートはショートパンツを除外します',
         'label:ko': '전체 뷰포트 제외 반바지',
         'label:id': 'Area pandang penuh tidak termasuk celana pendek',
         'label:es': 'Vista completa excluir pantalones cortos',
         'label:pt': 'Shorts de exclusão da janela de visualização completa',
         'label:fr': 'La fenêtre complète exclut les shorts',
         'label:it': 'La visualizzazione completa esclude i cortometraggi',
         'label:tr': 'Tam görünüm alanı şortları hariç tutar',
         'label:de': 'Vollbildansicht schließt Shorts aus',
         'label:pl': 'Pełny ekran wyklucza krótkie filmy',
         'label:ua': 'Повне вікно перегляду без прев`ю',
         type: 'checkbox',
         // title: '',
         'data-dependent': { 'player_full_viewport_mode': 'smart' },
      },
      cinema_mode_opacity: {
         _tagName: 'input',
         label: 'Opacity',
         'label:zh': '不透明度',
         'label:ja': '不透明度',
         'label:ko': '불투명',
         'label:id': 'Kegelapan',
         'label:es': 'Opacidad',
         'label:pt': 'Opacidade',
         'label:fr': 'Opacité',
         'label:it': 'Opacità',
         'label:tr': 'Opaklık',
         'label:de': 'Opazität',
         'label:pl': 'Przezroczystość',
         'label:ua': 'Прозорість',
         type: 'number',
         title: '0-1',
         placeholder: '0-1',
         step: .05,
         min: 0,
         max: 1,
         value: .75,
         'data-dependent': { 'player_full_viewport_mode': 'cinema_mode' },
      },
   }
});
window.nova_plugins.push({
   id: 'player-buttons-custom',
   title: 'Custom player buttons',
   'title:zh': '自定义按钮',
   'title:ja': 'カスタムボタン',
   'title:ko': '사용자 정의 버튼',
   'title:id': 'Tombol pemutar khusus',
   'title:es': 'Botones personalizados',
   'title:pt': 'Botões personalizados',
   'title:fr': 'Boutons personnalisés',
   'title:it': 'Pulsanti personalizzati del giocatore',
   'title:tr': 'Özel düğmeler',
   'title:de': 'Benutzerdefinierte Schaltflächen',
   'title:pl': 'Własne przyciski odtwarzacza',
   'title:ua': 'Власні кнопки відтворювання',
   run_on_pages: 'watch, embed, -mobile',
   section: 'player',
   // desc: '',
   _runtime: user_settings => {

      const
         SELECTOR_BTN_CLASS_NAME = 'nova-right-custom-button',
         SELECTOR_BTN = '.' + SELECTOR_BTN_CLASS_NAME; // for css

      // NOVA.waitElement('.ytp-left-controls')
      NOVA.waitElement('.ytp-right-controls')
         .then(async container => {
            NOVA.videoElement = await NOVA.waitElement('video'); // wait load video

            // global
            NOVA.css.push(
               `${SELECTOR_BTN} {
                  user-select: none;
                  /*padding: 5px;
                  width: 25px;*/
               }
               ${SELECTOR_BTN}:hover { color: #66afe9 !important; }
               ${SELECTOR_BTN}:active { color: #2196f3 !important; }`);

            // custon title (with animation)
            // NOVA.css.push(
            //    `${SELECTOR_BTN}[title]::before {
            //       content: attr(title);
            //       position: absolute;
            //       top: -3em;
            //       line-height: normal;
            //       background-color: rgba(28,28,28,.9);
            //       border-radius: 2px;
            //       padding: 5px 9px;
            //       color: #fff;
            //       font-weight: bold;
            //       white-space: nowrap;

            //       /*animation*/
            //       --scale: 0;
            //       transform: translateX(-25%) scale(var(--scale));
            //       transition: 50ms transform;
            //       transform-origin: bottom center;
            //    }
            //    ${SELECTOR_BTN}[title]:hover::before {
            //       --scale: 1
            //    }`);
            NOVA.css.push(
               `${SELECTOR_BTN}[title]:hover::before {
                  content: attr(title);
                  position: absolute;
                  top: -3em;
                  transform: translateX(-30%);
                  line-height: normal;
                  background-color: rgba(28,28,28,.9);
                  border-radius: 2px;
                  padding: 5px 9px;
                  color: #fff;
                  font-weight: bold;
                  white-space: nowrap;
               }`);

            // picture-in-picture player
            if (user_settings.player_buttons_custom_items?.includes('picture-in-picture')) {
               const pipBtn = document.createElement('button');

               pipBtn.className = `ytp-button ${SELECTOR_BTN_CLASS_NAME}`;
               pipBtn.title = 'Open in PictureInPicture';
               pipBtn.innerHTML = createSVG();
               // pipBtn.innerHTML =
               //    `<svg viewBox="-8 -6 36 36" height="100%" width="100%">
               //       <g fill="currentColor">
               //          <path d="M2.5,17A1.5,1.5,0,0,1,1,15.5v-9A1.5,1.5,0,0,1,2.5,5h13A1.5,1.5,0,0,1,17,6.5V10h1V6.5A2.5,2.5,0,0,0,15.5,4H2.5A2.5,2.5,0,0,0,0,6.5v9A2.5,2.5,0,0,0,2.5,18H7V17Z M18.5,11h-8A2.5,2.5,0,0,0,8,13.5v5A2.5,2.5,0,0,0,10.5,21h8A2.5,2.5,0,0,0,21,18.5v-5A2.5,2.5,0,0,0,18.5,11Z" />
               //       </g>
               //    </svg>`;
               // `<svg viewBox="-3 -7 30 30" height="100%" width="100%">
               //    <g fill="currentColor">
               //       <path fill-rule="evenodd" d="M0 3.5A1.5 1.5 0 0 1 1.5 2h13A1.5 1.5 0 0 1 16 3.5v9a1.5 1.5 0 0 1-1.5 1.5h-13A1.5 1.5 0 0 1 0 12.5v-9zM1.5 3a.5.5 0 0 0-.5.5v9a.5.5 0 0 0 .5.5h13a.5.5 0 0 0 .5-.5v-9a.5.5 0 0 0-.5-.5h-13z"/>
               //       <path d="M8 8.5a.5.5 0 0 1 .5-.5h5a.5.5 0 0 1 .5.5v3a.5.5 0 0 1-.5.5h-5a.5.5 0 0 1-.5-.5v-3z"/>
               //    </g>
               // </svg>`;
               // `<svg viewBox="0 -5 24 30" height="100%" width="100%">
               //    <g transform="translate(0,2)">
               //       <polygon fill-rule="nonzero" points="1.85008844 1.51464844 18.2421138 1.51464844 18.2421138 7.74121094 19.2421138 7.74121094 19.2421138 0.514648438 0.850088443 0.514648438 0.850088443 11.7244572 9.16539331 11.7758693 9.17157603 10.7758885 1.85008844 10.7306209" />
               //       <rect x="10.5" y="9" width="9.5" height="6" />
               //       <path d="M8.49517931,6.9934339 L4.58268904,3.10539669 L3.87780235,3.81471662 L7.75590296,7.6685791 L5.14025649,7.6685791 L5.14025649,8.6685791 L9.49517931,8.6685791 L9.49517931,4.64446771 L8.49517931,4.64446771 L8.49517931,6.9934339 Z" fill-rule="nonzero" />
               //    </g>
               // </svg>`;
               pipBtn.addEventListener('click', () => document.pictureInPictureElement
                  ? document.exitPictureInPicture() : NOVA.videoElement.requestPictureInPicture()
               );

               container.prepend(pipBtn);

               // update icon
               NOVA.videoElement?.addEventListener('enterpictureinpicture', () => pipBtn.innerHTML = createSVG(2));
               NOVA.videoElement?.addEventListener('leavepictureinpicture', () => pipBtn.innerHTML = createSVG());

               function createSVG(alt) {
                  const svg = document.createElement('svg');
                  svg.setAttribute('width', '100%');
                  svg.setAttribute('height', '100%');
                  svg.setAttribute('viewBox', '-8 -6 36 36');
                  const path = document.createElement("path");
                  path.setAttribute('fill', '#fff');
                  path.setAttribute('d', alt
                     ? 'M18.5,11H18v1h.5A1.5,1.5,0,0,1,20,13.5v5A1.5,1.5,0,0,1,18.5,20h-8A1.5,1.5,0,0,1,9,18.5V18H8v.5A2.5,2.5,0,0,0,10.5,21h8A2.5,2.5,0,0,0,21,18.5v-5A2.5,2.5,0,0,0,18.5,11Z M14.5,4H2.5A2.5,2.5,0,0,0,0,6.5v8A2.5,2.5,0,0,0,2.5,17h12A2.5,2.5,0,0,0,17,14.5v-8A2.5,2.5,0,0,0,14.5,4Z'
                     : 'M2.5,17A1.5,1.5,0,0,1,1,15.5v-9A1.5,1.5,0,0,1,2.5,5h13A1.5,1.5,0,0,1,17,6.5V10h1V6.5A2.5,2.5,0,0,0,15.5,4H2.5A2.5,2.5,0,0,0,0,6.5v9A2.5,2.5,0,0,0,2.5,18H7V17Z M18.5,11h-8A2.5,2.5,0,0,0,8,13.5v5A2.5,2.5,0,0,0,10.5,21h8A2.5,2.5,0,0,0,21,18.5v-5A2.5,2.5,0,0,0,18.5,11Z');
                  svg.append(path);
                  return svg.outerHTML;
               }
            }

            // Pop-up player
            if (user_settings.player_buttons_custom_items?.indexOf('popup') !== -1 && !NOVA.queryURL.has('popup')) {
               // alt - https://greasyfork.org/en/scripts/401907-youtube-popout-button-mashup
               const popupBtn = document.createElement('button');
               popupBtn.className = `ytp-button ${SELECTOR_BTN_CLASS_NAME}`;
               popupBtn.title = 'Open in popup';
               popupBtn.innerHTML =
                  // `<svg viewBox="-8 -8 36 36" height="100%" width="100%">
                  //    <g fill="currentColor">
                  //       <path d="M18 2H6v4H2v12h12v-4h4V2z M12 16H4V8h2v6h6V16z M16 12h-2h-2H8V8V6V4h8V12z" />
                  //    </g>
                  // </svg>`;
                  `<svg viewBox="0 -1 38 38" height="100%" width="100%">
                     <g fill="currentColor">
                        <path d="M 27.020989,25.020001 H 9.0209895 v -14.05 L 20.278056,10.969089 20.27853,8.9999999 H 8.9544297 c -1.0730594,0 -1.9334402,0.9 -1.9334402,2.0000001 v 14 c 0,1.1 0.8603808,2 1.9334402,2 H 27.045569 c 1.063393,0 1.97421,-0.885891 1.968683,-1.985877 l 0.0018,-7.014124 h -1.991386 z m -4.80902,-16.0200011 -0.01053,1.9774681 3.525926,-0.0018 -9.547729,9.854341 1.363076,1.41 9.481183,-9.799226 v 3.59 l 1.993516,-0.0095 0.0039,-7.0250141 z" />
                     </g>
                  </svg>`;
               popupBtn.addEventListener('click', () => {
                  const
                     // width = window.innerWidth / 2,
                     width = screen.width / (+user_settings.player_buttons_custom_popup_width || 4),
                     // aspectRatio = NOVA.videoElement.videoWidth / NOVA.videoElement.videoHeight,
                     // height = Math.round(width / aspectRatio);
                     height = Math.round(width / (16 / 9));

                  url = new URL(document.querySelector('link[itemprop="embedUrl"][href]')?.href || ('/embed/' + movie_player.getVideoData().video_id));
                  // list param ex.
                  // https://www.youtube.com/embed/PBlOi5OVcKs?start=0&amp;playsinline=1&amp;controls=0&amp;fs=20&amp;disablekb=1&amp;rel=0&amp;origin=https%3A%2F%2Ftyping-tube.net&amp;enablejsapi=1&amp;widgetid=1

                  if (currentTime = ~~NOVA.videoElement?.currentTime) url.searchParams.set('start', currentTime);
                  url.searchParams.set('autoplay', 1);
                  url.searchParams.set('popup', true); // deactivate popup-button for used window

                  openPopup({ 'url': url.href, 'title': document.title, 'width': width, 'height': height });
               });

               container.prepend(popupBtn);

               function openPopup({ url, title, width, height }) {
                  // center screen
                  const left = (screen.width / 2) - (width / 2);
                  const top = (screen.height / 2) - (height / 2);
                  // bottom right corner
                  // left = window.innerWidth;
                  // top = window.innerHeight;
                  return window.open(url, title, `popup=1,toolbar=no,location=no,directories=no,status=no,menubar=no, scrollbars=no,resizable=yes,copyhistory=no,width=${width},height=${height},top=${top},left=${left}`);
               }
            }

            if (user_settings.player_buttons_custom_items?.includes('screenshot')) {
               const
                  // bar
                  SELECTOR_SCREENSHOT_ID = 'nova-screenshot-result',
                  SELECTOR_SCREENSHOT = '#' + SELECTOR_SCREENSHOT_ID; // for css

               NOVA.css.push(
                  SELECTOR_SCREENSHOT + ` {
                     --width: 400px;
                     --height: 400px;

                     position: fixed;
                     top: 0;
                     right: 0;
                     overflow: hidden;
                     margin: 36px 30px; /* <-- possibility out of date */
                     box-shadow: 0 0 15px #000;
                     max-width: var(--width);
                     max-height: var(--height);
                  }
                  /* for embed */
                  /*html[data-cast-api-enabled] ${SELECTOR_SCREENSHOT} {
                     margin-right: 0;
                  }*/

                  /*${SELECTOR_SCREENSHOT}:hover {
                     outline: 2px dashed #f69c55;
                  }*/

                  ${SELECTOR_SCREENSHOT} canvas {
                     max-width: var(--width);
                     max-height: var(--height);
                     /* object-fit: contain; */
                  }

                  ${SELECTOR_SCREENSHOT} .close-btn {
                     position: absolute;
                     bottom: 0;
                     right: 0;
                     background-color: rgba(0, 0, 0, .5);
                     color: #FFF;
                     cursor: pointer;
                     font-size: 12px;
                     display: grid;
                     height: 100%;
                     width: 25%;
                  }
                  ${SELECTOR_SCREENSHOT} .close-btn:hover { background-color: rgba(0, 0, 0, .65); }
                  ${SELECTOR_SCREENSHOT} .close-btn > * { margin: auto; }`);

               const screenshotBtn = document.createElement('button');
               screenshotBtn.className = `ytp-button ${SELECTOR_BTN_CLASS_NAME}`;
               screenshotBtn.title = 'Take screenshot';
               // Doesn't work defoult title
               // screenshotBtn.setAttribute('aria-pressed', 'false');
               // screenshotBtn.setAttribute('aria-label','test');
               screenshotBtn.innerHTML =
                  `<svg viewBox="0 -166 512 860" height="100%" width="100%">
                     <g fill="currentColor">
                        <circle cx="255.811" cy="285.309" r="75.217" />
                        <path d="M477,137H352.718L349,108c0-16.568-13.432-30-30-30H191c-16.568,0-30,13.432-30,30l-3.718,29H34 c-11.046,0-20,8.454-20,19.5v258c0,11.046,8.954,20.5,20,20.5h443c11.046,0,20-9.454,20-20.5v-258C497,145.454,488.046,137,477,137 z M255.595,408.562c-67.928,0-122.994-55.066-122.994-122.993c0-67.928,55.066-122.994,122.994-122.994 c67.928,0,122.994,55.066,122.994,122.994C378.589,353.495,323.523,408.562,255.595,408.562z M474,190H369v-31h105V190z" />
                     </g>
                  </svg>`;

               // simplified implementation. Can't open images in a new tab
               // screenshotBtn.addEventListener('click', getScreenshot);
               // function getScreenshot() {
               //    var width, height, aspectRatio, container, canvas, close;
               //    container = document.getElementById(SELECTOR_SCREENSHOT_ID) || document.createElement('div');
               //    canvas = container.querySelector('canvas') || document.createElement('canvas');
               //    canvas.width = NOVA.videoElement.videoWidth;
               //    canvas.height = NOVA.videoElement.videoHeight
               //    canvas.getContext('2d').drawImage(NOVA.videoElement, 0, 0, canvas.width, canvas.height);
               //    // create
               //    if (!container.id) {
               //       canvas.addEventListener('click', ({ target }) => {
               //          downloadCanvasAsImage(target);
               //          container.remove();
               //       });
               //       container.id = SELECTOR_SCREENSHOT_ID;
               //       container.append(canvas);
               //       const close = document.createElement('div');
               //       close.className = 'close-btn';
               //       close.innerHTML = '<span>CLOSE</span>';
               //       close.addEventListener('click', evt => container.remove());
               //       container.append(close);
               //       document.body.append(container);
               //    }
               // }

               screenshotBtn.addEventListener('click', () => {
                  const
                     container = document.getElementById(SELECTOR_SCREENSHOT_ID) || document.createElement('a'),
                     canvas = container.querySelector('canvas') || document.createElement('canvas');

                  canvas.width = NOVA.videoElement.videoWidth;
                  canvas.height = NOVA.videoElement.videoHeight
                  canvas.getContext('2d').drawImage(NOVA.videoElement, 0, 0, canvas.width, canvas.height);
                  try {
                     // fix Uncaught DOMException: Failed to execute 'toDataURL' on 'HTMLCanvasElement': Tainted canvases may not be exported.
                     // ex: https://www.youtube.com/watch?v=FZovbrEP53o

                     canvas.toBlob(blob => container.href = URL.createObjectURL(blob));
                     // container.href = canvas.toDataURL(); // err in Brave browser (https://github.com/raingart/Nova-YouTube-extension/issues/8)
                  } catch (error) {
                     // alert("The video is protected. Can't take screenshot due to security policy");
                     // container.remove();
                  }
                  // create
                  if (!container.id) {
                     container.id = SELECTOR_SCREENSHOT_ID;
                     container.target = '_blank'; // useful link
                     container.title = 'Click to save';
                     if (headerContainer = document.getElementById('masthead-container')) { // skip embed
                        container.style.marginTop = (headerContainer?.offsetHeight || 0) + 'px'; // fix header indent
                        container.style.zIndex = +getComputedStyle(headerContainer)['z-index'] + 1; // fix header overlapping
                     }
                     canvas.addEventListener('click', evt => {
                        evt.preventDefault();
                        downloadCanvasAsImage(evt.target);
                        container.remove();
                     });
                     container.append(canvas);
                     const close = document.createElement('a');
                     close.className = 'close-btn'
                     // close.textContent = 'CLOSE';
                     close.innerHTML = '<span>CLOSE</span>';
                     close.addEventListener('click', evt => {
                        evt.preventDefault();
                        container.remove();
                     });
                     container.append(close);
                     document.body.append(container);
                  }
               });

               function downloadCanvasAsImage(canvas) {
                  const
                     downloadLink = document.createElement('a'),
                     downloadFileName =
                        [
                           movie_player.getVideoData().title
                              .replace(/[\\/:*?"<>|]+/g, '')
                              .replace(/\s+/g, ' ').trim(),
                           `[${NOVA.timeFormatTo.HMS.abbr(NOVA.videoElement.currentTime)}]`,
                        ]
                           .join(' ');

                  downloadLink.href = canvas.toBlob(blob => URL.createObjectURL(blob));
                  // downloadLink.href = canvas.toDataURL('image/png').replace('image/png', 'image/octet-stream');
                  // container.href = canvas.toDataURL(); // err in Brave browser (https://github.com/raingart/Nova-YouTube-extension/issues/8)
                  downloadLink.download = downloadFileName + '.png';
                  downloadLink.click();
               }
               container.prepend(screenshotBtn);
            }

            if (user_settings.player_buttons_custom_items?.includes('thumbnail')) {
               // alt - https://greasyfork.org/en/scripts/19151-get-youtube-thumbnail
               const thumbBtn = document.createElement('button');
               thumbBtn.className = `ytp-button ${SELECTOR_BTN_CLASS_NAME}`;
               // thumbBtn.setAttribute('data-tooltip', 'View Thumbnail');
               thumbBtn.title = 'View Thumbnail';
               thumbBtn.innerHTML =
                  `<svg viewBox="0 -10 21 40" height="100%" width="100%">
                     <g fill="currentColor">
                        <circle cx='8' cy='7.2' r='2'/>
                        <path d='M0 2v16h20V2H0z M18 16H2V4h16V16z'/>
                        <polygon points='17 10.9 14 7.9 9 12.9 6 9.9 3 12.9 3 15 17 15' />
                     </g>
                  </svg>`;

               // getMaxThumbnailAvailable
               thumbBtn.addEventListener('click', async () => {
                  // Strategy 1 (API). skip embed
                  if (NOVA.currentPage == 'watch'
                     && (imgUrl = document.body.querySelector('ytd-watch, ytd-watch-flexy')
                        ?.playerData?.videoDetails?.thumbnail.thumbnails.pop().url)
                  ) return window.open(imgUrl);

                  // Strategy 2 (fetch)
                  const
                     videoId = movie_player.getVideoData().video_id || NOVA.queryURL.get('v'),
                     thumbSizeTemplate = [
                        // Warn! "maxresdefault" is not available everywhere. etc:
                        // https://i.ytimg.com/vi_webp/<VIDEO_ID>/maxresdefault.webp
                        // https://i.ytimg.com/vi/<VIDEO_ID>/maxresdefault.jpg
                        // https://i.ytimg.com/vi/<VIDEO_ID>/hqdefault.jpg
                        'maxres', // width: 1280
                        'sd', // width: 640
                        'hq', // width: 480
                        'mq', // width: 320
                        '' // width: 120
                     ];

                  document.body.style.cursor = 'wait';
                  for (const resPrefix of thumbSizeTemplate) {
                     const
                        imgUrl = `https://i.ytimg.com/vi/${videoId}/${resPrefix}default.jpg`,
                        response = await fetch(imgUrl);

                     if (response.status === 200) {
                        document.body.style.cursor = 'default';
                        window.open(imgUrl);
                        break;
                     }
                  }
               });
               container.prepend(thumbBtn);
            }

            if (user_settings.player_buttons_custom_items?.includes('rotate')) {
               // alt - https://github.com/zhzLuke96/ytp-rotate
               const rotateBtn = document.createElement('button');

               // if (NOVA.videoElement?.videoWidth < NOVA.videoElement?.videoHeight) {
               rotateBtn.className = `ytp-button ${SELECTOR_BTN_CLASS_NAME}`;
               rotateBtn.title = 'Rotate video';
               Object.assign(rotateBtn.style, {
                  padding: '0 1.1em',
               });
               rotateBtn.innerHTML =
                  `<svg viewBox="0 0 1536 1536" height="100%" width="100%">
                     <g fill="currentColor">
                        <path
                           d="M1536 128v448q0 26-19 45t-45 19h-448q-42 0-59-40-17-39 14-69l138-138Q969 256 768 256q-104 0-198.5 40.5T406 406 296.5 569.5 256 768t40.5 198.5T406 1130t163.5 109.5T768 1280q119 0 225-52t179-147q7-10 23-12 14 0 25 9l137 138q9 8 9.5 20.5t-7.5 22.5q-109 132-264 204.5T768 1536q-156 0-298-61t-245-164-164-245T0 768t61-298 164-245T470 61 768 0q147 0 284.5 55.5T1297 212l130-129q29-31 70-14 39 17 39 59z"/>
                        </path>
                     </g>
                  </svg>`;
               rotateBtn.addEventListener('click', () => {
                  let angle = parseInt(NOVA.videoElement.style.transform.replace(/^\D+/g, '')) || 0;
                  // fix ratio scale. Before angle calc
                  const scale = (angle === 0 || angle === 180) ? movie_player.clientHeight / NOVA.videoElement.clientWidth : 1;
                  angle += 90;
                  NOVA.videoElement.style.transform = (angle === 360) ? '' : `rotate(${angle}deg) scale(${scale})`;
                  console.debug('rotate', angle, scale, NOVA.videoElement.style.transform);
               });
               container.prepend(rotateBtn);
               // }
            }

            if (user_settings.player_buttons_custom_items?.includes('watch-later')) {

               NOVA.waitElement('.ytp-watch-later-button')
                  .then(watchLaterDefault => {

                     NOVA.css.push(
                        `.${SELECTOR_BTN_CLASS_NAME} .ytp-spinner-container {
                           position: relative;
                           top: 0;
                           left: 0;
                           scale: .5;
                           margin: 0;
                        }
                        .${SELECTOR_BTN_CLASS_NAME}.watch-later-btn svg {
                           scale: .85;
                        }`);

                     const watchLaterBtn = document.createElement('button');

                     watchLaterBtn.className = `ytp-button ${SELECTOR_BTN_CLASS_NAME} watch-later-btn`;
                     watchLaterBtn.title = 'Watch later';
                     renderIcon();
                     watchLaterBtn.addEventListener('click', () => {
                        watchLaterDefault.click();
                        renderIcon(); // render loading (.ytp-spinner)
                        const waitStatus = setInterval(() => {
                           // console.debug('wait svg. current show div ".ytp-spinner"');
                           if (watchLaterDefault.querySelector('svg')) {
                              // console.debug('svg ready');
                              clearInterval(waitStatus);
                              renderIcon();
                           }
                        }, 100); // check evry 100ms
                        // setTimeout(renderIcon, 1000); // 1 sec
                     });
                     //
                     // container.append(watchLaterBtn);
                     [...document.getElementsByClassName(SELECTOR_BTN_CLASS_NAME)].pop() // last custom btn
                        .after(watchLaterBtn);

                     function renderIcon() {
                        // <div class="ytp-spinner-container">
                        //    <div class="ytp-spinner-rotator">
                        //       <div class="ytp-spinner-left">
                        //          <div class="ytp-spinner-circle"></div>
                        //       </div>
                        //       <div class="ytp-spinner-right">
                        //          <div class="ytp-spinner-circle"></div>
                        //       </div>
                        //    </div>
                        // </div>

                        // return alt
                        //    ? `<svg height="100%" version="1.1" viewBox="0 0 36 36" width="100%">
                        //          <use class="ytp-svg-shadow" xlink:href="#ytp-id-25"></use>
                        //          <path class="ytp-svg-fill"
                        //             d="M18,8 C12.47,8 8,12.47 8,18 C8,23.52 12.47,28 18,28 C23.52,28 28,23.52 28,18 C28,12.47 23.52,8 18,8 L18,8 Z M16,19.02 L16,12.00 L18,12.00 L18,17.86 L23.10,20.81 L22.10,22.54 L16,19.02 Z"
                        //             id="ytp-id-25"></path>
                        //       </svg>`
                        //    : watchLater.querySelector('.ytp-watch-later-icon').innerHTML;
                        watchLaterBtn.innerHTML = watchLaterDefault.querySelector('.ytp-watch-later-icon')?.innerHTML;
                     }
                  });
            }

            if (user_settings.player_buttons_custom_items?.includes('quick-quality')) {
               const
                  // conteiner <a>
                  SELECTOR_QUALITY_CLASS_NAME = 'nova-quick-quality',
                  SELECTOR_QUALITY = '.' + SELECTOR_QUALITY_CLASS_NAME,
                  qualityConteinerBtn = document.createElement('a'),
                  // list <ul>
                  SELECTOR_QUALITY_LIST_ID = SELECTOR_QUALITY_CLASS_NAME + '-list',
                  SELECTOR_QUALITY_LIST = '#' + SELECTOR_QUALITY_LIST_ID,
                  listQuality = document.createElement('ul'),
                  // btn <span>
                  SELECTOR_QUALITY_BTN_ID = SELECTOR_QUALITY_CLASS_NAME + '-btn',
                  qualityBtn = document.createElement('span'),

                  qualityFormatList = {
                     highres: { label: '4320p', badge: '8K' },
                     hd2880: { label: '2880p', badge: '5K' },
                     hd2160: { label: '2160p', badge: '4K' },
                     hd1440: { label: '1440p', badge: 'QHD' },
                     hd1080: { label: '1080p', badge: 'FHD' },
                     // hd720: { label: '720p', badge: 'HD' },
                     hd720: { label: '720p', badge: 'ᴴᴰ' },
                     large: { label: '480p' },
                     medium: { label: '360p' },
                     small: { label: '240p' },
                     tiny: { label: '144p' },
                     auto: { label: 'auto' },
                  };

               NOVA.css.push(
                  SELECTOR_QUALITY + ` {
                     overflow: visible !important;
                     position: relative;
                     text-align: center !important;
                     vertical-align: top;
                     font-weight: bold;
                  }

                  ${SELECTOR_QUALITY_LIST} {
                     position: absolute;
                     bottom: 4em;
                     left: -2em;
                     list-style: none;
                     padding-bottom: .5em;
                     z-index: ${+getComputedStyle(document.body.querySelector('.ytp-progress-bar'))['z-index'] + 1};
                  }

                  /* for embed */
                  html[data-cast-api-enabled] ${SELECTOR_QUALITY_LIST} {
                     margin: 0;
                     padding: 0;
                     bottom: 3.3em;
                     /* --yt-spec-brand-button-background: #c00; */
                  }

                  ${SELECTOR_QUALITY}:not(:hover) ${SELECTOR_QUALITY_LIST} {
                     display: none;
                  }

                  ${SELECTOR_QUALITY_LIST} li {
                     cursor: pointer;
                     line-height: 1.4;
                     background: rgba(28, 28, 28, 0.9);
                     margin: .3em 0;
                     padding: .5em 3em;
                     border-radius: .3em;
                     color: #fff;
                  }

                  ${SELECTOR_QUALITY_LIST} li .quality-menu-item-label-badge {
                     position: absolute;
                     right: 1em;
                     width: 1.7em;
                  }

                  ${SELECTOR_QUALITY_LIST} li.active { background: #720000; }
                  ${SELECTOR_QUALITY_LIST} li:hover:not(.active) { background: #c00; }`);
               // ${SELECTOR_QUALITY_LIST} li:hover:not(.active) { background-color: var(--yt-spec-brand-button-background); }`);
               // conteiner <a>
               qualityConteinerBtn.className = `ytp-button ${SELECTOR_BTN_CLASS_NAME} ${SELECTOR_QUALITY_CLASS_NAME}`;
               // qualityConteinerBtn.title = 'Change quality';
               // btn <span>
               qualityBtn.id = SELECTOR_QUALITY_BTN_ID;
               qualityBtn.textContent = qualityFormatList[movie_player.getPlaybackQuality()]?.label || '[out of range]';
               // list <ul>
               listQuality.id = SELECTOR_QUALITY_LIST_ID;

               // show current quality
               movie_player.addEventListener('onPlaybackQualityChange', quality => {
                  document.getElementById(SELECTOR_QUALITY_BTN_ID)
                     .textContent = qualityFormatList[quality]?.label || '[out of range]';
                  // .textContent = movie_player.getVideoData().video_quality
                  // dirty hack (clear list) replaces this prototype code
                  // document.getElementById(SELECTOR_QUALITY_LIST_ID li..) li.className = 'active';
               });

               qualityConteinerBtn.prepend(qualityBtn);
               qualityConteinerBtn.append(listQuality);

               container.prepend(qualityConteinerBtn);

               fillQualityMenu(); // init

               NOVA.videoElement?.addEventListener('canplay', fillQualityMenu); // update

               function fillQualityMenu() {
                  if (qualityList = document.getElementById(SELECTOR_QUALITY_LIST_ID)) {
                     qualityList.innerHTML = '';

                     movie_player.getAvailableQualityLevels()
                        .forEach(quality => {
                           const qualityItem = document.createElement('li');
                           // if (movie_player.getVideoData().video_quality == quality) qualityItem.className = 'active';
                           if (movie_player.getPlaybackQuality() == quality) qualityItem.className = 'active';
                           // qualityList.innerHTML =
                           //    `<span class="quality-menu-item-text">1080p</span>
                           //    <span class="quality-menu-item-label-badge">HD</span>`;
                           if (qualityData = qualityFormatList[quality]) {
                              qualityItem.textContent = qualityData.label;
                              if (badge = qualityData.badge) {
                                 qualityItem.insertAdjacentHTML('beforeend',
                                    `<span class="quality-menu-item-label-badge">${badge}</span>`);
                              }
                              qualityItem.addEventListener('click', () => {
                                 // console.debug('setPlaybackQuality', quality);
                                 movie_player.setPlaybackQualityRange(quality, quality);
                                 // movie_player.setPlaybackQuality(quality); // Doesn't work
                                 qualityList.innerHTML = ''; // dirty hack (clear list)
                              })
                              qualityList.append(qualityItem);
                           }
                        });
                  }
               }
            }

            if (user_settings.player_buttons_custom_items?.includes('toggle-speed')) {
               const
                  speedBtn = document.createElement('a'),
                  hotkey = user_settings.player_buttons_custom_hotkey_toggle_speed || 'a',
                  defaultRateText = '1x';
               // `<svg viewBox="0 0 36 36" height="100%" width="100%">
               //    <g fill="currentColor">
               //       <path d="m 27.526463,13.161756 -1.400912,2.107062 a 9.1116182,9.1116182 0 0 1 -0.250569,8.633258 H 10.089103 A 9.1116182,9.1116182 0 0 1 22.059491,11.202758h24.166553,9.8018471 A 11.389523,11.389523 0 0 0 8.1301049,25.041029 2.2779046,2.2779046 0 0 0 10.089103,26.179981 H 25.863592 A 2.2779046,2.2779046 0 0 0 27.845369,25.041029 11.389523,11.389523 0 0 0 27.537852,13.150367 Zs16.376119,20.95219 a 2.2779046,2.2779046 0 0 0 3.223235,0h6.446471,-9.669705 -9.669706,6.44647 a 2.2779046,2.2779046 0 0 0 0,3.223235 z" />
               //    </g>
               // </svg>`;

               let rateOrig = {};

               speedBtn.className = `ytp-button ${SELECTOR_BTN_CLASS_NAME}`;
               speedBtn.style.textAlign = 'center';
               speedBtn.style.fontWeight = 'bold';
               speedBtn.innerHTML = defaultRateText;
               speedBtn.title = `Toggle speed to ${defaultRateText} (${hotkey})`;
               // hotkey
               document.addEventListener('keyup', evt => {
                  if (['input', 'textarea'].includes(evt.target.localName) || evt.target.isContentEditable) return;
                  if (evt.key === hotkey) {
                     switchRate();
                  }
               })
               speedBtn.addEventListener('click', switchRate);

               function switchRate() {
                  // restore orig
                  if (Object.keys(rateOrig).length) {
                     playerRate.set(rateOrig);
                     rateOrig = {};
                     speedBtn.innerHTML = defaultRateText;

                  } else { // return default
                     rateOrig = (movie_player && NOVA.videoElement.playbackRate % .25) === 0
                        ? { 'default': movie_player.getPlaybackRate() }
                        : { 'html5': NOVA.videoElement.playbackRate };

                     let resetRate = Object.assign({}, rateOrig); // clone obj
                     resetRate[Object.keys(resetRate)[0]] = 1; // first property of object
                     playerRate.set(resetRate);

                     speedBtn.textContent = rateOrig[Object.keys(rateOrig)[0]] + 'x';
                  }
                  speedBtn.title = `Switch to ${speedBtn.textContent} (${hotkey})`;
                  // console.debug('rateOrig', rateOrig);
               }

               const playerRate = {
                  set(obj) {
                     if (obj.hasOwnProperty('html5') || !movie_player) {
                        NOVA.videoElement.playbackRate = obj.html5;

                     } else {
                        movie_player.setPlaybackRate(obj.default);
                     }
                     // this.saveInSession(obj.html5 || obj.default);
                  },

                  // saveInSession(level = required()) {
                  //    try {
                  //       sessionStorage['yt-player-playback-rate'] = JSON.stringify({
                  //          creation: Date.now(), data: level.toString(),
                  //       })
                  //       // console.log('playbackRate save in session:', ...arguments);

                  //    } catch (err) {
                  //       console.info(`${err.name}: save "rate" in sessionStorage failed. It seems that "Block third-party cookies" is enabled`, err.message);
                  //    }
                  // },
               };

               container.prepend(speedBtn);

               visibilitySwitch(); // init

               NOVA.videoElement?.addEventListener('ratechange', visibilitySwitch); // update #1
               // reset speedBtn state
               NOVA.videoElement?.addEventListener('loadeddata', () => { // update #2
                  rateOrig = {};
                  speedBtn.textContent = defaultRateText;
                  visibilitySwitch();
               });

               function visibilitySwitch() {
                  if (!Object.keys(rateOrig).length) {
                     // speedBtn.style.visibility = /*movie_player.getPlaybackRate() ===*/ NOVA.videoElement.playbackRate === 1 ? 'hidden' : 'visible';
                     speedBtn.style.display = /*movie_player.getPlaybackRate() ===*/ NOVA.videoElement?.playbackRate === 1 ? 'none' : '';
                  }
               }
            }
         });

   },
   options: {
      player_buttons_custom_items: {
         _tagName: 'select',
         label: 'Buttons',
         'label:zh': '纽扣',
         'label:ja': 'ボタン',
         'label:ko': '버튼',
         'label:id': 'Tombol',
         'label:es': 'Botones',
         'label:pt': 'Botões',
         'label:fr': 'Boutons',
         'label:it': 'Bottoni',
         'label:tr': 'Düğmeler',
         'label:de': 'Tasten',
         'label:pl': 'Przyciski',
         'label:ua': 'Кнопки',
         title: '[Ctrl+Click] to select several',
         'title:zh': '[Ctrl+Click] 选择多个',
         'title:ja': '「Ctrl+Click」して、いくつかを選択します',
         'title:ko': '[Ctrl+Click] 여러 선택',
         'title:id': '[Ctrl+Klik] untuk memilih beberapa',
         'title:es': '[Ctrl+Click] para seleccionar varias',
         'title:pt': '[Ctrl+Click] para selecionar vários',
         'title:fr': '[Ctrl+Click] pour sélectionner plusieurs',
         'title:it': '[Ctrl+Clic] per selezionarne diversi',
         'title:tr': 'Birkaç tane seçmek için [Ctrl+Tıkla]',
         'title:de': '[Ctrl+Click] um mehrere auszuwählen',
         'title:pl': 'Ctrl+kliknięcie, aby zaznaczyć kilka',
         'title:ua': '[Ctrl+Click] щоб обрати декілька',
         multiple: null, // dont use - selected: true
         required: true, // dont use - selected: true
         size: 4, // = options.length
         options: [
            {
               value: 'quick-quality',
               label: 'quick quality',
               'label:zh': '质量',
               'label:ja': '品質',
               'label:ko': '품질',
               // 'label:id': '',
               'label:es': 'calidad',
               'label:pt': 'qualidade',
               'label:fr': 'qualité',
               // 'label:it': '',
               'label:tr': 'hızlı kalite',
               'label:de': 'qualität',
               'label:pl': 'jakość',
               'label:ua': 'Якість',
            },
            {
               value: 'toggle-speed',
               label: 'toggle speed',
               'label:zh': '切换速度',
               'label:ja': 'トグル速度',
               'label:ko': '토글 속도',
               // 'label:id': '',
               'label:es': 'alternar velocidad',
               'label:pt': 'velocidade de alternância',
               'label:fr': 'basculer la vitesse',
               // 'label:it': '',
               'label:tr': 'geçiş hızı',
               'label:de': 'geschwindigkeit umschalten',
               'label:pl': 'szybkość',
               'label:ua': 'Швидкість',
            },
            {
               value: 'screenshot',
               label: 'screenshot',
               'label:zh': '截屏',
               'label:ja': 'スクリーンショット',
               'label:ko': '스크린샷',
               // 'label:id': '',
               'label:es': 'captura de pantalla',
               'label:pt': 'captura de tela',
               'label:fr': "capture d'écran",
               // 'label:it': '',
               'label:tr': 'ekran görüntüsü',
               'label:de': 'bildschirmfoto',
               // 'label:pl': 'screenshot'
               'label:ua': 'Фото екрану',
            },
            {
               value: 'picture-in-picture',
               label: 'picture-in-picture',
               // 'label:zh': '',
               // 'label:ja': '',
               // 'label:ko': '',
               // 'label:id': '',
               // 'label:es': '',
               // 'label:pt': '',
               // 'label:fr': '',
               // 'label:it': '',
               // 'label:tr': '',
               // 'label:de': ''
               'label:pl': 'obraz w obrazie',
               'label:ua': 'Картинка в картинці',
            },
            {
               value: 'popup',
               label: 'popup',
               'label:zh': '弹出式播放器',
               'label:ja': 'ポップアッププレーヤー',
               'label:ko': '썸네일',
               // 'label:id': '',
               // 'label:es': 'jugadora emergente',
               'label:pt': 'jogador pop-up',
               'label:fr': 'lecteur contextuel',
               // 'label:it': '',
               'label:tr': 'pop-up oynatıcı',
               // 'label:de': ''
               'label:pl': 'w okienku',
               'label:ua': 'Спливаюче повідомлення',
            },
            {
               value: 'rotate',
               label: 'rotate',
               'label:zh': '旋转',
               'label:ja': '回転する',
               'label:ko': '회전',
               // 'label:id': '',
               'label:es': 'girar',
               'label:pt': 'girar',
               'label:fr': 'tourner',
               // 'label:it': '',
               'label:tr': 'döndürmek',
               'label:de': 'drehen',
               'label:pl': 'obróć',
               'label:ua': 'Повернути',
            },
            {
               value: 'watch-later',
               label: 'watch later',
               // 'label:zh': '',
               // 'label:ja': '',
               // 'label:ko': '',
               // 'label:id': '',
               // 'label:es': '',
               // 'label:pt': '',
               // 'label:fr': '',
               // 'label:it': '',
               // 'label:tr': '',
               // 'label:de': '',
               // 'label:pl': '',
               'label:ua': 'Переглянути пізніше',
            },
            {
               value: 'thumbnail',
               label: 'thumbnail',
               'label:zh': '缩略图',
               'label:ja': 'サムネイル',
               'label:ko': '썸네일',
               // 'label:id': '',
               'label:es': 'miniatura',
               'label:pt': 'captura de tela',
               'label:fr': 'la vignette',
               // 'label:it': '',
               'label:tr': 'küçük resim',
               'label:de': 'bildschirmfoto',
               'label:pl': 'miniaturka',
               'label:ua': 'Мініатюра',
            },
         ],
      },
      player_buttons_custom_popup_width: {
         _tagName: 'input',
         label: 'Player window size aspect ratio',
         'label:zh': '播放器窗口大小纵横比',
         'label:ja': 'プレーヤーのウィンドウサイズのアスペクト比',
         'label:ko': '플레이어 창 크기 종횡비',
         'label:id': 'Rasio aspek ukuran jendela pemutar',
         'label:es': 'Relación de aspecto del tamaño de la ventana del reproductor',
         'label:pt': 'Proporção do tamanho da janela do jogador',
         'label:fr': "Rapport d'aspect de la taille de la fenêtre du lecteur",
         'label:it': 'Proporzioni della dimensione della finestra del lettore',
         'label:tr': 'Oyuncu penceresi boyutu en boy oranı',
         'label:de': 'Seitenverhältnis der Player-Fenstergröße',
         'label:pl': 'Rozmiar okna odtwarzacza',
         'label:ua': 'Співвідношення розміру вікна відтворювача',
         type: 'number',
         title: 'less value - larger size',
         'title:zh': '较小的值 - 较大的尺寸',
         'title:ja': '小さい値-大きいサイズ',
         'title:ko': '더 작은 값 - 더 큰 크기',
         'title:id': 'Nilai lebih kecil - ukuran lebih besar',
         'title:es': 'Valor más pequeño - tamaño más grande',
         'title:pt': 'Valor menor - tamanho maior',
         'title:fr': 'Plus petite valeur - plus grande taille',
         'title:it': 'meno valore - dimensioni maggiori',
         'title:tr': 'Daha az değer - daha büyük boyut',
         'title:de': 'Kleiner Wert - größere Größe',
         'title:pl': 'mniejsza wartość - większy rozmiar',
         'title:ua': 'Менше значення - більший розмір',
         // title: '',
         placeholder: '1.5-4',
         step: 0.1,
         min: 1.5,
         max: 4,
         value: 2.5,
         'data-dependent': { 'player_buttons_custom_items': ['popup'] },
      },
      player_buttons_custom_hotkey_toggle_speed: {
         _tagName: 'select',
         label: 'Hotkey toggle speed',
         'label:zh': '热键切换速度',
         'label:ja': '速度を切り替えるためのホットボタン',
         'label:ko': '단축키 토글 속도',
         'label:id': 'Kecepatan beralih tombol pintas',
         'label:es': 'Velocidad de cambio de teclas de acceso rápido',
         'label:pt': 'Velocidade de alternância da tecla de atalho',
         'label:fr': 'Vitesse de basculement des raccourcis clavier',
         'label:it': 'Tasto di scelta rapida per attivare/disattivare la velocità',
         'label:tr': 'Kısayol geçiş hızı',
         'label:de': 'Hotkey-Umschaltgeschwindigkeit',
         'label:pl': 'Skrót przełączania prędkości',
         'label:ua': 'Гаряча клавіша увімкнути швидкість',
         // title: '',
         options: [
            { label: 'A', value: 'a', selected: true },
            'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z'],
         'data-dependent': { 'player_buttons_custom_items': ['toggle-speed'] },
      },
   }
});
// for test
// https://www.youtube.com/watch?v=bTm3kwroEyw - https://watannetwork.com/tools/blocked/#url=bTm3kwroEyw
// https://www.youtube.com/watch?v=3U2UGM0ldGg - https://watannetwork.com/tools/blocked/#url=3U2UGM0ldGg
// https://www.youtube.com/watch?v=OztVDJXEfpo - https://watannetwork.com/tools/blocked/#url=OztVDJXEfpo

// warn "The following content may contain suicide or self-harm topics."
// https://www.youtube.com/watch?v=MEZ-0nyiago
// https://www.youtube.com/watch?v=MiQozY6jR0I
// https://www.youtube.com/watch?v=ek7JK6pattE
// https://www.youtube.com/watch?v=qAYlTiV-Zf8

window.nova_plugins.push({
   id: 'video-unblock-region',
   title: 'Try unblock if video not available in your country',
   'title:zh': '尝试解锁您所在地区的视频',
   'title:ja': 'お住まいの地域の動画のブロックを解除してみてください',
   'title:ko': '해당 지역의 동영상 차단을 해제해 보세요',
   'title:id': 'Coba buka blokir jika video tidak tersedia di negara Anda',
   'title:es': 'Intenta desbloquear videos para tu región',
   'title:pt': 'Tente desbloquear vídeos para sua região',
   'title:fr': 'Débloquer la vidéo de la région',
   'title:it': 'Prova a sbloccare se il video non è disponibile nel tuo paese',
   'title:tr': 'Bölgeniz için videoların engellemesini kaldırmayı deneyin',
   'title:de': 'Versuchen Sie, Videos für Ihre Region zu entsperren',
   'title:pl': 'Spróbuj odblokować, jeśli film nie jest dostępny w Twoim kraju',
   'title:ua': 'Спробувати розблокувати якщо відео не доступне у країні',
   run_on_pages: 'watch, embed, -mobile',
   section: 'player',
   desc: "attempt fix 'is not available in your country'",
   // 'desc:zh': '',
   // 'desc:ja': '',
   // 'desc:ko': '',
   // 'desc:id': '',
   // 'desc:es': '',
   // 'desc:pt': '',
   // 'desc:fr': '',
   // 'desc:it': '',
   // 'desc:tr': '',
   // 'desc:de': '',
   'desc:pl': 'próba naprawienia nie jest dostępna w Twoim kraju',
   'desc:ua': 'спроба розблокувати доступ до відео',
   _runtime: user_settings => {

      NOVA.waitElement('ytd-watch-flexy[player-unavailable]')
         .then(redirect);

      // Doesn't work
      // NOVA.waitElement('video')
      //    .then(video => {
      //       video.addEventListener('emptied', redirect);
      //    });

      function redirect() {
         // location.hostname = 'hooktube.com'; // cinemaphile.com
         // or
         location.assign(`${location.protocol}//hooktube.com/watch${location.search}`); // currect tab

         window.open(`https://watannetwork.com/tools/blocked/#url=${NOVA.queryURL.get('v')}:~:text=Allowed%20countries`); // new tab and focus

         // tubeunblock.com is shut down
         // location.assign(`${location.protocol}//hooktube.com/watch${location.search}`);
      }

   },
});
window.nova_plugins.push({
   id: 'player-disable-fullscreen-scroll',
   title: 'Disable scrolling in Full Screen Mode',
   'title:zh': '禁用全屏滚动',
   'title:ja': 'フルスクリーンスクロールを無効にする',
   'title:ko': '전체 화면 스크롤 비활성화',
   'title:id': 'Nonaktifkan pengguliran pemain dalam mode layar penuh',
   'title:es': 'Desactivar el desplazamiento a pantalla completa',
   'title:pt': 'Desabilitar rolagem em tela cheia',
   'title:fr': 'Désactiver le défilement plein écran',
   'title:it': 'Disabilita lo scorrimento del lettore in modalità a schermo intero',
   'title:tr': 'Tam ekran kaydırmayı devre dışı bırak',
   'title:de': 'Deaktivieren Sie das Scrollen im Vollbildmodus',
   'title:pl': 'Wyłącz przewijanie w trybie pełnoekranowym',
   'title:ua': 'Вимкнути прокрутку у повноекранному режимі',
   run_on_pages: 'watch',
   section: 'player',
   // desc: '',
   _runtime: user_settings => {

      // hide "Scroll for details" button
      NOVA.css.push(`.ytp-fullerscreen-edu-button { display: none !important; }`);

      document.addEventListener('fullscreenchange', () => {
         document.fullscreenElement
            ? document.addEventListener('wheel', lockscroll, { passive: false })
            : document.removeEventListener('wheel', lockscroll)
      }
      );

      function lockscroll(evt) {
         // console.debug('fullscreenElement:', document.fullscreenElement);
         evt.preventDefault();
      }

      // document.addEventListener('wheel', evt => {
      //    if (document.fullscreen || movie_player.isFullscreen()) {
      //       // console.debug('fullscreenElement:', document.fullscreenElement);
      //       evt.preventDefault();
      //       // movie_player.scrollIntoView({behavior: 'instant', block: 'end', inline: 'nearest'});
      //    }
      // }, { passive: false });

   },
});
// for test
// https://radio.nv.ua/online-radio-nv - live embed

window.nova_plugins.push({
   id: 'time-remaining',
   title: 'Remaining time',
   'title:zh': '剩余时间',
   'title:ja': '余日',
   'title:ko': '남은 시간',
   'title:id': 'Waktu yang tersisa',
   'title:es': 'Tiempo restante',
   'title:pt': 'Tempo restante',
   'title:fr': 'Temps restant',
   'title:it': 'Tempo rimanente',
   'title:tr': 'Kalan süre',
   'title:de': 'Verbleibende Zeit',
   'title:pl': 'Pozostały czas',
   'title:ua': 'Час, що залишився',
   run_on_pages: 'watch, embed',
   section: 'player',
   desc: 'Remaining time until the end of the video',
   'desc:zh': '距离视频结束的剩余时间',
   'desc:ja': 'ビデオの終わりまでの残り時間',
   'desc:ko': '영상 끝까지 남은 시간',
   'desc:id': 'Sisa waktu sampai akhir video',
   'desc:es': 'Tiempo restante hasta el final del video',
   'desc:pt': 'Tempo restante até o final do vídeo',
   'desc:fr': "Temps restant jusqu'à la fin de la vidéo",
   'desc:it': 'Tempo rimanente fino alla fine del video',
   'desc:tr': 'Videonun sonuna kalan süre',
   'desc:de': 'Verbleibende Zeit bis zum Ende des Videos',
   'desc:pl': 'Czas pozostały do końca filmu',
   'desc:ua': 'Час, що залишився до кінця відео',
   _runtime: user_settings => {

      const SELECTOR_ID = 'nova-player-time-remaining';

      NOVA.waitElement('.ytp-time-duration, ytm-time-display .time-display-content')
         .then(container => {

            NOVA.waitElement('video')
               .then(video => {
                  video.addEventListener('timeupdate', setRemaining.bind(video));
                  video.addEventListener('ratechange', setRemaining.bind(video));
                  // clear text
                  ['suspend', 'ended'].forEach(evt => {
                     video.addEventListener(evt, () => insertToHTML({ 'container': container }));
                  });
                  document.addEventListener('yt-navigate-start', () => insertToHTML({ 'container': container }));
               });

            function setRemaining() {
               if (isNaN(this.duration)
                  || movie_player.getVideoData().isLive // stream. Doesn't work in embed
                  || (NOVA.currentPage == 'embed' && window.self.location.href.includes('live_stream'))
                  || document.visibilityState == 'hidden' // tab inactive
                  || movie_player.classList.contains('ytp-autohide')
               ) return;

               const
                  getProgressPt = () => {
                     const floatRound = pt => this.duration > 3600 ? pt.toFixed(2) // >1 hour
                        : this.duration > 1500 ? pt.toFixed(1) // >25 Minute
                           : Math.round(pt); // whats left
                     return floatRound((this.currentTime / this.duration) * 100) + '%';
                  },
                  getLeftTime = () => '-' + NOVA.timeFormatTo.HMS.digit((this.duration - this.currentTime) / this.playbackRate);

               let text;

               switch (user_settings.time_remaining_mode) {
                  case 'pt': text = ' • ' + getProgressPt(); break;
                  case 'time': text = getLeftTime(); break;
                  // case 'full':
                  default:
                     text = getLeftTime();
                     text += text && ` (${getProgressPt()})`; // prevent show NaN
               }

               if (text) {
                  insertToHTML({
                     'text': text,
                     'container': container,
                  });
               }
            }

            function insertToHTML({ text = '', container = required() }) {
               // console.debug('insertToHTML', ...arguments);
               if (!(container instanceof HTMLElement)) return console.error('container not HTMLElement:', container);

               (document.getElementById(SELECTOR_ID) || (function () {
                  // const el = document.createElement('span');
                  // el.id = SELECTOR_ID;
                  // container.after(el);
                  // container.insertAdjacentElement('afterend', '&nbsp;' + el);
                  container.insertAdjacentHTML('afterend', `&nbsp;<span id="${SELECTOR_ID}">${text}</span>`);
                  return document.getElementById(SELECTOR_ID);
               })())
                  .textContent = text;
            }

         });

   },
   options: {
      time_remaining_mode: {
         _tagName: 'select',
         label: 'Mode',
         'label:zh': '模式',
         'label:ja': 'モード',
         'label:ko': '방법',
         // 'label:fd': 'Mode',
         'label:es': 'Modo',
         'label:pt': 'Modo',
         // 'label:fr': 'Mode',
         'label:it': 'Modalità',
         'label:tr': 'Mod',
         'label:de': 'Modus',
         'label:pl': 'Tryb',
         'label:ua': 'Режим',
         options: [
            { label: 'time+(%)', value: 'full' },
            { label: 'time', value: 'time', selected: true },
            { label: '%', value: 'pt' },
         ],
      },
   }
});
window.nova_plugins.push({
   id: 'player-hotkeys-focused',
   title: 'Player hotkeys always active',
   'title:zh': '播放器热键始终处于活动状态',
   'title:ja': 'プレーヤーのホットキーは常にアクティブです',
   'title:ko': '플레이어 단축키는 항상 활성화되어 있습니다',
   'title:id': 'Tombol pintas pemain selalu aktif',
   'title:es': 'Teclas de acceso rápido del jugador siempre activas',
   'title:pt': 'Teclas de atalho do jogador sempre ativas',
   'title:fr': 'Les raccourcis clavier du joueur sont toujours actifs',
   'title:it': 'Tasti di scelta rapida del giocatore sempre attivi',
   'title:tr': 'Oyuncu kısayol tuşları her zaman etkin',
   'title:de': 'Player-Hotkeys immer aktiv',
   'title:pl': 'Klawisze skrótów dla graczy zawsze aktywne',
   'title:ua': 'Гарячі клавіші відтворювача завжди активні',
   run_on_pages: 'watch, embed, -mobile',
   section: 'player',
   // desc: 'Player hotkeys always active【SPACE/F】etc.',
   _runtime: user_settings => {

      document.addEventListener('keydown', ({ target }) => {
         // movie_player.contains(document.activeElement) // Dont use! stay overline
         if (['input', 'textarea'].includes(target.localName) || target.isContentEditable) return;

         // NOVA.videoElement?.focus();
         movie_player.focus();
         // document.activeElement.style.border = '2px solid red'; // mark for test
         // console.debug('active element', target.localName);
      });

   },
});
// for test
// https://www.youtube.com/watch?v=dq5a1GW6iVA

window.nova_plugins.push({
   id: 'livechat-visibility',
   title: 'Hide live chat',
   'title:zh': '隐藏实时聊天',
   'title:ja': 'ライブチャットを非表示',
   'title:ko': '실시간 채팅 숨기기',
   'title:id': 'Sembunyikan obrolan langsung',
   'title:es': 'Ocultar chat en vivo',
   'title:pt': 'Ocultar livechat',
   'title:fr': 'Masquer le chat en direct',
   'title:it': 'Nascondi chat dal vivo',
   'title:tr': 'Canlı sohbeti gizle',
   'title:de': 'Livechat ausblenden',
   'title:pl': 'Ukryj czat na żywo',
   'title:ua': 'Приховати чат',
   run_on_pages: 'watch, -mobile',
   // restart_on_transition: true,
   section: 'sidebar',
   // desc: '',
   _runtime: user_settings => {

      if (user_settings.livechat_visibility_mode == 'disable') {
         const fn1 = () => NOVA.waitElement('#chat')
            .then(chat => {
               chat.remove();
               fn1(); // restart
            });

         fn1(); // init

      } else {
         const fn2 = () => NOVA.waitElement('#chat:not([collapsed]) #show-hide-button #button')
            .then(btn => {
               btn.click()
               fn2(); // restart
            });

         fn2(); // init
      }

   },
   options: {
      livechat_visibility_mode: {
         _tagName: 'select',
         label: 'Mode',
         'label:zh': '模式',
         'label:ja': 'モード',
         'label:ko': '방법',
         // 'label:id': 'Mode',
         'label:es': 'Modo',
         'label:pt': 'Modo',
         // 'label:fr': 'Mode',
         'label:it': 'Mode',
         'label:tr': 'Mod',
         'label:de': 'Modus',
         'label:pl': 'Tryb',
         'label:ua': 'Режим',
         options: [
            { label: 'collapse', value: 'hide', selected: true, 'label:pl': 'zwiń', 'label': 'Приховати' },
            { label: 'remove', value: 'disable', 'label:pl': 'usuń', 'label': 'Вимкнути' },
         ],
      },
   }
});
window.nova_plugins.push({
   id: 'sidebar-channel-links-patch',
   title: 'Fix channel links in sidebar',
   'title:zh': '修复侧边栏中的频道链接',
   'title:ja': 'サイドバーのチャネルリンクを修正',
   'title:ko': '사이드바에서 채널 링크 수정',
   'title:id': 'Perbaiki tautan saluran di bilah sisi',
   'title:es': 'Arreglar enlaces de canales en la barra lateral',
   'title:pt': 'Corrigir links de canais na barra lateral',
   'title:fr': 'Correction des liens de chaîne dans la barre latérale',
   'title:it': 'Correggi i collegamenti ai canali nella barra laterale',
   'title:tr': 'Kenar çubuğunda kanal bağlantılarını düzeltin',
   'title:de': 'Korrigieren Sie die Kanallinks in der Seitenleiste',
   'title:pl': 'Napraw linki do kanałów na pasku bocznym',
   'title:ua': 'Виправити посилання на канали на бічній панелі',
   run_on_pages: 'watch, -mobile',
   section: 'sidebar',
   // desc: '',
   _runtime: user_settings => {

      document.addEventListener('mouseover', ({ target }) => {
         //console.debug('>', target);

         if (!target.matches('.ytd-channel-name')) return;

         if ((link = target.closest('a'))
            && target.__data?.text?.runs.length
            && target.__data?.text?.runs[0].navigationEndpoint?.commandMetadata?.webCommandMetadata?.webPageType == 'WEB_PAGE_TYPE_CHANNEL'
         ) {
            // Doesn't work
            // target.addEventListener('click', ({ target }) => target.preventDefault());

            //const urlOrig = '/watch?v=' + link.data.watchEndpoint.videoId;
            const urlOrig = link.href;
            const url = target.__data.text.runs[0].navigationEndpoint.commandMetadata.webCommandMetadata.url + '/videos';

            // patch
            link.href = url;
            link.data.commandMetadata.webCommandMetadata.url = url;
            link.data.commandMetadata.webCommandMetadata.webPageType = 'WEB_PAGE_TYPE_CHANNEL';
            link.data.browseEndpoint = target.__data.text.runs[0].navigationEndpoint.browseEndpoint;
            link.data.browseEndpoint.params = encodeURIComponent(btoa(String.fromCharCode(0x12, 0x06) + 'videos'));
            //console.debug('patch link:', 1);

            // restore
            target.addEventListener('mouseout', ({ target }) => {
               link.href = urlOrig;
               link.data.commandMetadata.webCommandMetadata.url = urlOrig;
               link.data.commandMetadata.webCommandMetadata.webPageType = 'WEB_PAGE_TYPE_WATCH';
               //console.debug('restore link:', 2);
            }, { capture: true, once: true });
         }
      })

   },
});
// for test:
// https://www.youtube.com/watch?v=9JzmYISeRMA&list=OLAK5uy_kDx6ubTnuS4mYHCPyyX1NpXyCtoQN08M4

window.nova_plugins.push({
   id: 'playlist-reverse',
   title: 'Add playlist reverse order button',
   'title:zh': '添加按钮反向播放列表顺序',
   'title:ja': 'ボタンの逆プレイリストの順序を追加',
   'title:ko': '버튼 역 재생 목록 순서 추가',
   'title:id': 'Tambahkan tombol urutan terbalik daftar putar',
   'title:es': 'Agregar orden de lista de reproducción inverso',
   'title:pt': 'Adicionar ordem inversa da lista de reprodução',
   'title:fr': 'Ajouter un ordre de lecture inversé',
   'title:it': "Aggiungi il pulsante dell'ordine inverso della playlist",
   'title:tr': 'Ekle düğmesi ters çalma listesi sırası',
   'title:de': 'Umgekehrte Playlist-Reihenfolge hinzufügen',
   'title:pl': 'Dodaj przycisk odtwarzania w odwrotnej kolejności',
   'title:ua': 'Кнопка додавання списку відтворення у зворотному порядку',
   run_on_pages: 'watch, -mobile',
   // restart_on_transition: true,
   section: 'sidebar',
   // desc: '',
   _runtime: user_settings => {

      const
         SELECTOR_ID = 'nova-playlist-reverse-btn',
         SELECTOR = '#' + SELECTOR_ID, // for css
         CLASS_NAME_ACTIVE = 'nova-playlist-reverse-on';

      window.nova_playlistReversed; // global for other plugin (for fix conflict)

      // init reverseBtn style
      NOVA.css.push(
         SELECTOR + ` {
            background: none;
            border: 0;
         }
         yt-icon-button {
            width: 40px;
            height: 40px;
            padding: 10px;
         }
         ${SELECTOR} svg {
            fill: white;
            fill: var(--yt-spec-text-secondary);
         }
         ${SELECTOR}:hover svg { fill: #66afe9; }

         ${SELECTOR}:active svg,
         ${SELECTOR}.${CLASS_NAME_ACTIVE} svg { fill: #2196f3; }`);

      document.addEventListener('yt-navigate-finish', () => {
         // if (!NOVA.queryURL.has('list')/* || !movie_player?.getPlaylistId()*/) return;
         if (!location.search.includes('list=')) return;
         insertButton();
         reverseControl(); // add events
      });
      // init
      // if (NOVA.queryURL.has('list')/* || movie_player?.getPlaylistId()*/) insertButton();
      if (location.search.includes('list=')) insertButton();

      function insertButton() {
         NOVA.waitElement('ytd-watch-flexy.ytd-page-manager:not([hidden]) ytd-playlist-panel-renderer:not([collapsed]) #playlist-action-menu .top-level-buttons:not([hidden]), #secondary #playlist #playlist-action-menu #top-level-buttons-computed')
            .then(el => renderBtn(el));

         function renderBtn(container = required()) {
            if (!(container instanceof HTMLElement)) return console.error('container not HTMLElement:', container);

            document.getElementById(SELECTOR_ID)?.remove(); // clear old

            const
               reverseBtn = document.createElement('div'),
               renderTitle = () => reverseBtn.title = `Reverse playlist order is ${window.nova_playlistReversed ? 'ON' : 'OFF'}`;

            if (window.nova_playlistReversed) reverseBtn.className = CLASS_NAME_ACTIVE;
            reverseBtn.id = SELECTOR_ID;
            renderTitle(); // refresh only after page transitionend
            reverseBtn.innerHTML =
               // `<yt-icon-button>
               //    <svg viewBox="0 0 16 20">
               //       <g>
               //          <polygon points="7,8 3,8 3,14 0,14 5,20 10,14 7,14"/>
               //          <polygon points="'11,0 6,6 9,6 9,12 13,12 13,6 16,6"/>
               //       </g>
               //    </svg>
               // </yt-icon-button>`;
               `<yt-icon-button>
                  <svg viewBox="0 0 381.399 381.399" height="100%" width="100%">
                     <g>
                        <path d="M233.757,134.901l-63.649-25.147v266.551c0,2.816-2.286,5.094-5.104,5.094h-51.013c-2.82,0-5.099-2.277-5.099-5.094 V109.754l-63.658,25.147c-2.138,0.834-4.564,0.15-5.946-1.669c-1.389-1.839-1.379-4.36,0.028-6.187L135.452,1.991 C136.417,0.736,137.91,0,139.502,0c1.576,0,3.075,0.741,4.041,1.991l96.137,125.061c0.71,0.919,1.061,2.017,1.061,3.109 c0,1.063-0.346,2.158-1.035,3.078C238.333,135.052,235.891,135.735,233.757,134.901z M197.689,378.887h145.456v-33.62H197.689 V378.887z M197.689,314.444h145.456v-33.622H197.689V314.444z M197.689,218.251v33.619h145.456v-33.619H197.689z"/>
                     </g>
                  </svg>
               </yt-icon-button>`;
            reverseBtn.addEventListener('click', () => {
               reverseBtn.classList.toggle(CLASS_NAME_ACTIVE);
               window.nova_playlistReversed = !window.nova_playlistReversed;

               if (window.nova_playlistReversed) {
                  reverseControl();
                  // movie_player.updatePlaylist();
                  renderTitle(); // refresh before page transition
                  fixConflictPlugins();
               } else {
                  location.reload(); // disable reverse
               }
            });
            container.append(reverseBtn);
         }
      }

      function fixConflictPlugins() {
         // document.getElementById('nova-playlist-duration').style.display = 'none'; // hide
         document.getElementById('nova-playlist-duration').innerHTML = '&nbsp; [out of reach] &nbsp;';
         document.getElementById('nova-playlist-autoplay-btn').disabled = true; // disabled button
         document.getElementById('nova-playlist-autoplay-btn').title = 'out of reach';
      }

      // Strategy 1 (api way)
      async function reverseControl() {
         if (!window.nova_playlistReversed) return;

         const
            ytdWatch = await NOVA.waitElement(('ytd-watch, ytd-watch-flexy')),
            data = await NOVA.waitUntil(() => ytdWatch?.data.contents?.twoColumnWatchNextResults),
            playlist = data.playlist.playlist,
            autoplay = data.autoplay.autoplay;

         playlist.contents.reverse();

         playlist.currentIndex = (playlist.totalVideos - playlist.currentIndex) - 1;
         playlist.localCurrentIndex = (playlist.contents.length - playlist.localCurrentIndex) - 1;

         for (const i of autoplay.sets) {
            i.autoplayVideo = i.previousButtonVideo;
            i.previousButtonVideo = i.nextButtonVideo;
            i.nextButtonVideo = i.autoplayVideo;
         }

         ytdWatch.updatePageData_(data);

         if ((manager = document.body.querySelector('yt-playlist-manager'))
            && (ytdPlayer = document.getElementById('ytd-player'))
         ) {
            ytdPlayer.updatePlayerComponents(null, autoplay, null, playlist);
            manager.autoplayData = autoplay;
            manager.setPlaylistData(playlist);
            ytdPlayer.updatePlayerPlaylist_(playlist);
         }

         scrollToElement(document.body.querySelector('#secondary #playlist-items[selected], ytm-playlist .item[selected=true]'));
      }

      // Strategy 2 (html5 way)
      // function reverseControl() {
      //    if (!window.nova_playlistReversed) return;

      //    // auto next click
      //    NOVA.videoElement?.addEventListener('ended', () =>
      //       window.nova_playlistReversed && movie_player.previousVideo(), { capture: true, once: true });

      //    // update UI
      //    // Strategy 1
      //    reverseElement(document.body.querySelector('#secondary #playlist #items.playlist-items, ytm-playlist lazy-list'));
      //    scrollToElement(document.body.querySelector('#secondary #playlist-items[selected], ytm-playlist .item[selected=true]'));
      //    // Strategy 2: scroll doesn't work
      //    // NOVA.css.push(
      //    //    `#playlist #items.playlist-items {
      //    //       display: flex;
      //    //       flex-direction: column-reverse;
      //    //    }`);

      //    updateNextButton();


      //    function updateNextButton() {
      //       const
      //          nextItem = document.body.querySelector('#secondary #playlist [selected] + * a'),
      //          nextURL = nextItem?.querySelector('a')?.href;

      //       if (!nextURL) return;

      //       if (next_button = document.body.querySelector('.ytp-next-button')) {
      //          next_button.href = nextURL;
      //          next_button.dataset.preview = nextItem.querySelector('img').src;
      //          next_button.dataset.tooltipText = nextItem.querySelector('#video-title').textContent;
      //       }
      //       if (manager = document.body.querySelector('yt-playlist-manager')?.autoplayData.sets[0].nextButtonVideo) {
      //          manager.commandMetadata.webCommandMetadata.url = nextURL.replace(location.origin, '');
      //          manager.watchEndpoint.videoId = NOVA.queryURL.get('v', nextURL);
      //       }
      //    }

      //    function reverseElement(container = required()) {
      //       if (!(container instanceof HTMLElement)) return console.error('container not HTMLElement:', container);
      //       container.append(...Array.from(container.childNodes).reverse());
      //    }
      // }

      function scrollToElement(targetEl = required()) {
         if (!(targetEl instanceof HTMLElement)) return console.error('targetEl not HTMLElement:', targetEl);
         const container = targetEl.parentElement;
         container.scrollTop = targetEl.offsetTop - container.offsetTop;
      }

   },
});
window.nova_plugins.push({
   id: 'related-visibility',
   title: 'Collapse related section',
   'title:zh': '收起相关栏目',
   'title:ja': '関連セクションを折りたたむ',
   'title:ko': '관련 섹션 축소',
   'title:id': 'Ciutkan bagian terkait',
   'title:es': 'Ocultar sección relacionada',
   'title:pt': 'Recolher seção relacionada',
   'title:fr': 'Réduire la section associée',
   'title:it': 'Comprimi la sezione relativa',
   'title:tr': 'İlgili bölümü daralt',
   'title:de': 'Zugehörigen Abschnitt minimieren',
   'title:pl': 'Zwiń powiązaną sekcję',
   'title:ua': 'Згорнути розділ "пов`язано"',
   run_on_pages: 'watch, -mobile',
   section: 'sidebar',
   // desc: '',
   _runtime: user_settings => {

      NOVA.collapseElement({
         selector: '#secondary #related',
         title: 'related',
         remove: user_settings.related_visibility_mode == 'disable' ? true : false,
      });

   },
   options: {
      related_visibility_mode: {
         _tagName: 'select',
         label: 'Mode',
         'label:zh': '模式',
         'label:ja': 'モード',
         'label:ko': '방법',
         // 'label:id': 'Mode',
         'label:es': 'Modo',
         'label:pt': 'Modo',
         // 'label:fr': 'Mode',
         'label:it': 'Mode',
         'label:tr': 'Mod',
         'label:de': 'Modus',
         'label:pl': 'Tryb',
         'label:ua': 'Режим',
         options: [
            { label: 'collapse', value: 'hide', selected: true, 'label:pl': 'zwiń', 'label:ua': 'Приховати' },
            { label: 'remove', value: 'disable', 'label:pl': 'usuń', 'label:ua': 'Вимкнути' },
         ],
      },
   }
});
// for test:
// https://www.youtube.com/playlist?list=WL
// https://www.youtube.com/watch?v=G134f9wUGcU&list=PLVaR5VNkhu5533wzRj0W0gfXExZ0srdjY - short and has [Private video]
// https://www.youtube.com/watch?v=Y07--9_sLpA&list=OLAK5uy_nMilHFKO3dZsuNgVWmEKDZirwXRXMl9yM - hidden playlist conteiner
// https://www.youtube.com/playlist?list=PLJP5_qSxMbkLzx-XiaW0U8FcpYGgwlh5s -simple
// https://www.youtube.com/watch?v=L1bBMndgmM0&list=PLNGZuc13nIrqOrynIHoy3VdQ5FDXypMSO&index=5 - has 36:00
// https://www.youtube.com/watch?v=v0PqdzLdFSk&list=OLAK5uy_m-Dv_8xLBZNZeysu7yXsw7psMf48nJ7tw - 1 unavailable video is hidden
// https://www.youtube.com/watch?v=RhxF9Qg5mOU&list=RDEMd-ObnI9A_YffTMufAPhAHQ&index=9 - infinite playlist

window.nova_plugins.push({
   id: 'playlist-duration',
   title: 'Show playlist duration',
   'title:zh': '显示播放列表持续时间',
   'title:ja': 'プレイリストの期間を表示',
   'title:ko': '재생목록 재생시간 표시',
   'title:id': 'Tampilkan durasi daftar putar',
   'title:es': 'Mostrar duración de la lista de reproducción',
   'title:pt': 'Mostrar duração da lista de reprodução',
   'title:fr': 'Afficher la durée de la liste de lecture',
   'title:it': 'Mostra la durata della playlist',
   'title:tr': 'Oynatma listesi süresini göster',
   'title:de': 'Wiedergabelistendauer anzeigen',
   'title:pl': 'Pokaż czas trwania playlisty',
   'title:ua': 'Показувати тривалість списку відтворення',
   run_on_pages: 'watch, playlist, -mobile',
   restart_on_transition: true,
   section: 'sidebar',
   // desc: '',
   _runtime: user_settings => {

      // alt - https://greasyfork.org/en/scripts/408966-display-remaining-youtube-playlist-time
      // alt2 - https://greasyfork.org/en/scripts/407457-youtube-playlist-duration-calculator

      const
         SELECTOR_ID = 'nova-playlist-duration',
         // CACHE_PREFIX = SELECTOR_ID + ':',
         // STORE_NAME = CACHE_PREFIX + playlistId,
         playlistId = NOVA.queryURL.get('list');

      if (!playlistId) return;

      switch (NOVA.currentPage) {
         case 'playlist':
            NOVA.waitElement('#stats yt-formatted-string:first-child')
               .then(el => {
                  if (duration = getPlaylistDuration()) {
                     insertToHTML({ 'container': el, 'text': duration });

                  } else {
                     // getPlaylistDurationFromThumbs()
                     getPlaylistDurationFromThumbnails({
                        'items_selector': '#primary .ytd-thumbnail-overlay-time-status-renderer:not(:empty)',
                     })
                        .then(duration => insertToHTML({ 'container': el, 'text': duration }));
                  }

                  function getPlaylistDuration() {
                     // if (storage = sessionStorage.getItem(STORE_NAME)) {
                     //    // console.debug(`get from cache [${CACHE_PREFIX + playlistId}]`, storage);
                     //    return storage;
                     // }

                     const vids_list = (document.body.querySelector('ytd-app')?.data?.response || window.ytInitialData)
                        .contents.twoColumnBrowseResultsRenderer
                        ?.tabs[0].tabRenderer?.content?.sectionListRenderer
                        ?.contents[0].itemSectionRenderer
                        ?.contents[0].playlistVideoListRenderer?.contents;

                     const duration = vids_list?.reduce((acc, vid) => acc + (isNaN(vid.playlistVideoRenderer?.lengthSeconds) ? 0 : parseInt(vid.playlistVideoRenderer.lengthSeconds)), 0);

                     if (duration) return outFormat(duration);
                  }
               });
            break;

         case 'watch':
            NOVA.waitElement('#secondary .index-message-wrapper')
               .then(el => {
                  const waitPlaylist = setInterval(() => {
                     const playlistLength = movie_player.getPlaylist()?.length;

                     let vids_list = document.body.querySelector('ytd-watch, ytd-watch-flexy')
                        ?.data?.contents?.twoColumnWatchNextResults?.playlist?.playlist?.contents
                        // let vids_list = window.ytInitialData.contents?.twoColumnWatchNextResults?.playlist?.playlist?.contents // not updated after page transition!
                        .filter(i => i.playlistPanelVideoRenderer?.hasOwnProperty('videoId')); // filter hidden

                     console.assert(vids_list?.length === playlistLength, 'playlist loading:', vids_list?.length + '/' + playlistLength);

                     if (vids_list?.length && playlistLength && vids_list?.length === playlistLength) {
                        clearInterval(waitPlaylist);

                        if (duration = getPlaylistDuration(vids_list)) {
                           insertToHTML({ 'container': el, 'text': duration });

                        } else if (!user_settings.playlist_duration_progress_type) { // this method ignores progress
                           getPlaylistDurationFromThumbnails({
                              'container': document.body.querySelector('#secondary #playlist'),
                              'items_selector': '#playlist-items #unplayableText[hidden]',
                           })
                              // getPlaylistDurationFromThumbs({
                              //    'container': document.body.querySelector('#secondary #playlist'),
                              // })
                              .then(duration => insertToHTML({ 'container': el, 'text': duration }));
                        }
                     }
                  }, 1000); // 1 sec

                  function getPlaylistDuration(vids_list = []) {
                     // console.log('getPlaylistDuration', ...arguments);

                     // if (!user_settings.playlist_duration_progress_type && (storage = sessionStorage.getItem(STORE_NAME))) {
                     //    // console.debug(`get from cache [${CACHE_PREFIX + playlistId}]`, storage);
                     //    return storage;
                     // }

                     // let vids_list = document.body.querySelector('ytd-watch, ytd-watch-flexy')
                     // ?.data?.contents?.twoColumnWatchNextResults?.playlist?.playlist?.contents || [];

                     // alt if current "playingIdx" always one step behind
                     // const
                     //    videoId = movie_player.getVideoData().video_id || NOVA.queryURL.get('v'),
                     //    playingIdx2 = vids_list?.findIndex(c => c.playlistPanelVideoRenderer.videoId == videoId);
                     // console.assert(playingIdx == playingIdx2, 'playingIdx diff:', playingIdx + '/' + playingIdx2);
                     // if (playingIdx !== playingIdx2) alert(1)

                     if (window.nova_playlistReversed) vids_list = [...vids_list].reverse();

                     const playingIdx = vids_list?.findIndex(c => c.playlistPanelVideoRenderer.selected);
                     // not available for reverse
                     // const playingIdx = movie_player.getPlaylistIndex() || vids_list?.findIndex(c => c.playlistPanelVideoRenderer.selected);

                     let total;

                     switch (user_settings.playlist_duration_progress_type) {
                        case 'done':
                           total = getDurationFromList(vids_list);
                           vids_list.splice(playingIdx);
                           // console.debug('done vids_list.length:', vids_list.length);
                           break;

                        case 'left':
                           total = getDurationFromList(vids_list);
                           vids_list.splice(0, playingIdx);
                           // console.debug('left vids_list.length:', vids_list.length);
                           break;

                        // case 'total': // skiping
                     }

                     if ((duration = getDurationFromList(vids_list)) // disallow set zero
                        || (duration === 0 && user_settings.playlist_duration_progress_type) // allow set zero if use playlist_duration_progress_type
                     ) {
                        return outFormat(duration, total);
                     }

                     function getDurationFromList(arr) {
                        return [...arr]
                           .filter(e => e.playlistPanelVideoRenderer?.thumbnailOverlays?.length) // filter [Private video]
                           .flatMap(e => (time = e.playlistPanelVideoRenderer.thumbnailOverlays[0].thumbnailOverlayTimeStatusRenderer?.text.simpleText)
                              ? NOVA.timeFormatTo.hmsToSec(time) : [])
                           .reduce((acc, time) => acc + time, 0);
                     }
                  }
               });
            break;
      }

      function getPlaylistDurationFromThumbnails({ items_selector = required(), container }) {
         console.log('thumbnails_method', ...arguments);
         if (container && !(container instanceof HTMLElement)) {
            return console.error('container not HTMLElement:', container);
         }

         return new Promise(resolve => {
            let forcePlaylistRun = false;
            const waitThumbnails = setInterval(() => {
               const
                  playlistLength = document.body.querySelector('ytd-player')?.player_?.getPlaylist()?.length || document.body.querySelectorAll(items_selector)?.length,
                  timeStampList = (container || document.body)
                     .querySelectorAll('.ytd-thumbnail-overlay-time-status-renderer:not(:empty)'),
                  duration = getTotalTime(timeStampList);

               console.assert(timeStampList.length === playlistLength, 'playlist loading:', timeStampList.length + '/' + playlistLength);

               if (+duration && timeStampList.length
                  && (timeStampList.length === playlistLength || forcePlaylistRun)
               ) {
                  clearInterval(waitThumbnails);
                  resolve(outFormat(duration));

               } else if (!forcePlaylistRun) { // set force calc duration
                  setTimeout(() => forcePlaylistRun = true, 1000 * 3); // 3sec
               }

            }, 500); // 500ms
         });

         function getTotalTime(nodes) {
            // console.debug('getTotalTime', ...arguments);
            const arr = [...nodes]
               .map(e => NOVA.timeFormatTo.hmsToSec(e.textContent))
               .filter(Number); // filter PREMIERE

            return arr.length && arr.reduce((acc, time) => acc + +time, 0);
         }
         // function getTotalTime(nodes) {
         //    // console.debug('getTotalTime', ...arguments);
         //    return [...nodes]
         //       // .map(e => NOVA.timeFormatTo.hmsToSec(e.textContent))
         //       // .filter(t => !isNaN(+t)) // filter PREMIERE
         //       .flatMap(e => NOVA.timeFormatTo.hmsToSec(e.textContent) || [])
         //       .reduce((acc, time) => acc + time, 0);
         // }
      }

      function outFormat(duration = 0, total) {
         // console.log('outFormat', ...arguments);
         let outArr = [];
         // time
         outArr.push(NOVA.timeFormatTo.HMS.digit(
            (NOVA.currentPage == 'watch' && NOVA.videoElement?.playbackRate)
               ? duration / NOVA.videoElement.playbackRate : duration
         ));
         // pt
         if (user_settings.playlist_duration_percentage && total) {
            outArr.push(`(${~~(duration * 100 / total) + '%'})`);
         }
         // progress type (done, left, total)
         if (user_settings.playlist_duration_progress_type) {
            outArr.push(user_settings.playlist_duration_progress_type);
         }
         return ' - ' + outArr.join(' ');
      }

      function insertToHTML({ text = '', container = required() }) {
         // console.debug('insertToHTML', ...arguments);
         if (!(container instanceof HTMLElement)) return console.error('container not HTMLElement:', container);

         (document.getElementById(SELECTOR_ID) || (function () {
            const el = document.createElement('span');
            el.id = SELECTOR_ID;
            // el.className = 'style-scope ytd-playlist-sidebar-primary-info-renderer';
            // el.style.display = 'inline-block';
            // el.style.margin = '0 .5em';
            return container.appendChild(el);
         })())
            .textContent = ' ' + text;

         // sessionStorage.setItem(STORE_NAME, text); // save in sessionStorage
      }

   },
   options: {
      playlist_duration_progress_type: {
         _tagName: 'select',
         label: 'Time display mode',
         'label:zh': '时间显示方式',
         'label:ja': '時間表示モード',
         'label:ko': '시간 표시 모드',
         'label:id': 'Mode tampilan waktu',
         'label:es': 'Modo de visualización de la hora',
         'label:pt': 'Modo de exibição de tempo',
         'label:fr': "Mode d'affichage de l'heure",
         'label:it': "Modalità di visualizzazione dell'ora",
         'label:tr': 'Zaman görüntüleme modu',
         'label:de': 'Zeitanzeigemodus',
         'label:pl': 'Tryb wyświetlania czasu',
         'label:ua': 'Режим відображення часу',
         options: [
            { label: 'done', value: 'done', 'label:zh': '结束', 'label:ja': '終わり', 'label:ko': '보았다', /*'label:id': '',*/ 'label:es': 'hecho', 'label:pt': 'feito', 'label:fr': 'regardé', /*'label:it': '',*/ 'label:tr': 'tamamlamak', 'label:de': 'fertig', 'label:pl': 'zakończone', 'label': 'Завершено' },
            { label: 'left', value: 'left', 'label:zh': '剩下', 'label:ja': '残り', 'label:ko': '왼쪽', /*'label:id': '',*/ 'label:es': 'izquierda', 'label:pt': 'deixou', 'label:fr': 'À gauche', /*'label:it': '',*/'label:tr': 'sola', 'label:de': 'links', 'label:pl': 'pozostało', 'label': 'Залишилось' },
            { label: 'total', value: false, selected: true, 'label:zh': '全部的', 'label:ja': '全て', 'label:ko': '총', /*'label:id': '', 'label:es': '','label:pt': '',*/  'label:fr': 'le total', /*'label:it': '',*/ 'label:tr': 'toplam', 'label:de': 'gesamt', 'label:pl': 'w sumie', 'label': 'Загалом' },
         ],
      },
      playlist_duration_percentage: {
         _tagName: 'input',
         label: 'Add percentage',
         'label:zh': '显示百分比',
         'label:ja': 'パーセンテージを表示',
         'label:ko': '백분율 추가',
         'label:id': 'Tambahkan persentase',
         'label:es': 'Agregar porcentaje',
         'label:pt': 'Adicionar porcentagem',
         'label:fr': 'Ajouter un pourcentage',
         'label:it': 'Aggiungi percentuale',
         'label:tr': 'Yüzde ekle',
         'label:de': 'Prozent hinzufügen',
         'label:pl': 'Pokaż procenty',
         'label:ua': 'Показати %',
         type: 'checkbox',
      },
   }
});
// for test:
// https://www.youtube.com/watch?v=9JzmYISeRMA&list=OLAK5uy_kDx6ubTnuS4mYHCPyyX1NpXyCtoQN08M4

window.nova_plugins.push({
   id: 'playlist-toggle-autoplay',
   title: 'Playlist autoplay control button',
   'title:zh': '播放列表自动播放控制',
   'title:ja': 'プレイリストの自動再生コントロール',
   'title:ko': '재생 목록 자동 재생 제어',
   'title:id': 'Tombol kontrol putar otomatis daftar putar',
   'title:es': 'Control de reproducción automática de listas de reproducción',
   'title:pt': 'Controle de reprodução automática da lista de reprodução',
   'title:fr': 'Contrôle de lecture automatique de la liste de lecture',
   'title:it': 'Pulsante di controllo della riproduzione automatica della playlist',
   'title:tr': 'Oynatma listesi otomatik oynatma kontrolü',
   'title:de': 'Steuerung der automatischen Wiedergabe von Wiedergabelisten',
   'title:pl': 'Kontrola autoodtwarzania listy odtwarzania',
   'title:ua': 'Кнопка керування автовідтворенням',
   run_on_pages: 'watch, -mobile',
   // restart_on_transition: true,
   section: 'sidebar',
   // desc: '',
   _runtime: user_settings => {

      // alt - https://greasyfork.org/en/scripts/415542-youtube-prevent-playlist-autoplay

      if (window.nova_playlistReversed) return; // conflict with plugin

      const
         SELECTOR_ID = 'nova-playlist-autoplay-btn', // .switcher
         SELECTOR = '#' + SELECTOR_ID; // for css

      let sesionAutoplayState = user_settings.playlist_autoplay;

      // init checkboxBtn style
      NOVA.css.push(
         `#playlist-action-menu .top-level-buttons {
            align-items: center;
         }
         ${SELECTOR}[type=checkbox] {
            --height: 1em;
            width: 2.2em;
         }
         ${SELECTOR}[type=checkbox]:after {
            transform: scale(1.5);
         }
         ${SELECTOR}[type=checkbox] {
            --opacity: .7;
            --color: #fff;
            height: var(--height);
            line-height: 1.6em;
            border-radius: 3em;
            background-color: var(--paper-toggle-button-unchecked-bar-color, #000000);
            appearance: none;
            -webkit-appearance: none;
            position: relative;
            cursor: pointer;
            outline: 0;
            border: none;
         }
         ${SELECTOR}[type=checkbox]:after {
            position: absolute;
            top: 0;
            left: 0;
            content: '';
            width: var(--height);
            height: var(--height);
            border-radius: 50%;
            background-color: var(--color);
            box-shadow: 0 0 .25em rgba(0, 0, 0, .3);
            /* box-shadow: 0 .1em .25em #999999; */
         }
         ${SELECTOR}[type=checkbox]:checked:after {
            left: calc(100% - var(--height));
            --color: var(--paper-toggle-button-checked-button-color, var(--primary-color));
         }
         ${SELECTOR}[type=checkbox]:focus, input[type=checkbox]:focus:after {
            transition: all 200ms ease-in-out;
         }
         ${SELECTOR}[type=checkbox]:disabled {
            opacity: .3;
         }`);

      // init
      insertButton();
      // on page update
      document.addEventListener('yt-navigate-finish', insertButton);

      function insertButton() {
         // if (!NOVA.queryURL.has('list')/* || !movie_player?.getPlaylistId()*/) return;
         if (!location.search.includes('list=')) return;
         if (window.nova_playlistReversed) return; // conflict with plugin

         NOVA.waitElement('ytd-watch-flexy.ytd-page-manager:not([hidden]) ytd-playlist-panel-renderer:not([collapsed]) #playlist-action-menu .top-level-buttons:not([hidden]), #secondary #playlist #playlist-action-menu #top-level-buttons-computed')
            .then(el => renderCheckbox(el));

         function renderCheckbox(container = required()) {
            if (!(container instanceof HTMLElement)) return console.error('container not HTMLElement:', container);

            document.getElementById(SELECTOR_ID)?.remove(); // clear old

            const checkboxBtn = document.createElement('input');
            // checkboxBtn.className = '';
            checkboxBtn.id = SELECTOR_ID;
            checkboxBtn.type = 'checkbox';
            checkboxBtn.title = 'Playlist toggle autoplay';
            checkboxBtn.addEventListener('change', ({ target }) => {
               // setAssociatedAutoplay(target.checked);
               sesionAutoplayState = target.checked;
               setAssociatedAutoplay();
            });
            container.append(checkboxBtn);

            checkboxBtn.checked = sesionAutoplayState; // set default state
            // setAssociatedAutoplay(sesionAutoplayState);
            setAssociatedAutoplay();

            // function setAssociatedAutoplay(state) {
            function setAssociatedAutoplay() {
               // get playlist manager
               if (manager = document.body.querySelector('yt-playlist-manager')) {
                  manager.interceptedForAutoplay = true;
                  manager.canAutoAdvance_ = checkboxBtn.checked;
                  // let currentExpected = true
                  // manager.onYtNavigateStart_ = function () { this.canAutoAdvance_ = currentExpected = false }
                  // manager.onYtNavigateFinish_ = function () { currentExpected = true; this.canAutoAdvance_ = checkboxBtn.checked ? currentExpected : false }
                  // checkbox update state
                  checkboxBtn.checked = manager?.canAutoAdvance_;
                  checkboxBtn.title = `Playlist Autoplay is ${manager?.canAutoAdvance_ ? 'ON' : 'OFF'}`;

               } else console.error('Error playlist-autoplay. Playlist manager is', manager);
            }

         }
      }

   },
   options: {
      playlist_autoplay: {
         _tagName: 'select',
         label: 'Default state',
         'label:zh': '默认状态',
         'label:ja': 'デフォルト状態',
         'label:ko': '기본 상태',
         // 'label:id': 'Status default',
         'label:es': 'Estado predeterminado',
         'label:pt': 'Estado padrão',
         'label:fr': 'État par défaut',
         'label:it': 'Stato predefinito',
         'label:tr': 'Varsayılan',
         'label:de': 'Standardzustand',
         'label:pl': 'Stan domyślny',
         'label:ua': 'Cтан за замовчуваням',
         options: [
            { label: 'play', value: true, selected: true },
            { label: 'stop', value: false },
         ],
      },
   }
});
const Plugins = {
   list: [
      // 'plugins/_blank_plugin.js', // for example

      'player/ad-skip-button.js',
      'player/speed.js',
      'player/volume.js',
      'player/hud.js',
      'player/quality.js',
      'player/autostop.js',
      'player/autopause.js',
      'player/theater-mode.js',
      'player/pause-background.js',
      'player/fullscreen-on-playback.js',
      'player/control-autohide.js',
      'player/hotkeys-focused.js',
      'player/pin.js',
      'player/time-jump.js',
      'player/time-remaining.js',
      'player/float-progress-bar.js',
      'player/no-sleep.js',
      'player/loop.js',
      'player/resume-playback.js',
      // 'player/-thumb-pause.js',
      'player/buttons-custom.js',
      'player/subtitle-transparent.js',
      // 'player/subtitle-lang.js',
      // 'player/miniplayer-disable.js',
      'player/unblock-region.js',
      // 'player/next-autoplay.js',
      'player/fullscreen-scroll.js',

      'other/annotations.js',
      'other/thumbs-clear.js',
      'other/thumbs-title-normalize.js',
      // 'other/thumbs-rating.js',
      'other/thumbs-watched.js',
      'other/channel-tab.js',
      // 'other/dark-theme.js',
      'other/title-time.js',
      'other/scroll-to-top.js',
      'other/thumb-title-filter.js',
      'other/search-channel-filter.js',
      'other/thumbs-hide.js',
      'other/shorts-redirect.js',
      // 'other/shorts-hide.js',
      // 'other/premieres-hide.js',
      // 'other/thumbnails-mix-hide.js',
      // 'other/streams-hide.js',
      'other/playlist-rss.js',
      // 'other/thumbs-sort.js',
      'other/stop-channel-trailer.js',
      'other/miniplayer-disable.js',

      'details/videos-count.js',
      'details/description-expand.js',
      'details/description-popup.js',
      'details/timestamps-scroll.js',
      'details/redirect-clear.js',
      // 'details/quick-menu.js',

      'comments/visibility.js',
      'comments/square-avatars.js',
      'comments/popup.js',
      'comments/expand.js',

      'sidebar/related-visibility.js',
      'sidebar/playlist-autoplay.js',
      'sidebar/playlist-duration.js',
      'sidebar/playlist-reverse.js',
      'sidebar/livechat.js',
      'sidebar/channel-link.js',
      // 'sidebar/playlist-skip-liked.js',

      'header/search.js',
      'header/short.js',
      'header/unfixed.js',
      'header/logo.js',
   ],

   // for test
   // list: [
   //    'other/annotations.js',
   //    'sidebar/playlist-duration.js',
   //    'sidebar/playlist-reverse.js',
   //    'comments/expand.js',
   //    'details/description-expand.js',
   //    'details/description-popup.js',
   //    'details/videos-count.js',
   // ],
   // list: [
   //    // 'comments/square-avatars.js',
   //    // 'player/autostop.js',
   //    'sidebar/-playlist-skip-liked.js',
   // ],

   load(list) {
      (list || this.list)
         .forEach(plugin => {
            try {
               this.injectScript(chrome.runtime.getURL('/plugins/' + plugin));
            } catch (error) {
               console.error(`plugin loading failed: ${plugin}\n${error.stack}`);
            }
         })
   },

   injectScript(source = required()) {
      const script = document.createElement('script');

      if (source.endsWith('.js')) {
         script.src = source;
         script.defer = true; // https://developer.mozilla.org/en-US/docs/Web/HTML/Element/script#attr-defer:~:text=defer,-This
         // script.async = true;

      } else { // injectCode
         script.textContent = source.toString();
         // script.src = "data:text/plain;base64," + btoa(source);
         // script.src = 'data:text/javascript,' + encodeURIComponent(source)
      }

      (document.head || document.documentElement).append(script);

      script.onload = () => {
         // console.log('script injected:', script.src || script.textContent.substr(0, 100));
         script.remove(script); // Remove <script> node after injectScript runs.
      };
   },

   // injectFunction(func, args) {
   //    // console.debug('injectFunction', ...arguments);
   //    this.injectScript(`(${func})(${args});`);
   // },

   run: ({ user_settings, app_ver }) => {
      // console.debug('plugins_executor', ...arguments);
      if (!window.nova_plugins?.length) return console.error('nova_plugins empty', window.nova_plugins);
      if (!user_settings) return console.error('user_settings empty', user_settings);

      NOVA.currentPage = (function () {
         const [page, channelTab] = location.pathname.split('/').filter(Boolean);
         return (['channel', 'c', 'user'].includes(page)
            // fix non-standard link:
            // https://www.youtube.com/pencilmation
            // https://www.youtube.com/rhino
            || ['featured', 'videos', 'shorts', 'streams', 'playlists', 'community', 'channels', 'about'].includes(channelTab)
            // https://www.youtube.com/clip/Ugkx2Z62NxoBfx_ZR2nIDpk3F2f90TV4_uht
         ) ? 'channel' : page == 'clip' ? 'watch' : page || 'home';
      })();
      // console.debug('NOVA.currentPage', NOVA.currentPage);

      const isMobile = location.host == 'm.youtube.com';

      let logTableArray = [],
         logTableStatus,
         logTableTime;

      // console.groupCollapsed('plugins status');

      window.nova_plugins?.forEach(plugin => {
         const pagesAllowList = plugin?.run_on_pages?.split(',').map(p => p.trim().toLowerCase()).filter(Boolean);
         // reset logTable
         logTableTime = 0;
         logTableStatus = false;

         if (!pluginChecker(plugin)) {
            console.error('Plugin invalid\n', plugin);
            alert('Plugin invalid: ' + plugin?.id);
            logTableStatus = 'INVALID';

         } else if (plugin.was_init && !plugin.restart_on_transition) {
            logTableStatus = 'skiped';

         } else if (!user_settings.hasOwnProperty(plugin.id)) {
            logTableStatus = 'off';

         } else if (
            (
               pagesAllowList?.includes(NOVA.currentPage)
               || (pagesAllowList?.includes('all') && !pagesAllowList?.includes('-' + NOVA.currentPage))
            )
            && (!isMobile || (isMobile && !pagesAllowList?.includes('-mobile')))
         ) {
            try {
               const startTableTime = performance.now();
               plugin.was_init = true;
               plugin._runtime(user_settings);
               // plugin._runtime.apply(plugin, [user_settings])
               logTableTime = (performance.now() - startTableTime).toFixed(2);
               logTableStatus = true;

            } catch (err) {
               console.groupEnd('plugins status'); // out-of-group display
               console.error(`[ERROR PLUGIN] ${plugin.id}\n${err.stack}\n\nPlease report the bug: https://github.com/raingart/Nova-YouTube-extension/issues/new?body=` + encodeURIComponent(app_ver + ' | ' + navigator.userAgent));

               if (user_settings.report_issues && _pluginsCaptureException) {
                  _pluginsCaptureException({
                     'trace_name': plugin.id,
                     'err_stack': err.stack,
                     'app_ver': app_ver,
                     'confirm_msg': `ERROR in Nova YouTube™\n\nCrash plugin: "${plugin.title}"\nPlease report the bug or disable the plugin\n\nOpen popup to report the bug?`,
                  });
               }

               console.groupCollapsed('plugins status'); // resume console group
               logTableStatus = 'ERROR';
            }
         }

         logTableArray.push({
            'launched': logTableStatus,
            'name': plugin?.id,
            'time init (ms)': logTableTime,
         });
      });
      console.table(logTableArray);
      console.groupEnd('plugins status');

      function pluginChecker(plugin) {
         const result = plugin?.id && plugin.run_on_pages && 'function' === typeof plugin._runtime;
         if (!result) {
            console.error('plugin invalid:\n', {
               'id': plugin?.id,
               'run_on_pages': plugin?.run_on_pages,
               '_runtime': 'function' === typeof plugin?._runtime,
            });
         }
         return result;
      }
   },
}
console.log('%c /* %s */', 'color:#0096fa; font-weight:bold;', GM_info.script.name + ' v.' + GM_info.script.version);

const
   optionsPage = 'https://raingart.github.io/options.html', // ?tabs=tab-plugins
   configStoreName = 'user_settings',
   fix_undefine = v => v === 'undefined' ? undefined : v, // for Tampermonkey
   user_settings = fix_undefine(GM_getValue(configStoreName)) || {};

// Disabled script if youtube is embedded
if (user_settings?.exclude_iframe && (window.frameElement || window.self !== window.top)) {
   return console.warn(GM_info.script.name + ': processed in the iframe disable');
}

// updateKeyStorage
// const keyRenameTemplate = {
//    // 'oldKey': 'newKey',
// }
// for (const oldKey in user_settings) {
//    if (newKey = keyRenameTemplate[oldKey]) {
//       console.log(oldKey, '=>', newKey);
//       delete Object.assign(user_settings, { [newKey]: user_settings[oldKey] })[oldKey];

//       user_settings['thumbs-hide'] = true;
//    }
//    GM_setValue(configStoreName, user_settings);
// }

if (isOptionsPage()) return;

if (!user_settings?.disable_setting_button) renderSettingButton();

landerPlugins();

function isOptionsPage() {
   // GM_registerMenuCommand('Settings', () => window.open(optionsPage));
   GM_registerMenuCommand('Settings', () => GM_openInTab(optionsPage, { active: true }));
   GM_registerMenuCommand('Export settings', () => {
      let d = document.createElement('a');
      d.style.display = 'none';
      d.download = 'nova-settings.json';
      d.href = 'data:text/plain;charset=utf-8,' + encodeURIComponent(JSON.stringify(user_settings));
      document.body.append(d);
      d.click();
      d.remove();
   });
   GM_registerMenuCommand('Import settings', () => {
      let f = document.createElement('input');
      f.type = 'file';
      f.accept = 'application/JSON';
      f.style.display = 'none';
      f.addEventListener('change', function () {
         if (f.files.length !== 1) return alert('file empty');
         let rdr = new FileReader();
         rdr.addEventListener('load', function () {
            try {
               GM_setValue(configStoreName, JSON.parse(rdr.result));
               alert('Settings imported');
               location.reload();
            }
            catch (err) {
               alert(`Error parsing settings\n${err.name}: ${err.message}`);
            }
         });
         rdr.addEventListener('error', error => alert('Error loading file\n' + rdr?.error || error));
         rdr.readAsText(f.files[0]);
      });
      document.body.append(f);
      f.click();
      f.remove();
   });
   //    GM_registerMenuCommand('Import settings', () => {
   //       if(json = JSON.parse(prompt('Enter json file context'))) {
   //           GM_setValue(configStoreName, json);
   //           alert('Settings imported');
   //           location.reload();
   //       } else alert('Import failed');
   //   });

   // is optionsPage
   if (location.hostname === new URL(optionsPage).hostname) {
      // form submit
      document.addEventListener('submit', event => {
         // console.debug('submit', event.target);
         event.preventDefault();

         let obj = {};
         for (let [key, value] of new FormData(event.target)) {
            if (obj.hasOwnProperty(key)) { // SerializedArray
               obj[key] += ',' + value; // add new
               obj[key] = obj[key].split(','); // to array [old, new]

            } else {
               obj[key] = value;
            };
         }
         // fix tab reassignment
         // if (obj.tabs) delete obj.tabs;

         console.debug(`update ${configStoreName}:`, obj);
         GM_setValue(configStoreName, obj);
      });

      window.addEventListener('DOMContentLoaded', () => {
         localizePage(user_settings?.lang_code);
         storeData = user_settings; // export(sync) settings to page
      });

      window.addEventListener('load', () => {
         // unlock if synchronized
         document.body?.classList?.remove('preload');

         document.body.querySelector('a[href$="issues/new"]')
            .addEventListener('click', ({ target }) => {
               target.href += '?body=' + encodeURIComponent(GM_info.script.version + ' | ' + navigator.userAgent);
            });
      });

   } else if (!user_settings || !Object.keys(user_settings).length) { // is user_settings empty
      user_settings['report_issues'] = 'on'; // default plugins settings
      GM_setValue(configStoreName, user_settings);
      // if (confirm('Active plugins undetected. Open the settings page now?')) window.open(optionsPage);
      if (confirm('Active plugins undetected. Open the settings page now?')) GM_openInTab(optionsPage, { active: true });

   } else { // is not optionsPage
      return false;
   }

   return true;
}

function landerPlugins() {
   processLander();

   let playlist_page_transition_count = 0;

   function processLander() {
      const plugins_lander = setInterval(() => {
         // wait page loaded
         const domLoaded = document?.readyState != 'loading';
         if (!domLoaded) return console.debug('waiting, page loading..');

         clearInterval(plugins_lander);
         // force page reload. Dirty hack to page reset hack to clean up junk (for playlist)
         // playlistPageReload();

         console.groupCollapsed('plugins status');

         Plugins.run({
            'user_settings': user_settings,
            'app_ver': GM_info.script.version,
         });

      }, 500); // 100ms
   }

   let lastUrl = location.href;
   const isURLChanged = () => lastUrl == location.href ? false : lastUrl = location.href;
   // skip first page transition
   document.addEventListener('yt-navigate-start', () => isURLChanged() && processLander());

   // function playlistPageReload(sec = 5) {
   //    if (location.search.includes('list=')) {
   //       playlist_page_transition_count++;
   //       // console.debug('playlist_page_transition_count:', playlist_page_transition_count);

   //       if (playlist_page_transition_count === 30) {
   //          const notice = document.createElement('div');
   //          Object.assign(notice.style, {
   //             position: 'fixed',
   //             top: 0,
   //             right: '50%',
   //             transform: 'translateX(50%)',
   //             margin: '50px',
   //             'z-index': 9999,
   //             'border-radius': '2px',
   //             'background-color': 'tomato',
   //             'box-shadow': 'rgb(0 0 0 / 50%) 0px 0px 3px',
   //             'font-size': '12px',
   //             color: '#fff',
   //             padding: '10px',
   //             cursor: 'pointer',
   //          });
   //          notice.addEventListener('click', () => {
   //             playlist_page_transition_count = 0;
   //             notice.remove();
   //             clearTimeout(playlist_reload);
   //          });
   //          notice.innerHTML =
   //             `<h4 style="margin:0;">Attention! ${GM_info.script.name}</h4>
   //             <div>The page will be automatically reloaded within ${sec} sec</div>
   //             <div><i>Click for cancel</i></div>`;
   //          document.body.append(notice);

   //          const playlist_reload = setTimeout(() => location.reload(), 1000 * +sec); // 5sec
   //       }
   //    }
   // }
}

function renderSettingButton() {
   NOVA.waitElement('#masthead #end')
      .then(menu => {
         const a = document.createElement('a');
         a.title = 'Nova Settings';
         a.href = optionsPage + '?tabs=tab-plugins';
         a.target = '_blank';
         a.innerHTML =
            // <div style="display:inline-block;padding:var(--yt-button-icon-padding,8px);width:24px;height:24px;">
            `<yt-icon-button class="style-scope ytd-button-renderer style-default size-default">
               <svg viewBox="0 -2 20 20">
                  <g fill="deepskyblue">
                     <polygon points="0,16 14,8 0,0"/>
                  </g>
               </svg>
            </yt-icon-button>`;
         // a.textContent = '►';
         // Object.assign(a.style, {
         //    'font-size': '24px',
         //    'color': 'deepskyblue !important',
         //    'text-decoration': 'none',
         //    'padding': '0 10px',
         // });
         a.addEventListener('click', () => {
            setTimeout(() => document.body.click(), 200); // fix hide <tp-yt-iron-dropdown>
         });
         menu.prepend(a);

         // const btn = document.createElement('button');
         // btn.className = 'ytd-topbar-menu-button-renderer';
         // btn.title = 'Nova Settings';
         // btn.innerHTML =
         //    `<svg width="24" height="24" viewBox="0 0 24 24">
         //       <g fill="deepskyblue">
         //          <polygon points='21 12 3,1.8 3 22.2' />
         //          <path d='M3 1.8v20.4L21 12L3 1.8z M6 7l9 5.1l-9 5.1V7z' />
         //       </g>
         //    </svg>`;
         // Object.assign(btn.style, {
         //    // color: 'var(--yt-spec-text-secondary)',
         //    padding: '0 24px',
         //    border: 0,
         //    outline: 0,
         //    cursor: 'pointer',
         // });
         // btn.addEventListener('click', () => parent.open(optionsPage + '?tabs=tab-plugins'));
         // // menu.insertBefore(btn, menu.lastElementChild);
         // menu.prepend(btn);
      });
}

function _pluginsCaptureException({ trace_name, err_stack, confirm_msg, app_ver }) {
   // GM_notification({ text: GM_info.script.name + ' an error occurred', timeout: 4000, onclick: openBugReport });

   if (confirm(confirm_msg || `Error in ${GM_info.script.name}. Open popup to report the bug?`)) {
      openBugReport();
   }

   function openBugReport() {
      // window.open(
      GM_openInTab(
         'https://docs.google.com/forms/u/0/d/e/1FAIpQLScfpAvLoqWlD5fO3g-fRmj4aCeJP9ZkdzarWB8ge8oLpE5Cpg/viewform' +
         '?entry.35504208=' + encodeURIComponent(trace_name) +
         '&entry.151125768=' + encodeURIComponent(err_stack) +
         '&entry.744404568=' + encodeURIComponent(location.href) +
         '&entry.1416921320=' + encodeURIComponent(app_ver + ' | ' + navigator.userAgent + ' [' + window.navigator.language + ']')
         , { active: true });
   }
};

window.addEventListener('unhandledrejection', err => {
   //if (!err.reason.stack.toString().includes(${JSON.stringify(chrome.runtime.id)})) return;
   console.error('[ERROR PROMISE]\n', err.reason, '\nPlease report the bug: https://github.com/raingart/Nova-YouTube-extension/issues/new?body=' + encodeURIComponent(GM_info.script.version + ' | ' + navigator.userAgent));

   // if (user_settings.report_issues && err.reason.stack.includes('/Nova%20YouTube.user.js'))
   if (user_settings.report_issues && err.reason.stack.includes('Nova'))
      _pluginsCaptureException({
         'trace_name': 'unhandledrejection',
         'err_stack': err.reason.stack,
         'app_ver': GM_info.script.version,
         'confirm_msg': `Failure when async-call of one "${GM_info.script.name}" plugin.\nDetails in the console\n\nOpen tab to report the bug?`,
      });
});
